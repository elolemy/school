import subprocess, os

print("Checking JS files for syntax errors...")

for path in ["public/assets/app-bundle.js", "assets/app-bundle.js"]:
    if os.path.exists(path):
        res = subprocess.run(["node", "--check", path], capture_output=True, text=True)
        print(f"Node check for {path}: exit code {res.returncode}")
        if res.returncode != 0:
            print(res.stderr[:500])
