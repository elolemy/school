import re

print("Applying bulletproof morning routine and isolated regulations logic...")

with open("assets/app-bundle.js", "r") as f:
    code = f.read()

# 1. wXe render
old_wxe = """s.jsx(wXe,{isOpen:fr,onClose:()=>{Js(!1);try{localStorage.setItem("school_tutorial_completed","true")}catch{}if(rnStep==="tutorial"){setRnStep("story"),is(!0)}},language:i.settings.language})"""
new_wxe = """s.jsx(wXe,{isOpen:fr,onClose:()=>{Js(!1);try{localStorage.setItem("school_tutorial_completed","true")}catch{}if(window.__morningRoutineStep==="tutorial"){window.__morningRoutineStep="story";is(!0)}else{window.__morningRoutineStep=null}},language:i.settings.language})"""
assert old_wxe in code, "old_wxe not found"
code = code.replace(old_wxe, new_wxe)

# 2. aZe render
old_aze = """s.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1),l(pe=>({...pe,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));const wasStory=rnStep==="story";setRnStep(null);if(wasStory){setRnStep("regulations");we(!0)}},currentDay:i.currentDay,schoolName:i.settings.schoolName,reputation:i.reputation,budget:i.budget"""
new_aze = """s.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1),l(pe=>({...pe,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));if(window.__morningRoutineStep==="story"){window.__morningRoutineStep="regulations";we(!0)}else{window.__morningRoutineStep=null}},currentDay:i.currentDay,schoolName:i.settings.schoolName,reputation:i.reputation,budget:i.budget"""
assert old_aze in code, "old_aze not found"
code = code.replace(old_aze, new_aze)

# 3. CJe render
old_cje = """s.jsx(CJe,{isOpen:de,onClose:()=>{we(!1);const wasReg=rnStep==="regulations";setRnStep(null);if(wasReg){p(!0)}},language:i.settings.language,isDark:vi})"""
new_cje = """s.jsx(CJe,{isOpen:de,onClose:()=>{we(!1);if(window.__morningRoutineStep==="regulations"){window.__morningRoutineStep=null;p(!0)}else{window.__morningRoutineStep=null}},language:i.settings.language,isDark:vi})"""
assert old_cje in code, "old_cje not found"
code = code.replace(old_cje, new_cje)

# 4. SJe start actions (onStartGame, onStartMorningRoutine)
code = re.sub(
    r'onStartGame:\(\)=>\{[^\}]+setRnStep\("tutorial"\),Js\(!0\),c\("desk"\)\}',
    'onStartGame:()=>{I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!1);is(!1);we(!1);window.__morningRoutineStep="tutorial";Js(!0);c("desk")}',
    code
)

code = re.sub(
    r'onStartMorningRoutine:\(\)=>\{[^\}]+setRnStep\("tutorial"\),Js\(!0\),c\("desk"\)\}',
    'onStartMorningRoutine:()=>{I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!1);is(!1);we(!1);window.__morningRoutineStep="tutorial";Js(!0);c("desk")}',
    code
)

# 5. Clean up any remaining setRnStep calls to window.__morningRoutineStep
code = code.replace('setRnStep(null);we(!0)', 'window.__morningRoutineStep=null;we(!0)')
code = code.replace('setRnStep("tutorial")', 'window.__morningRoutineStep="tutorial"')
code = code.replace('setRnStep("story")', 'window.__morningRoutineStep="story"')
code = code.replace('setRnStep("regulations")', 'window.__morningRoutineStep="regulations"')

with open("assets/app-bundle.js", "w") as f:
    f.write(code)

print("Successfully updated assets/app-bundle.js!")
