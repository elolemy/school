import re

print("Applying perfect morning routine and isolated regulations flow...")

with open("assets/app-bundle.js", "r") as f:
    code = f.read()

# 1. Ensure wXe onClose sets morning routine step to story if in tutorial, else null
old_wxe = 's.jsx(wXe,{isOpen:fr,onClose:()=>{Js(!1);try{localStorage.setItem("school_tutorial_completed","true")}catch{}if(window.__morningRoutineStep==="tutorial"){window.__morningRoutineStep="story";is(!0)}else{window.__morningRoutineStep=null}},language:i.settings.language})'
if old_wxe not in code:
    # Try finding wXe render with regex
    code = re.sub(
        r's\.jsx\(wXe,\{isOpen:fr,onClose:\(\)=>\{[^\}]+\},language:i\.settings\.language\}\)',
        's.jsx(wXe,{isOpen:fr,onClose:()=>{Js(!1);try{localStorage.setItem("school_tutorial_completed","true")}catch{}if(window.__morningRoutineStep==="tutorial"){window.__morningRoutineStep="story";is(!0)}else{window.__morningRoutineStep=null}},language:i.settings.language})',
        code
    )

# 2. Ensure aZe onClose sets morning routine step to regulations if in story, else null
old_aze_pattern = r's\.jsx\(aZe,\{isOpen:ms,onClose:\(\)=>\{[^\}]+\},currentDay:i\.currentDay'
new_aze = 's.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1),l(pe=>({...pe,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));if(window.__morningRoutineStep==="story"){window.__morningRoutineStep="regulations";we(!0)}else{window.__morningRoutineStep=null}},currentDay:i.currentDay'
code = re.sub(old_aze_pattern, new_aze, code)

# 3. Ensure CJe onClose checks if window.__morningRoutineStep === "regulations" to open p(!0), else just closes
old_cje_pattern = r's\.jsx\(CJe,\{isOpen:de,onClose:\(\)=>\{[^\}]+\},language:i\.settings\.language,isDark:vi\}\)'
new_cje = 's.jsx(CJe,{isOpen:de,onClose:()=>{we(!1);if(window.__morningRoutineStep==="regulations"){window.__morningRoutineStep=null;p(!0)}else{window.__morningRoutineStep=null}},language:i.settings.language,isDark:vi})'
if re.search(old_cje_pattern, code):
    code = re.sub(old_cje_pattern, new_cje, code)
else:
    # Fallback replacement for CJe close
    code = re.sub(
        r's\.jsx\(CJe,\{isOpen:de,onClose:[^}]+\},language:i\.settings\.language,isDark:vi\}\)',
        new_cje,
        code
    )

# 4. Ensure onStartMorningRoutine and onStartGame set window.__morningRoutineStep="tutorial" and open Js(!0)
code = re.sub(
    r'onStartGame:\(\)=>\{[^}]+\}',
    'onStartGame:()=>{I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!1);is(!1);we(!1);window.__morningRoutineStep="tutorial";Js(!0);c("desk")}',
    code
)

code = re.sub(
    r'onStartMorningRoutine:\(\)=>\{[^}]+\}',
    'onStartMorningRoutine:()=>{I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!1);is(!1);we(!1);window.__morningRoutineStep="tutorial";Js(!0);c("desk")}',
    code
)

# 5. Ensure manual opening of regulations (onOpenDailyRegulations, onOpenRulebook, open-rulebook) explicitly sets window.__morningRoutineStep = null
code = code.replace('onOpenDailyRegulations:()=>we(!0)', 'onOpenDailyRegulations:()=>{window.__morningRoutineStep=null;we(!0)}')
code = code.replace('onOpenRulebook:()=>we(!0)', 'onOpenRulebook:()=>{window.__morningRoutineStep=null;we(!0)}')
code = code.replace('window.addEventListener("open-rulebook",()=>we(!0))', 'window.addEventListener("open-rulebook",()=>{window.__morningRoutineStep=null;we(!0)})')

with open("assets/app-bundle.js", "w") as f:
    f.write(code)

print("Perfect flow applied successfully!")
