import json
import time

new_docs = [
  {
    "id": "app_doc_35",
    "titleAr": "استمارة ترشيح لأولمبياد الروبوتات والذكاء الاصطناعي المدرسي",
    "titleEn": "School AI & Robotics Olympiad Official Nomination Form",
    "categoryAr": "ابتكارات وتكنولوجيا",
    "categoryEn": "Tech & Innovation",
    "studentNameAr": "يوسف البرمجي",
    "studentNameEn": "Youssef El-Barmagy",
    "descriptionAr": "الطالب صمم نموذج ذكاء اصطناعي يكتشف تسريب المياه في المعامل ويرغب في تمثيل المدرسة.",
    "descriptionEn": "Student built an AI system detecting water leaks in labs seeking school representation.",
    "stampRequirementAr": "موافق مع ختم الاعتماد التكنولوجي",
    "stampRequirementEn": "Approved with Tech Endorsement Seal",
    "icon": "🤖",
    "quirkAr": "مطبوع برمز QR باركود ذكي",
    "quirkEn": "Printed with dynamic QR code"
  },
  {
    "id": "app_doc_36",
    "titleAr": "شهادة كشف طبي معتمد وفحص لياقة من مستشفى النخبة التخصصي",
    "titleEn": "Elite Hospital Comprehensive Medical & Fitness Clearance",
    "categoryAr": "شؤون الصحة المدرسية",
    "categoryEn": "Health Clearance",
    "studentNameAr": "مروان كمال النبراوي",
    "studentNameEn": "Marwan Kamal El-Nabrawy",
    "descriptionAr": "إفادة بخلو الطالب من الأمراض المزمنة مع توصية بتناول وجبة تفاح إضافية في الفسحة.",
    "descriptionEn": "Clearance from chronic conditions with medical recommendation for extra apple at recess.",
    "stampRequirementAr": "معتمد بختم النسر الطبي",
    "stampRequirementEn": "Approved with Medical Eagle Seal",
    "icon": "🩺",
    "quirkAr": "مختوم بشعار المستشفى الأحمر",
    "quirkEn": "Sealed with red hospital crest"
  },
  {
    "id": "app_doc_37",
    "titleAr": "طلب تحويل رسمي بين الإدارات التعليمية ممهور بختم الشعار",
    "titleEn": "Official Inter-District Educational Transfer Petition",
    "categoryAr": "شؤون القيد والتحويل",
    "categoryEn": "Enrollment & Transfers",
    "studentNameAr": "زياد عبد الحميد الدسوقي",
    "studentNameEn": "Ziad Abdel Hamid El-Desouky",
    "descriptionAr": "طلب انتقال عاجل بسبب نقل عمل ولي الأمر إلى جوار الحرم المدرسي مع إرفاق بيان الدرجات.",
    "descriptionEn": "Urgent transfer due to parent relocation near campus with attached academic transcript.",
    "stampRequirementAr": "موافق بعد التحقق من السعة الاستيعابية",
    "stampRequirementEn": "Approved upon Capacity Check",
    "icon": "📑",
    "quirkAr": "مكتوب على ورق ديواني فاخر",
    "quirkEn": "Official parchment header"
  },
  {
    "id": "app_doc_38",
    "titleAr": "استمارة تفوق رياضي وبطولة الجمهورية لألعاب القوى",
    "titleEn": "National School Athletics Championship Merit Diploma",
    "categoryAr": "بطولات وأنشطة رياضية",
    "categoryEn": "Athletics & Sports",
    "studentNameAr": "كريم العداء الصاروخي",
    "studentNameEn": "Karim The Rocket Runner",
    "descriptionAr": "حاصل على الميدالية الذهبية في سباق 100 متر حواجز ويطلب إذناً للتدريب المبكر بالصالة الرياضية.",
    "descriptionEn": "100m hurdles gold medalist requesting early gym access pass.",
    "stampRequirementAr": "معتمد مع وسام الشرف الرياضي",
    "stampRequirementEn": "Approved with Sports Honor Badge",
    "icon": "🏃",
    "quirkAr": "ممهور بشريط ميدالية ذهبي",
    "quirkEn": "Embossed gold ribbon ribbon"
  },
  {
    "id": "app_doc_39",
    "titleAr": "إفادة سداد المصروفات المدرسية عبر فوري ومكاتب البريد",
    "titleEn": "Official Egyptian Post & Fawry Tuition Payment Receipt",
    "categoryAr": "الحسابات والمصروفات",
    "categoryEn": "Finance & Tuition",
    "studentNameAr": "نور الدين المحاسب",
    "studentNameEn": "Nour El-Deen The Accountant",
    "descriptionAr": "إيصال سداد إلكتروني معتمد بالرقم المرجعي لتسوية القسط الدراسي الأول بالكامل.",
    "descriptionEn": "Verified electronic receipt with transaction reference for 1st semester tuition settlement.",
    "stampRequirementAr": "خالص السداد ومعتمد بالخزينة",
    "stampRequirementEn": "Fully Paid & Treasury Endorsed",
    "icon": "💳",
    "quirkAr": "مطبوع برقم عملية إلكتروني",
    "quirkEn": "Valid e-payment transaction ID"
  },
  {
    "id": "app_doc_40",
    "titleAr": "طلب إعفاء استثنائي من رسوم المقصف والزي لظروف التفوق",
    "titleEn": "Merit-Based Canteen & Uniform Fee Exemption Waiver",
    "categoryAr": "منح ورعاية المتفوقين",
    "categoryEn": "Scholarships & Grants",
    "studentNameAr": "سلمى صبحي العبقرية",
    "studentNameEn": "Salma Sobhy The Prodigy",
    "descriptionAr": "الطالبة حصدت المركز الأول على المحافظة وتطلب منحة كاملة للزي والكتب المدرسية.",
    "descriptionEn": "Ranked #1 in the governorate requesting full uniform and textbook scholarship grant.",
    "stampRequirementAr": "موافق بقرار مجلس الأمناء",
    "stampRequirementEn": "Approved by Board Decree",
    "icon": "🎓",
    "quirkAr": "مرفق بشهادة درجات 100%",
    "quirkEn": "Attached 100% transcript"
  },
  {
    "id": "app_doc_41",
    "titleAr": "محضر جلسة مجلس تأديب واعتذار رسمي مصدق من ولي الأمر",
    "titleEn": "Disciplinary Board Hearing Reconciliation & Conduct Pledge",
    "categoryAr": "شؤون الانضباط والسلوك",
    "categoryEn": "Discipline & Conduct",
    "studentNameAr": "شادي المشاغب التائب",
    "studentNameEn": "Shady The Reformed Prankster",
    "descriptionAr": "تعهد كتابي بعدم إطلاق المفرقعات الصوتية في الفناء وتنظيف مقاعد الفصل لمدة أسبوعين.",
    "descriptionEn": "Written pledge to cease courtyard noise pranks and clean classroom desks for 2 weeks.",
    "stampRequirementAr": "موافق مع وضعه تحت الملاحظة",
    "stampRequirementEn": "Approved under Probation",
    "icon": "⚖️",
    "quirkAr": "موقع ببصمة ولي الأمر والناظر",
    "quirkEn": "Signed by guardian & vice principal"
  },
  {
    "id": "app_doc_42",
    "titleAr": "استمارة اختبارات القدرات والميول الأكاديمية والمهنية",
    "titleEn": "Early Aptitude & Career Orientation Diagnostic Profile",
    "categoryAr": "التوجيه الأكاديمي والمهني",
    "categoryEn": "Career Guidance",
    "studentNameAr": "عمر المهندس المستقبلي",
    "studentNameEn": "Omar The Future Engineer",
    "descriptionAr": "نتائج مقياس الميول تشير إلى تميز فائق في التفكير الهندسي والفيزياء التطبيقية بنسبة 98%.",
    "descriptionEn": "Aptitude profile showing 98% mastery in mechanical reasoning and applied physics.",
    "stampRequirementAr": "معتمد للتوجيه العلمي المتقدم",
    "stampRequirementEn": "Approved for Advanced STEM",
    "icon": "📐",
    "quirkAr": "مخطط بياني للمهارات",
    "quirkEn": "Skills radar diagram"
  },
  {
    "id": "app_doc_43",
    "titleAr": "تقرير تفتيش الحقيبة المدرسية وإقرار خلو من الممنوعات",
    "titleEn": "Backpack Security Inspection & Contraband-Free Slip",
    "categoryAr": "أمن وسلامة البوابات",
    "categoryEn": "Campus Security",
    "studentNameAr": "سامح أمين الحقيبة",
    "studentNameEn": "Sameh The Bag Inspector",
    "descriptionAr": "تم فحص الحقيبة بجهاز الكشف، ولا تحتوي إلا على دفاتر الأنشطة والألوان الخشبية المصرح بها.",
    "descriptionEn": "Bag scanned cleanly at main gate; only authorized coloring pencils and notebooks present.",
    "stampRequirementAr": "مرور آمن ومطابق للشروط",
    "stampRequirementEn": "Safe Pass Verified",
    "icon": "🎒",
    "quirkAr": "ملصق فحص أمني أخضر",
    "quirkEn": "Green safety clearance sticker"
  },
  {
    "id": "app_doc_44",
    "titleAr": "تصريح مشاركة في المعسكر الكشفي والبيئي بمحمية وادي الريان",
    "titleEn": "Scout Camp & Nature Reserve Expedition Participation Pass",
    "categoryAr": "رحلات ومعسكرات بيئية",
    "categoryEn": "Scouts & Expeditions",
    "studentNameAr": "طارق قائد الكشافة",
    "studentNameEn": "Tarek The Scout Leader",
    "descriptionAr": "موافقة رسمية للمبيت في الخيام وتعلم مهارات الإسعافات الأولية والتخييم تحت إشراف القادة.",
    "descriptionEn": "Official permit for tent camping, first aid mastery, and environmental survival.",
    "stampRequirementAr": "موافق مع تعليمات السلامة",
    "stampRequirementEn": "Approved with Safety Directives",
    "icon": "⛺",
    "quirkAr": "مختوم بشعار الكشافة البحرية",
    "quirkEn": "Sea scouts official emblem"
  },
  {
    "id": "app_doc_45",
    "titleAr": "وثيقة تسجيل براءة اختراع لجهاز توليد طاقة شمسية مصغر",
    "titleEn": "Student Micro-Solar Clean Energy Patent Certificate",
    "categoryAr": "المخترع الصغير والبيئة",
    "categoryEn": "Young Inventor Patents",
    "studentNameAr": "رانيا شمس الدين",
    "studentNameEn": "Rania Shams El-Deen",
    "descriptionAr": "ابتكار خلايا شمسية من مواد معاد تدويرها لشحن مصابيح الفصول تلقائياً أثناء الطوارئ.",
    "descriptionEn": "Invented recycled mini-solar panel to power emergency classroom LED lights.",
    "stampRequirementAr": "معتمد للمشاركة في معرض الجمهورية",
    "stampRequirementEn": "Endorsed for National Expo",
    "icon": "☀️",
    "quirkAr": "رسم هندسي للدائرة الكهربائية",
    "quirkEn": "Schematic blueprint included"
  },
  {
    "id": "app_doc_46",
    "titleAr": "إذن سفر وتمثيل المدرسة في مسابقة الخطابة والمناظرات",
    "titleEn": "National Eloquence & Debate Championship Travel Warrant",
    "categoryAr": "مناظرات وفنون الخطابة",
    "categoryEn": "Debate & Rhetoric",
    "studentNameAr": "بلال فصيح اللسان",
    "studentNameEn": "Belal The Eloquent Orator",
    "descriptionAr": "ترشيح رسمي لتمثيل المجمع التعليمي في مناظرات ديوان الوزارة حول تحديات التعليم الحديث.",
    "descriptionEn": "Nominated to represent school in ministry public debates on modern educational challenges.",
    "stampRequirementAr": "موافق وتكليف رسمي بالسفر",
    "stampRequirementEn": "Approved Travel Assignment",
    "icon": "🎙️",
    "quirkAr": "مكتوب بلغة عربية فصحى مشكولة",
    "quirkEn": "Vocalized Classical Arabic script"
  },
  {
    "id": "app_doc_47",
    "titleAr": "شهادة حفظ القرآن الكريم وتجويده من ديوان الأوقاف",
    "titleEn": "Holy Quran Memorization & Tajweed Certified Diploma",
    "categoryAr": "مسابقات دينية وثقافية",
    "categoryEn": "Religious & Cultural Honors",
    "studentNameAr": "حمزة عبد التواب",
    "studentNameEn": "Hamza Abdel Tawwab",
    "descriptionAr": "إتمام حفظ القرآن الكريم كاملاً برواية حفص عن عاصم مع مرتبة الشرف الأولى للإذاعة الصباحية.",
    "descriptionEn": "Full memorization with first-class recitation honors for school morning assembly recitals.",
    "stampRequirementAr": "مبارك ومعتمد للتكريم في حفل الختام",
    "stampRequirementEn": "Blessed & Approved for Gala Honor",
    "icon": "📖",
    "quirkAr": "زخارف إسلامية ذهبية مذهبة",
    "quirkEn": "Gilded Islamic border calligraphy"
  },
  {
    "id": "app_doc_48",
    "titleAr": "طلب انضمام لفريق كرة القدم المدرسي الاحترافي FC 27",
    "titleEn": "FC 27 School Football Academy Pro Trial Application",
    "categoryAr": "دوري المدارس وكرة القدم",
    "categoryEn": "FC 27 Football League",
    "studentNameAr": "حسام حريف الملاعب",
    "studentNameEn": "Hossam The Playmaker",
    "descriptionAr": "صانع ألعاب يمتلك قدم يسرى ساحرة ودقة تمرير 94% يطلب خوض اختبارات القبول الرسمية.",
    "descriptionEn": "Left-footed playmaker boasting 94% pass accuracy requesting official tryout trial.",
    "stampRequirementAr": "موافق لتحت الاختبار الفني",
    "stampRequirementEn": "Approved for Technical Trial",
    "icon": "⚽",
    "quirkAr": "مرفق ببطاقة إحصائيات تقييم 84 OVR",
    "quirkEn": "Attached 84 OVR FUT stat card"
  },
  {
    "id": "app_doc_49",
    "titleAr": "عقد رعاية تجارية للزي الرياضي المدرسي من شركة ألعاب محلية",
    "titleEn": "Official School Sports Jersey Commercial Sponsorship Pact",
    "categoryAr": "الاستثمار والرعايات الرياضية",
    "categoryEn": "Commercial Sponsorships",
    "studentNameAr": "مندوب شركة الأبطال الرياضية",
    "studentNameEn": "Champions Sports Representative",
    "descriptionAr": "عرض تمويل بقيمة 5,000 ج.م لشراء شورتات وتيشيرتات الفريق مقابل وضع الشعار بالملعب.",
    "descriptionEn": "5,000 EGP sponsorship to fund team kits in exchange for sideline banner placement.",
    "stampRequirementAr": "موافق مع إيداع العائد بخزينة المدرسة",
    "stampRequirementEn": "Approved & Deposited to Vault",
    "icon": "👕",
    "quirkAr": "مختوم بخاتم تجاري ثلاثي الأبعاد",
    "quirkEn": "3D Holographic commercial stamp"
  },
  {
    "id": "app_doc_50",
    "titleAr": "تصريح دخول واستخدام الدراجات الهوائية ومواقف الحرم المدرسي",
    "titleEn": "Student Bicycle Campus Commute & Parking Permit",
    "categoryAr": "المبادرات الخضراء والمواصلات",
    "categoryEn": "Green Transit & Parking",
    "studentNameAr": "مازن دراج الحي",
    "studentNameEn": "Mazen The Cyclist",
    "descriptionAr": "تعهد بارتداء خوذة الأمان وركن الدراجة في الموقف المخصص بجانب بوابة الأنشطة.",
    "descriptionEn": "Commitment to wear safety helmet and park bicycle in designated green transit zone.",
    "stampRequirementAr": "تصريح سارٍ للعام الدراسي كاملاً",
    "stampRequirementEn": "Valid Full-Year Pass",
    "icon": "🚲",
    "quirkAr": "مرفق برقم لوحة معدنية للدراجة",
    "quirkEn": "Bicycle chassis tag number included"
  },
  {
    "id": "app_doc_51",
    "titleAr": "استمارة فحص النظر وتصريح الجلوس في المقاعد الأمامية",
    "titleEn": "Ophthalmology Clinic Front-Row Seating Medical Directive",
    "categoryAr": "الرعاية البصرية والصحية",
    "categoryEn": "Optical Health",
    "studentNameAr": "ندى حازم البصري",
    "studentNameEn": "Nada Hazem El-Basry",
    "descriptionAr": "كشف نظر يؤكد قصر نظر خفيف وتوصية طبية بنقل الطالبة للمقعد الأول أمام السبورة التفاعلية.",
    "descriptionEn": "Mild myopia diagnosis recommending student placement in front row facing smart board.",
    "stampRequirementAr": "توجيه إداري ملزم لمعلم الفصل",
    "stampRequirementEn": "Mandatory Teacher Directive",
    "icon": "👓",
    "quirkAr": "مرفق بجدول قياس حدة الإبصار 6/9",
    "quirkEn": "Attached 6/9 vision chart"
  },
  {
    "id": "app_doc_52",
    "titleAr": "وثيقة تطوع بنك الطعام ومساعدة عمال النظافة بالحرم",
    "titleEn": "Campus Environmental Cleanliness & Food Bank Service Diploma",
    "categoryAr": "الخدمة العامة والتطوع",
    "categoryEn": "Community & Service",
    "studentNameAr": "سعد فاعل الخير",
    "studentNameEn": "Saad The Generous",
    "descriptionAr": "إتمام 30 ساعة عمل تطوعي في تنظيف الفناء وتجميع بقايا الخبز النظيف لتوزيعه على الطيور.",
    "descriptionEn": "Completed 30 volunteer hours sorting recess leftovers and keeping courtyard pristine.",
    "stampRequirementAr": "معتمد مع شهادة شكر وتقدير",
    "stampRequirementEn": "Approved with Commendation",
    "icon": "🌱",
    "quirkAr": "مختوم بشعار الهلال الأخضر",
    "quirkEn": "Green crescent community emblem"
  },
  {
    "id": "app_doc_53",
    "titleAr": "طلب تمديد فترة استعارة موسوعات المكتبة المركزية الكبرى",
    "titleEn": "Central Library Rare Historical Encyclopedia Loan Extension",
    "categoryAr": "المكتبة والبحث العلمي",
    "categoryEn": "Library & Research",
    "studentNameAr": "عاصم باحث الآثار",
    "studentNameEn": "Assem The Historian",
    "descriptionAr": "الطالب يعكف على كتابة بحث عن تاريخ طنطا التعليمي في القرن التاسع عشر ويطلب شهراً إضافياً.",
    "descriptionEn": "Student drafting a thesis on 19th century regional school history seeking 30-day loan.",
    "stampRequirementAr": "موافق مع الالتزام بسلامة المجلدات",
    "stampRequirementEn": "Approved with Care Obligation",
    "icon": "📚",
    "quirkAr": "مطبوع برقم تصنيف ديوي العشري",
    "quirkEn": "Dewey Decimal stamp: 962.05"
  },
  {
    "id": "app_doc_54",
    "titleAr": "إفادة التحاق ببرنامج رعاية الموهوبين والعباقرة الصغار",
    "titleEn": "Gifted & Talented Accelerated Enrichment Admission Slip",
    "categoryAr": "رعاية الموهوبين والذكاء",
    "categoryEn": "Gifted Programs",
    "studentNameAr": "آية أحمد العبقرية",
    "studentNameEn": "Aya Ahmed The Prodigy",
    "descriptionAr": "اجتياز اختبار الذكاء (IQ) بنتيجة 142 درجة والحصول على مقعد في ورش العلوم المتقدمة.",
    "descriptionEn": "Scored 142 on standard Mensa IQ assessment qualifying for advanced physics workshops.",
    "stampRequirementAr": "معتمد لبرنامج رعاية النوابغ",
    "stampRequirementEn": "Approved for Genius Track",
    "icon": "🧠",
    "quirkAr": "ممهور بشهادة اختبار ذكاء موثقة",
    "quirkEn": "Certified IQ scorecard 142"
  },
  {
    "id": "app_doc_55",
    "titleAr": "عريضة تنظيم دوري الشطرنج الذهبي لفسحة الظهيرة الكبرى",
    "titleEn": "Golden Chess Noon Recess Tournament Grand Petition",
    "categoryAr": "أنشطة العقل والذكاء",
    "categoryEn": "Chess & Strategy",
    "studentNameAr": "ماجد ملك الشطرنج",
    "studentNameEn": "Maged The Chess Grandmaster",
    "descriptionAr": "جمع توقيعات 45 طالباً لتخصيص 4 طاولات رخامية بالفناء لمسابقات الشطرنج السريعة.",
    "descriptionEn": "Gathered 45 student signatures to dedicate 4 shaded courtyard tables for blitz chess.",
    "stampRequirementAr": "موافق وتكليف معلم التربية الفكرية",
    "stampRequirementEn": "Approved & Assigned to Mentor",
    "icon": "♟️",
    "quirkAr": "مرسوم برقعة شطرنج وتواقيع طلابية",
    "quirkEn": "Signed with chess board sketches"
  }
]

docs_js = []
for d in new_docs:
    obj_str = "{" + f"id:{json.dumps(d['id'])},titleAr:{json.dumps(d['titleAr'])},titleEn:{json.dumps(d['titleEn'])},categoryAr:{json.dumps(d['categoryAr'])},categoryEn:{json.dumps(d['categoryEn'])},studentNameAr:{json.dumps(d['studentNameAr'])},studentNameEn:{json.dumps(d['studentNameEn'])},descriptionAr:{json.dumps(d['descriptionAr'])},descriptionEn:{json.dumps(d['descriptionEn'])},stampRequirementAr:{json.dumps(d['stampRequirementAr'])},stampRequirementEn:{json.dumps(d['stampRequirementEn'])},icon:{json.dumps(d['icon'])},quirkAr:{json.dumps(d['quirkAr'])},quirkEn:{json.dumps(d['quirkEn'])}" + "}"
    docs_js.append(obj_str)

injected_str = "," + ",".join(docs_js)

with open("assets/index-BeRTxH1o.js", "r") as f:
    code = f.read()

idx = code.find("const zR=[")
end_idx = code.find("];", idx)
assert idx != -1 and end_idx != -1, "zR array not found"

new_code = code[:end_idx] + injected_str + code[end_idx:]

with open("assets/index-BeRTxH1o.js", "w") as f:
    f.write(new_code)
with open("assets/app-bundle.js", "w") as f:
    f.write(new_code)

ts = int(time.time())

html = f"""<!doctype html>
<html lang="ar" dir="rtl">
  <head>
    <script type="module" src="/@vite/client"></script>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>School Principal Simulator - مدير المدرسة</title>
    <meta name="description" content="An interactive school principal simulation featuring a Pro Football Hub (FC27 style) with tactical boards, match simulations, transfer markets, youth academy scouting, and comprehensive examination control rooms, principal career progression, and administrative routines." />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" crossorigin href="/assets/app-bundle.css?v={ts}">
    <script type="module" crossorigin src="/assets/app-bundle.js?v={ts}"></script>
  </head>
  <body class="bg-slate-900 text-slate-100 font-['Cairo',sans-serif] antialiased">
    <div id="root"></div>
  </body>
</html>"""

with open("index.html", "w") as f:
    f.write(html)
with open("dist/index.html", "w") as f:
    f.write(html)

print("SUCCESS: Injected all 21 new documents and regenerated bundle!")
