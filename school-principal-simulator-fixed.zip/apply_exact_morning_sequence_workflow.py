import subprocess

print("Applying exact requested workflow:")
print("1. Fix vxe so no initial students have decision: 'accepted' (change all to 'pending')")
print("2. Restart Story leaves game in menu without triggering sequence")
print("3. Start Morning Routine launches sequence: [اللائحة -> القصة -> التعليمات -> قرار المدير الإداري -> المكتب]")

for path in ["public/assets/app-bundle.js", "assets/app-bundle.js"]:
    print(f"Updating {path}...")
    with open(path, "r") as f:
        c = f.read()

    # 1. In vxe array: replace decision:"accepted" with decision:"pending"
    # Find vxe definition
    idx_vxe = c.find("vxe=[{")
    idx_vxe_end = c.find("],DQ=", idx_vxe)
    if idx_vxe != -1 and idx_vxe_end != -1:
        vxe_chunk = c[idx_vxe:idx_vxe_end]
        vxe_chunk_fixed = vxe_chunk.replace('decision:"accepted"', 'decision:"pending"')
        c = c[:idx_vxe] + vxe_chunk_fixed + c[idx_vxe_end:]
        print(f"  Fixed vxe array: replaced 'accepted' with 'pending'")
    else:
        print(f"  WARNING: vxe slice not found!")

    # 2. In e (onRestartStory): do not launch sequence, just reset and stay on start menu
    old_e = 'window.__isRestartSequence=!0,u(!1),p(!0),is(!1),we(!1),Js(!1),c("desk")}'
    new_e = 'window.__isRestartSequence=!1,u(!0),p(!1),is(!1),we(!1),Js(!1)}'
    if old_e in c:
        c = c.replace(old_e, new_e)
        print("  Updated e (onRestartStory): leaves in menu without launching modals")
    else:
        print("  WARNING: old_e not found!")

    # 3. onStartGame and onStartMorningRoutine: launch sequence starting with JDe, and guarantee clean queue
    old_start = 'onStartGame:()=>{window.__isRestartSequence=!1;I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:null}));u(!1);p(!1);is(!1);we(!1);Js(!1);c("desk")},onStartMorningRoutine:()=>{window.__isRestartSequence=!1;I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:null}));u(!1);p(!1);is(!1);we(!1);Js(!1);c("desk")}'
    new_start = 'onStartGame:()=>{window.__isMorningSequence=!0;I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty),cleanQueue=ae.map(st=>({...st,decision:"pending"}));l(pe=>({...pe,isDayStarted:!1,currentDailyQueue:cleanQueue,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!0);is(!1);we(!1);Js(!1);c("desk")},onStartMorningRoutine:()=>{window.__isMorningSequence=!0;I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty),cleanQueue=ae.map(st=>({...st,decision:"pending"}));l(pe=>({...pe,isDayStarted:!1,currentDailyQueue:cleanQueue,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!0);is(!1);we(!1);Js(!1);c("desk")}'
    if old_start in c:
        c = c.replace(old_start, new_start)
        print("  Updated onStartGame and onStartMorningRoutine to start morning sequence and clean queue")
    else:
        print("  WARNING: old_start not found!")

    # 4. JDe onStartDay: closes JDe and opens Story (aZe)
    old_jde = 'onStartDay:()=>{p(!1);if(window.__isRestartSequence){I.playRulebookOpen();is(!0)}else{I.playSchoolBell();l(ae=>({...ae,isDayStarted:!0,currentEvent:null}))}}'
    new_jde = 'onStartDay:()=>{p(!1);I.playRulebookOpen();is(!0)}'
    if old_jde in c:
        c = c.replace(old_jde, new_jde)
        print("  Updated JDe onStartDay to always open Story")
    else:
        print("  WARNING: old_jde not found!")

    # 5. aZe onClose: closes Story and opens Instructions (wXe)
    old_aze = 's.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1);if(window.__isRestartSequence){I.playPaperSlide();Js(!0)}else{l(pe=>({...pe,currentEvent:null}))}},'
    new_aze = 's.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1);I.playPaperSlide();Js(!0)},'
    if old_aze in c:
        c = c.replace(old_aze, new_aze)
        print("  Updated aZe onClose to always open Instructions")
    else:
        print("  WARNING: old_aze not found!")

    # 6. wXe onClose: closes Instructions and triggers Administrative Decision (XDe)
    old_wxe = 's.jsx(wXe,{isOpen:fr,onClose:()=>{Js(!1);try{localStorage.setItem("school_tutorial_completed","true")}catch{}if(window.__isRestartSequence){window.__isRestartSequence=!1;l(pe=>({...pe,isDayStarted:!0,currentEvent:null}));c("desk")}},language:i.settings.language})'
    new_wxe = 's.jsx(wXe,{isOpen:fr,onClose:()=>{Js(!1);try{localStorage.setItem("school_tutorial_completed","true")}catch{}l(pe=>({...pe,isDayStarted:!0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));c("desk")},language:i.settings.language})'
    if old_wxe in c:
        c = c.replace(old_wxe, new_wxe)
        print("  Updated wXe onClose to trigger Administrative Decision (XDe)")
    else:
        print("  WARNING: old_wxe not found!")

    with open(path, "w") as f:
        f.write(c)

    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check!")
    else:
        print(f"  ERROR: {path} syntax error:\n{res.stderr[:400]}")
        exit(1)

print("Exact workflow implementation applied successfully!")
