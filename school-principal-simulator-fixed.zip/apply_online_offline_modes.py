import subprocess
import re
import time

print("Implementing Full Online/Offline Modes, Exit Sync & Dedicated Buttons...")

for path in ["assets/app-bundle.js", "public/assets/app-bundle.js"]:
    print(f"\nProcessing {path}...")
    with open(path, "r") as f:
        c = f.read()

    # 1. Update Kat effects: define startSharedOnlineCompetition and enhanced returnToStartMenu
    old_kat_effect_start = 'window.openOnlineMultiplayer=()=>setIsMultiplayerOpen(!0);'
    new_kat_effect_start = '''window.openOnlineMultiplayer=()=>setIsMultiplayerOpen(!0);
      window.returnToStartMenu=()=>{
        try {
          if (typeof window.__broadcastMultiExit === "function") window.__broadcastMultiExit();
        } catch(e) {}
        setOppState(null);
        setIsMultiplayerOpen(!1);
        p(!1);
        is(!1);
        we(!1);
        Js(!1);
        setIsDecisionOpen(!1);
        l(pe => ({ ...pe, isDayStarted: !1 }));
        u(!0);
      };
      window.startSharedOnlineCompetition=()=>{
        setIsMultiplayerOpen(!1);
        u(!1);
        Js(!1);
        is(!1);
        we(!1);
        setIsDecisionOpen(!1);
        const queue=$E(1,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);
        l(pe=>({...pe,currentDailyQueue:queue,currentStudentIndex:0,isDayStarted:!1,currentEvent:_Q(1)}));
        p(!0);
      };
      window.startSharedMorningRoutine=()=>{
        window.startSharedOnlineCompetition();
      };'''

    if old_kat_effect_start in c:
        # replace from window.openOnlineMultiplayer up to startSharedMorningRoutine block
        c = re.sub(
            r'window\.openOnlineMultiplayer=\(\)=>setIsMultiplayerOpen\(!0\);[^;]+window\.returnToStartMenu=[^;]+;[^;]+window\.startSharedMorningRoutine=[^}]+;',
            new_kat_effect_start,
            c
        )
        print("  Updated window.returnToStartMenu and window.startSharedOnlineCompetition in Kat")

    # 2. In Kat's global msg listener: ensure PLAYER_LEFT sets isDayStarted: false
    old_player_left_storage = 'if (data.type === "PLAYER_LEFT") {'
    new_player_left_storage = '''if (data.type === "PLAYER_LEFT") {
              setOppState(null);
              setIsMultiplayerOpen(!1);
              p(!1);
              is(!1);
              we(!1);
              Js(!1);
              setIsDecisionOpen(!1);
              l(pe => ({ ...pe, isDayStarted: !1 }));
              u(!0);
            }'''
    if old_player_left_storage in c:
        c = re.sub(
            r'if\s*\(\s*data\.type\s*===\s*"PLAYER_LEFT"\s*\)\s*\{[^}]+\}',
            new_player_left_storage,
            c
        )
        print("  Updated global storage listener for PLAYER_LEFT")

    # 3. In OnlineMultiplayerModal: Add prominent Exit Online Button
    # Look for the modal footer / header to add "🚪 الخروج من الأونلاين والعودة لطور الأوفلاين"
    old_modal_header_close = 's.jsx("button", { onClick: onClose, className: "p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors", children: s.jsx(ps, { className: "w-5 h-5" }) })'
    new_modal_header_close = 's.jsx("button", { onClick: handleLeaveRoom, className: "px-3 py-1.5 rounded-xl bg-rose-900/60 hover:bg-rose-800 border border-rose-500/50 text-rose-200 font-bold text-xs transition-all flex items-center gap-1.5 shadow-md", title: "الخروج من الأونلاين والعودة للأوفلاين", children: [s.jsx("span", { children: "🚪 خروج من الأونلاين" })] })'
    if old_modal_header_close in c:
        c = c.replace(old_modal_header_close, new_modal_header_close)
        print("  Added dedicated Exit Online button in OnlineMultiplayerModal header")

    # 4. In OnlineMultiplayerModal: update handleLeaveRoom to reset isDayStarted
    old_leave_room = 'const handleLeaveRoom = () => {'
    new_leave_room = '''const handleLeaveRoom = () => {
      try { broadcast({ type: "PLAYER_LEFT" }); } catch(e) {}
      if (typeof window.updateOpponentState === "function") window.updateOpponentState(null);
      if (typeof window.returnToStartMenu === "function") window.returnToStartMenu();
      onClose();
    };'''
    if old_leave_room in c:
        c = re.sub(r'const handleLeaveRoom\s*=\s*\(\)\s*=>\s*\{[^}]+\};', new_leave_room, c)
        print("  Updated handleLeaveRoom")

    # 5. In StartMenu: make sure both Offline Mode button and Online Mode button are clearly rendered
    # In Kat where StartMenu is rendered, ensure onStartMorningRoutine resets and runs the 5 steps for Offline
    # And onOpenOnlineMultiplayer runs Online
    with open(path, "w") as f:
        f.write(c)

    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check!")
    else:
        print(f"  ERROR: {path} syntax error:\n{res.stderr[:400]}")
        exit(1)

# Update index.html cache buster timestamp
with open("index.html", "r") as f:
    h = f.read()

ts = int(time.time())
h = re.sub(r'app-bundle\.js\?v=[^\"]+', f'app-bundle.js?v={ts}', h)
h = re.sub(r'app-bundle\.css\?v=[^\"]+', f'app-bundle.css?v={ts}', h)

with open("index.html", "w") as f:
    f.write(h)

print(f"\nUpdated index.html cache buster to ?v={ts}!")
print("Done!")
