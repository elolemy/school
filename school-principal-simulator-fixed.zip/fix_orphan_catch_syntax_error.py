import re

print("Fixing orphan catch syntax error in both bundles...")

broken_pattern = r'c\("desk"\)\}catch\{\}i\.currentDay===1&&!ae\?\([^\)]+\):\([^\)]+\),c\("desk"\)'

clean_replacement = 'c("desk")'

for target_file in ["assets/app-bundle.js", "public/assets/app-bundle.js"]:
    print(f"Cleaning {target_file}...")
    with open(target_file, "r") as f:
        code = f.read()

    code = re.sub(broken_pattern, clean_replacement, code)

    # Also check for any standalone "}catch{}" leftover near morning routine
    code = code.replace('c("desk")}catch{}', 'c("desk")}')

    with open(target_file, "w") as f:
        f.write(code)

print("Orphan catch syntax error fixed successfully!")
