import re
import subprocess

print("Updating student count to 4 daily and fixing Day 2 regulations...")

for path in ["assets/app-bundle.js", "public/assets/app-bundle.js"]:
    print(f"Processing {path}...")
    with open(path, "r", encoding="utf-8") as f:
        c = f.read()

    # 1. Day 2 mandatoryDocuments fix:
    c = c.replace(
        'name:"نسبة النجاح العامة 75% فما فوق",nameEn:"Minimum 75% Academic Score",description:"تحقيق 75% كحد أدنى في المجموع التراكمي.",descriptionEn:"Achieve at least 75% in the weighted subject scores."',
        'name:"الحد الأدنى لدرجات المواد التخصصية 75% فأعلى",nameEn:"Specialization Subject Cutoff 75%+",description:"اجتياز المواد التخصصية الأساسية بنسبة لا تقل عن 75%.",descriptionEn:"Passing core specialization subjects at minimum 75%."'
    )

    # 2. Ensure 4 students in $E calls and definition:
    c = c.replace('const a=e??(r==="hard"?5:r==="easy"?3:4)', 'const a=e??4')
    c = re.sub(r'\(r==="hard"\?5:r==="easy"\?3:4\)', '4', c)
    c = re.sub(r'[a-zA-Z_\$]+\.difficulty\s*===\s*"hard"\s*\?\s*5\s*:\s*[a-zA-Z_\$]+\.difficulty\s*===\s*"easy"\s*\?\s*3\s*:\s*4', '4', c)
    c = re.sub(r'difficulty\s*===\s*"hard"\s*\?\s*5\s*:\s*difficulty\s*===\s*"easy"\s*\?\s*3\s*:\s*4', '4', c)

    with open(path, "w", encoding="utf-8") as f:
        f.write(c)

    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check!")
    else:
        print(f"  ERROR: {path} syntax error:\n{res.stderr[:400]}")
        exit(1)

# Also update sync_public_bundle.py
with open("sync_public_bundle.py", "r", encoding="utf-8") as f:
    sb = f.read()

sb = sb.replace('i.difficulty==="hard"?5:i.difficulty==="easy"?3:4', '4')
sb = sb.replace(
    'name:"نسبة النجاح العامة 75% فما فوق",nameEn:"Minimum 75% Academic Score",description:"تحقيق 75% كحد أدنى في المجموع التراكمي.",descriptionEn:"Achieve at least 75% in the weighted subject scores."',
    'name:"الحد الأدنى لدرجات المواد التخصصية 75% فأعلى",nameEn:"Specialization Subject Cutoff 75%+",description:"اجتياز المواد التخصصية الأساسية بنسبة لا تقل عن 75%.",descriptionEn:"Passing core specialization subjects at minimum 75%."'
)

with open("sync_public_bundle.py", "w", encoding="utf-8") as f:
    f.write(sb)

print("All updates applied and validated successfully!")
