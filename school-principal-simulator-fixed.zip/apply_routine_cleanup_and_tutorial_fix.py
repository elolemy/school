import subprocess

print("Updating routine logic and fixing tutorial header...")

# 1. Update public/assets/app-bundle.js and assets/app-bundle.js
for path in ["public/assets/app-bundle.js", "assets/app-bundle.js"]:
    print(f"Updating JS bundle at {path}...")
    with open(path, "r") as f:
        c = f.read()

    # Update guard definition
    old_guard = 'advanceFrom:function(s){if(this.currentStep!==s)return null;if(s==="instructions"){this.currentStep="story";return"story"}if(s==="story"){this.currentStep="regulations";return"regulations"}if(s==="regulations"){this.currentStep="decisions";return"decisions"}if(s==="decisions"){this.currentStep=null;return"done"}return null}'
    new_guard = 'advanceFrom:function(s){if(this.currentStep!==s)return null;if(s==="instructions"){this.currentStep="story";return"story"}this.currentStep=null;return"done"}'
    if old_guard in c:
        c = c.replace(old_guard, new_guard)
        print("  Updated window.__morningRoutineGuard")
    else:
        print("  WARNING: old_guard not found exactly")

    # Update aZe onClose: remove regulations and decisions
    old_aze_onclose = 's.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1);l(pe=>({...pe,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));const next=window.__morningRoutineGuard.advanceFrom("story");if(next==="regulations"){Js(!1);p(!1);we(!0)}},currentDay:i.currentDay'
    new_aze_onclose = 's.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1);l(pe=>({...pe,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));window.__morningRoutineGuard.reset();we(!1);p(!1)},currentDay:i.currentDay'
    if old_aze_onclose in c:
        c = c.replace(old_aze_onclose, new_aze_onclose)
        print("  Updated aZe onClose (removed regulations & decisions)")
    else:
        print("  WARNING: old_aze_onclose not found exactly")

    # Update CJe onClose: just close CJe
    old_cje_onclose = 's.jsx(CJe,{isOpen:de,onClose:()=>{we(!1);const next=window.__morningRoutineGuard.advanceFrom("regulations");if(next==="decisions"){Js(!1);is(!1);p(!0)}},language:i.settings.language,isDark:vi})'
    new_cje_onclose = 's.jsx(CJe,{isOpen:de,onClose:()=>{we(!1);window.__morningRoutineGuard.reset();p(!1)},language:i.settings.language,isDark:vi})'
    if old_cje_onclose in c:
        c = c.replace(old_cje_onclose, new_cje_onclose)
        print("  Updated CJe onClose")
    else:
        print("  WARNING: old_cje_onclose not found exactly")

    # Fix sticky classes in wXe modal header and footer
    c = c.replace(
        'shrink-0 sticky top-0 z-20 tutorial-modal-header',
        'shrink-0 relative z-20 tutorial-modal-header'
    )
    c = c.replace(
        'shrink-0 sticky bottom-0 z-20 tutorial-modal-footer',
        'shrink-0 relative z-20 tutorial-modal-footer'
    )

    with open(path, "w") as f:
        f.write(c)

    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check!")
    else:
        print(f"  ERROR: {path} syntax check failed:\n{res.stderr[:400]}")
        exit(1)

# 2. Update CSS files
css_replacement = """.tutorial-modal-card {
  max-height: 85vh !important;
  display: flex !important;
  flex-direction: column !important;
  overflow: hidden !important;
  position: relative !important;
}
.tutorial-modal-header {
  flex-shrink: 0 !important;
  position: relative !important;
  top: auto !important;
  z-index: 20 !important;
  background: #020617 !important;
  border-bottom: 1px solid rgba(245, 158, 11, 0.3) !important;
  width: 100% !important;
}
.tutorial-modal-sub-header {
  flex-shrink: 0 !important;
  position: relative !important;
  z-index: 15 !important;
  background: #0f172a !important;
  border-bottom: 1px solid #1e293b !important;
  width: 100% !important;
}
.tutorial-modal-body {
  flex: 1 1 auto !important;
  overflow-y: auto !important;
  overscroll-behavior: contain !important;
  min-height: 0 !important;
  -webkit-overflow-scrolling: touch !important;
}
.tutorial-modal-footer {
  flex-shrink: 0 !important;
  position: relative !important;
  bottom: auto !important;
  z-index: 20 !important;
  background: #020617 !important;
  border-top: 1px solid #1e293b !important;
  width: 100% !important;
}"""

for css_path in ["public/assets/app-bundle.css", "assets/app-bundle.css"]:
    print(f"Updating CSS at {css_path}...")
    with open(css_path, "r") as f:
        css = f.read()

    idx = css.find(".tutorial-modal-card")
    if idx != -1:
        end_idx = css.find("}", css.find(".tutorial-modal-footer")) + 1
        css = css[:idx] + css_replacement + css[end_idx:]
    else:
        css += "\n" + css_replacement

    with open(css_path, "w") as f:
        f.write(css)
    print(f"  SUCCESS: {css_path} updated")

print("All routine and tutorial UI changes completed!")
