import subprocess

print("Completely removing all background music from the game...")

for path in ["public/assets/app-bundle.js", "assets/app-bundle.js"]:
    print(f"Updating {path}...")
    with open(path, "r") as f:
        c = f.read()

    # 1. Silencing startAdaptiveLoop
    old_loop = "startAdaptiveLoop(){if(!this.isMusicPlaying||!this.ctx)return;"
    new_loop = "startAdaptiveLoop(){this.isMusicPlaying=!1;if(this.timerId){window.clearTimeout(this.timerId);this.timerId=null}return;if(!this.isMusicPlaying||!this.ctx)return;"
    if old_loop in c:
        c = c.replace(old_loop, new_loop)
        print("  Silenced startAdaptiveLoop")

    # 2. Silencing playDynamicBeat
    old_beat = "playDynamicBeat(e){if(!this.ctx||this.musicVolume<=0)return;"
    new_beat = "playDynamicBeat(e){return;if(!this.ctx||this.musicVolume<=0)return;"
    if old_beat in c:
        c = c.replace(old_beat, new_beat)
        print("  Silenced playDynamicBeat")

    # 3. Silencing toggleMusic
    old_toggle = "toggleMusic(e){this.initContext(),e&&!this.isMusicPlaying?(this.isMusicPlaying=!0,this.startAdaptiveLoop()):!e&&this.isMusicPlaying&&(this.isMusicPlaying=!1,this.timerId&&(window.clearTimeout(this.timerId),this.timerId=null))}"
    new_toggle = "toggleMusic(e){this.isMusicPlaying=!1;if(this.timerId){window.clearTimeout(this.timerId);this.timerId=null}}"
    if old_toggle in c:
        c = c.replace(old_toggle, new_toggle)
        print("  Updated toggleMusic to never play music")

    # 4. In default settings: set musicEnabled: !1, musicVolume: 0
    c = c.replace("musicEnabled:!0,musicVolume:50", "musicEnabled:!1,musicVolume:0")
    c = c.replace("musicVolume:.35", "musicVolume:0")

    # 5. In constructor of Exe: set musicVolume: 0, isMusicPlaying: !1
    c = c.replace('ft(this,"musicVolume",.35)', 'ft(this,"musicVolume",0)')

    # 6. Silencing ambient music loop notes if any
    old_ambient = "startAmbientLoop(){if(!this.ambientEnabled||!this.isAmbientRunning||!this.ctx)return;"
    new_ambient = "startAmbientLoop(){this.isAmbientRunning=!1;return;if(!this.ambientEnabled||!this.isAmbientRunning||!this.ctx)return;"
    if old_ambient in c:
        c = c.replace(old_ambient, new_ambient)
        print("  Silenced startAmbientLoop")

    with open(path, "w") as f:
        f.write(c)

    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check!")
    else:
        print(f"  ERROR: {path} syntax error:\n{res.stderr[:400]}")
        exit(1)

print("Music completely removed successfully!")
