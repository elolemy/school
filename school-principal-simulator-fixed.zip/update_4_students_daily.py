import re
import subprocess

print("Setting student count to exactly 4 students every day...")

for path in ["assets/app-bundle.js", "public/assets/app-bundle.js"]:
    print(f"\nProcessing {path}...")
    with open(path, "r", encoding="utf-8") as f:
        c = f.read()

    # 1. Update function $E definition: const a=e??(r==="hard"?5:r==="easy"?3:4) -> const a=e??4
    c = re.sub(
        r'function \$E\(([^)]+)\)\s*\{([^}]*?)const a=e\?\?\([^)]+\);',
        r'function $E(\1){\2const a=e??4;',
        c
    )
    # Also handle alternate formatting if any
    c = c.replace('const a=e??(r==="hard"?5:r==="easy"?3:4)', 'const a=e??4')

    # 2. Replace all ternary queue size calls:
    # e.g. difficulty==="hard"?5:difficulty==="easy"?3:4 -> 4
    c = re.sub(
        r'(?:i|pe|gt|ae)\.difficulty\s*===\s*"hard"\s*\?\s*5\s*:\s*(?:i|pe|gt|ae)\.difficulty\s*===\s*"easy"\s*\?\s*3\s*:\s*4',
        '4',
        c
    )
    c = re.sub(
        r'r\s*===\s*"hard"\s*\?\s*5\s*:\s*r\s*===\s*"easy"\s*\?\s*3\s*:\s*4',
        '4',
        c
    )
    # Generic replacement for any difficulty hard/easy ternary for queue size (5, 3, 4)
    c = re.sub(
        r'[a-zA-Z_\$]+\.difficulty\s*===\s*"hard"\s*\?\s*5\s*:\s*[a-zA-Z_\$]+\.difficulty\s*===\s*"easy"\s*\?\s*3\s*:\s*4',
        '4',
        c
    )
    c = re.sub(
        r'difficulty\s*===\s*"hard"\s*\?\s*5\s*:\s*difficulty\s*===\s*"easy"\s*\?\s*3\s*:\s*4',
        '4',
        c
    )

    with open(path, "w", encoding="utf-8") as f:
        f.write(c)

    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check!")
    else:
        print(f"  ERROR: {path} syntax error:\n{res.stderr[:400]}")
        exit(1)

print("\nSuccessfully updated student count to 4 students every day!")
