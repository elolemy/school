import re

print("Applying fix for morning sequence and isolated regulations guide...")

with open("assets/app-bundle.js", "r") as f:
    code = f.read()

# 1. Fix wXe closing functions (h, u, p) to always invoke e() without blocking conditions
# Find wXe definition
idx_wxe = code.find("wXe=({")
if idx_wxe != -1:
    idx_end_wxe = code.find("NXe=({", idx_wxe)
    wxe_snippet = code[idx_wxe:idx_end_wxe]
    
    # Replace h=()=>{if(I.playAchievementFanfare(),l)...}
    wxe_snippet_new = re.sub(
        r'h=\(\)=>\{if\(I\.playAchievementFanfare\(\),l\)try\{localStorage\.setItem\("school_tutorial_completed","true"\)\}catch\{\}e\(\)\};',
        r'h=()=>{I.playAchievementFanfare();try{localStorage.setItem("school_tutorial_completed","true")}catch{}e()};',
        wxe_snippet
    )
    
    # Make sure u also calls e() on last page
    wxe_snippet_new = re.sub(
        r'u=\(\)=>\{I\.playPaperSlide\(\),n<c\.length-1\?i\(n\+1\):h\(\)\}',
        r'u=()=>{I.playPaperSlide(),n<c.length-1?i(n+1):(I.playAchievementFanfare(),e())}',
        wxe_snippet_new
    )
    
    # Update last step button text in wXe
    wxe_snippet_new = wxe_snippet_new.replace(
        'n===c.length-1?a?"الانتقال إلى لوائح اليوم ✍️":"Proceed to Daily Regulations ✍️":a?"التالي":"Next"',
        'n===c.length-1?a?"الانتقال إلى قصة اليوم 📖":"Proceed to Daily Story 📖":a?"التالي":"Next"'
    )
    
    code = code[:idx_wxe] + wxe_snippet_new + code[idx_end_wxe:]
    print("✓ Successfully updated wXe internal handlers and button text")

# 2. Update onStartGame and onStartMorningRoutine in SJe in Kat
# Let's inspect where SJe is called in Kat
sje_call = code.find("d&&s.jsx(SJe")
if sje_call != -1:
    sje_call_end = code.find("m&&!d&&s.jsx(JDe", sje_call)
    sje_call_snippet = code[sje_call:sje_call_end]
    
    # Replace onStartGame & onStartMorningRoutine
    new_sje_call_snippet = re.sub(
        r'onStartGame:\(\)=>\{.+?c\("desk"\)\}',
        r'onStartGame:()=>{I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)})),u(!1),p(!1),is(!1),we(!1),setRnStep("tutorial"),Js(!0),c("desk")}',
        sje_call_snippet
    )
    new_sje_call_snippet = re.sub(
        r'onStartMorningRoutine:\(\)=>\{.+?c\("desk"\)\}',
        r'onStartMorningRoutine:()=>{I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)})),u(!1),p(!1),is(!1),we(!1),setRnStep("tutorial"),Js(!0),c("desk")}',
        new_sje_call_snippet
    )
    code = code[:sje_call] + new_sje_call_snippet + code[sje_call_end:]
    print("✓ Successfully updated onStartGame and onStartMorningRoutine in Kat")

# 3. Update all isolated openers for rulebook (onOpenDailyRegulations & onOpenRulebook) to set setRnStep(null)
code = code.replace('onOpenDailyRegulations:()=>we(!0)', 'onOpenDailyRegulations:()=>{setRnStep(null);we(!0)}')
code = code.replace('onOpenRulebook:()=>we(!0)', 'onOpenRulebook:()=>{setRnStep(null);we(!0)}')
print("✓ Updated onOpenDailyRegulations and onOpenRulebook to clear rnStep")

# 4. Check wXe, aZe, CJe in Kat to ensure sequence chaining
# wXe:
code = re.sub(
    r's\.jsx\(wXe,\{isOpen:fr,onClose:\(\)=>\{.+?\},language:i\.settings\.language\}\)',
    r's.jsx(wXe,{isOpen:fr,onClose:()=>{Js(!1);try{localStorage.setItem("school_tutorial_completed","true")}catch{}if(rnStep==="tutorial"){setRnStep("story"),is(!0)}},language:i.settings.language})',
    code
)

# aZe:
code = re.sub(
    r's\.jsx\(aZe,\{isOpen:ms,onClose:\(\)=>\{.+?\},currentDay:i\.currentDay',
    r's.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1),l(pe=>({...pe,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));if(rnStep==="story"){setRnStep("regulations"),we(!0)}},currentDay:i.currentDay',
    code
)

# CJe:
code = re.sub(
    r's\.jsx\(CJe,\{isOpen:de,onClose:\(\)=>\{.+?\},language:i\.settings\.language,isDark:vi\}\)',
    r's.jsx(CJe,{isOpen:de,onClose:()=>{we(!1);if(rnStep==="regulations"){setRnStep(null),p(!0)}},language:i.settings.language,isDark:vi})',
    code
)

with open("assets/app-bundle.js", "w") as f:
    f.write(code)

print("Finished applying all updates.")
