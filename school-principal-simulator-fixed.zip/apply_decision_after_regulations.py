import subprocess
import re
import time

print("Adding Executive Decision Modal (XDe) right after Day 1 Regulations...")

for path in ["assets/app-bundle.js", "public/assets/app-bundle.js"]:
    print(f"\nProcessing {path}...")
    with open(path, "r") as f:
        c = f.read()

    # 1. In Kat, add `const [isDecisionOpen, setIsDecisionOpen] = v.useState(false);`
    if 'const [isDecisionOpen, setIsDecisionOpen]' not in c:
        c = c.replace(
            'const[isMultiplayerOpen,setIsMultiplayerOpen]=v.useState',
            'const[isDecisionOpen,setIsDecisionOpen]=v.useState(!1);const[isMultiplayerOpen,setIsMultiplayerOpen]=v.useState'
        )
        print("  Added isDecisionOpen state to Kat")

    # 2. In onStartGame in Kat: ensure `setIsDecisionOpen(false)`
    c = c.replace('window.__morningRoutineStep=null;c("desk")', 'window.__morningRoutineStep=null;setIsDecisionOpen(!1);c("desk")')

    # 3. In JDe onStartDay prop in Kat:
    # Instead of entering desk directly, open decision modal:
    old_jde_onstart = 'm&&s.jsx(JDe,{state:i,event:i.currentEvent,language:i.settings.language,onStartDay:()=>{p(!1);u(!1);is(!1);we(!1);Js(!1);window.__morningRoutineStep=null;I.playSchoolBell();l(ae=>({...ae,isDayStarted:!0,currentDailyQueue:(ae.currentDailyQueue&&ae.currentDailyQueue.length>0)?ae.currentDailyQueue:$E(ae.currentDay||1,ae.difficulty==="hard"?5:ae.difficulty==="easy"?3:4,ae.difficulty||"medium")}));c("desk")}'
    new_jde_onstart = 'm&&s.jsx(JDe,{state:i,event:i.currentEvent,language:i.settings.language,onStartDay:()=>{p(!1);u(!1);is(!1);we(!1);Js(!1);window.__morningRoutineStep=null;if(i.currentEvent){setIsDecisionOpen(!0)}else{I.playSchoolBell();l(ae=>({...ae,isDayStarted:!0,currentDailyQueue:(ae.currentDailyQueue&&ae.currentDailyQueue.length>0)?ae.currentDailyQueue:$E(ae.currentDay||1,ae.difficulty==="hard"?5:ae.difficulty==="easy"?3:4,ae.difficulty||"medium")}));c("desk")}}}'

    if old_jde_onstart in c:
        c = c.replace(old_jde_onstart, new_jde_onstart)
        print("  Updated JDe onStartDay to transition to isDecisionOpen")
    else:
        print("  Trying regex for JDe onStartDay...")
        c = re.sub(
            r'm&&s\.jsx\(JDe,\{state:i,event:i\.currentEvent,language:i\.settings\.language,onStartDay:\(\)=>\{[^\}]+\}\}',
            new_jde_onstart,
            c
        )
        print("  Regex replaced JDe onStartDay")

    # 4. Render XDe when isDecisionOpen is true:
    # Place it right after JDe render:
    old_jde_full = new_jde_onstart + ')'
    new_jde_full = new_jde_onstart + '),isDecisionOpen&&i.currentEvent&&s.jsx(XDe,{event:i.currentEvent,language:i.settings.language,onMakeChoice:ae=>{setIsDecisionOpen(!1);lc(ae);I.playSchoolBell();l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:(pe.currentDailyQueue&&pe.currentDailyQueue.length>0)?pe.currentDailyQueue:$E(pe.currentDay||1,pe.difficulty==="hard"?5:pe.difficulty==="easy"?3:4,pe.difficulty||"medium")}));c("desk")}})'
    
    if old_jde_full in c:
        c = c.replace(old_jde_full, new_jde_full)
        print("  Rendered XDe when isDecisionOpen is true")
    else:
        print("  Warning: old_jde_full match not found, looking for alternative insertion point...")
        c = c.replace(
            new_jde_onstart,
            new_jde_onstart + ',isDecisionOpen&&i.currentEvent&&s.jsx(XDe,{event:i.currentEvent,language:i.settings.language,onMakeChoice:ae=>{setIsDecisionOpen(!1);lc(ae);I.playSchoolBell();l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:(pe.currentDailyQueue&&pe.currentDailyQueue.length>0)?pe.currentDailyQueue:$E(pe.currentDay||1,pe.difficulty==="hard"?5:pe.difficulty==="easy"?3:4,pe.difficulty||"medium")}));c("desk")}})'
        )
        print("  Inserted XDe render after JDe")

    # 5. In JDe button text, indicate progression to Executive Decision:
    old_btn_txt = 's.jsx("span",{children:i?"بدء اليوم الدراسي والدخول للمكتب ◄":"Start Academic Day & Enter Desk ◄"})'
    new_btn_txt = 's.jsx("span",{children:i?"متابعة: قرار المدير الإداري لليوم 1 ◄":"Next: Day 1 Executive Decision ◄"})'
    if old_btn_txt in c:
        c = c.replace(old_btn_txt, new_btn_txt)
        print("  Updated JDe button text to 'متابعة: قرار المدير الإداري لليوم 1 ◄'")

    with open(path, "w") as f:
        f.write(c)

    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check!")
    else:
        print(f"  ERROR: {path} syntax error:\n{res.stderr[:400]}")
        exit(1)

# Update index.html cache buster timestamp
with open("index.html", "r") as f:
    h = f.read()

ts = int(time.time())
h = re.sub(r'app-bundle\.js\?v=[^\"]+', f'app-bundle.js?v={ts}', h)
h = re.sub(r'app-bundle\.css\?v=[^\"]+', f'app-bundle.css?v={ts}', h)

with open("index.html", "w") as f:
    f.write(h)

print(f"\nUpdated index.html cache buster to ?v={ts}!")
print("Done!")
