import subprocess

print("Applying sound persistence on story restart & implementing Online Multiplayer Mode...")

for path in ["public/assets/app-bundle.js", "assets/app-bundle.js"]:
    print(f"Updating {path}...")
    with open(path, "r") as f:
        c = f.read()

    # 1. Update top of bundle: keep soundEnabled: true by default
    old_top = '_p.settings.soundEnabled=!1;_p.settings.musicEnabled=!1;_p.settings.ambientSoundEnabled=!1;_p.settings.musicVolume=0;_p.settings.ambientVolume=0;'
    new_top = '_p.settings.soundEnabled=(_p.settings.soundEnabled!==!1);_p.settings.musicEnabled=!1;_p.settings.ambientSoundEnabled=!1;_p.settings.musicVolume=0;_p.settings.ambientVolume=0;'
    if old_top in c:
        c = c.replace(old_top, new_top)
        print("  Updated bundle top: soundEnabled preserved as true")

    # 2. Update Zd default state: soundEnabled: !0 (true)
    old_zd = 'settings:{language:"ar",theme:"dark",soundEnabled:!1,musicEnabled:!1,musicVolume:0,sfxVolume:70,'
    new_zd = 'settings:{language:"ar",theme:"dark",soundEnabled:!0,musicEnabled:!1,musicVolume:0,sfxVolume:.6,'
    if old_zd in c:
        c = c.replace(old_zd, new_zd)
        print("  Updated Zd: soundEnabled default is now true")
    else:
        old_zd_alt = 'settings:{language:"ar",theme:"dark",soundEnabled:!1,'
        new_zd_alt = 'settings:{language:"ar",theme:"dark",soundEnabled:!0,'
        if old_zd_alt in c:
            c = c.replace(old_zd_alt, new_zd_alt)
            print("  Updated Zd (alt): soundEnabled default is now true")

    # 3. Update story restart handler e in Kat to preserve soundEnabled and call I.setSoundEnabled
    old_e_chunk = 'const ae=Zd(),re={...ae.settings,principalName:i.settings.principalName,'
    new_e_chunk = 'const ae=Zd(),_snd=(i.settings&&i.settings.soundEnabled!==!1),re={...ae.settings,soundEnabled:_snd,sfxVolume:(i.settings&&typeof i.settings.sfxVolume=="number"?i.settings.sfxVolume:.6),musicEnabled:!1,ambientSoundEnabled:!1,principalName:i.settings.principalName,'
    if old_e_chunk in c:
        c = c.replace(old_e_chunk, new_e_chunk)
        print("  Updated restart handler e to preserve sound settings")
    else:
        print("  WARNING: old_e_chunk not found!")

    old_e_end = 'l(pe),ri(pe,le),le&&Iy(pe,le),window.__isRestartSequence=!1'
    new_e_end = 'I.setSoundEnabled(_snd),l(pe),ri(pe,le),le&&Iy(pe,le),window.__isRestartSequence=!1'
    if old_e_end in c:
        c = c.replace(old_e_end, new_e_end)
        print("  Updated restart handler e to call I.setSoundEnabled(_snd)")
    else:
        print("  WARNING: old_e_end not found!")

    # 4. Also update pXe and xXe onRestart to preserve soundEnabled
    old_pxe = 'const ae=Zd();l(ae),ri(ae),Js(!1),p(!1),is(!1),c("desk")'
    new_pxe = 'const _snd=(i.settings&&i.settings.soundEnabled!==!1),ae=Zd();ae.settings.soundEnabled=_snd;I.setSoundEnabled(_snd);l(ae),ri(ae),Js(!1),p(!1),is(!1),c("desk")'
    if old_pxe in c:
        c = c.replace(old_pxe, new_pxe)
        print("  Updated legacy restart handlers to preserve sound")

    with open(path, "w") as f:
        f.write(c)

    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check for sound fixes!")
    else:
        print(f"  ERROR: {path} syntax error:\n{res.stderr[:400]}")
        exit(1)

print("Sound persistence fixes completed successfully!")
