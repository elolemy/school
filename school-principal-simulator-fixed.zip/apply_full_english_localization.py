import glob
import re

print("Applying 100% full English localization to WSe and all views...")

with open("assets/app-bundle.js", "r") as f:
    code = f.read()

# Replace Arabic-only strings inside WSe with bilingual versions:

# 1. Search bar placeholder and buttons
code = code.replace(
    'placeholder: "بحث في الـ 100 إضافة بالاسم أو الرقم..."',
    'placeholder: n ? "بحث في الـ 100 إضافة بالاسم أو الرقم..." : "Search 100 additions by name or #..."'
)

# 2. Filter count & Active count
code = code.replace(
    'children: ["عرض: ", filtered100.length, " إضافة"]',
    'children: [n ? "عرض: " : "Showing: ", filtered100.length, n ? " إضافة" : " additions"]'
)

code = code.replace(
    'children: ["المفعل: ", activatedIds.length, " / 100"]',
    'children: [n ? "المفعل: " : "Activated: ", activatedIds.length, " / 100"]'
)

code = code.replace(
    'children: [activatedIds.length, " / 100 مفعلة"]',
    'children: [activatedIds.length, n ? " / 100 مفعلة" : " / 100 Active"]'
)

# 3. Card active/free badges
code = code.replace(
    'children: "✓ مفعل"',
    'children: n ? "✓ مفعل" : "✓ Active"'
)

code = code.replace(
    'children: [item.cost, " ج.م"]',
    'children: [item.cost, n ? " ج.م" : " EGP"]'
)

code = code.replace(
    'children: "مجاني ✨"',
    'children: n ? "مجاني ✨" : "Free ✨"'
)

# 4. Card stats footer
code = code.replace(
    'children: ["+ ", item.rep, " سمعة | + ", item.morale, "% معنويات"]',
    'children: n ? ["+ ", item.rep, " سمعة | + ", item.morale, "% معنويات"] : ["+ ", item.rep, " Rep | + ", item.morale, "% Morale"]'
)

# 5. Court texts
code = code.replace(
    'children: "أدلة الإدانة الرسمية الموثقة:"',
    'children: n ? "أدلة الإدانة الرسمية الموثقة:" : "Official Evidence Documented:"'
)
code = code.replace(
    'children: "اعتراف الطالب وأقواله:"',
    'children: n ? "اعتراف الطالب وأقواله:" : "Student Statement & Confession:"'
)
code = code.replace(
    'children: "اختر العقوبة أو الإجراء التأديبي:"',
    'children: n ? "اختر العقوبة أو الإجراء التأديبي:" : "Select Disciplinary Action:"'
)
code = code.replace(
    'children: "إنذار رسمي واستدعاء ولي الأمر"',
    'children: n ? "إنذار رسمي واستدعاء ولي الأمر" : "Formal Warning & Summon Guardian"'
)
code = code.replace(
    'children: "فصل 3 أيام مع تكليف بخدمة المدرسة"',
    'children: n ? "فصل 3 أيام مع تكليف بخدمة المدرسة" : "3-Day Suspension & Campus Service"'
)
code = code.replace(
    'children: "العفو مع التعهد بعدم التكرار"',
    'children: n ? "العفو مع التعهد بعدم التكرار" : "Pardon with Written Pledge"'
)

# 6. CCTV texts
code = code.replace(
    'children: "بلاغ أمني عاجل بهذه الكاميرا:"',
    'children: n ? "بلاغ أمني عاجل بهذه الكاميرا:" : "Urgent Security Alert on Camera:"'
)
code = code.replace(
    'children: "الأوضاع هادئة ومستقرة تماماً بهذه الكاميرا ✅"',
    'children: n ? "الأوضاع هادئة ومستقرة تماماً بهذه الكاميرا ✅" : "Camera Area Calm & Fully Secured ✅"'
)

# 7. Phone texts
code = code.replace(
    'children: "دليل التحويلات والأرقام الداخلية:"',
    'children: n ? "دليل التحويلات والأرقام الداخلية:" : "Internal Department Extensions:"'
)
code = code.replace(
    'children: "اتصال 📞"',
    'children: n ? "اتصال 📞" : "Call 📞"'
)
code = code.replace(
    'children: "مسح ⌫"',
    'children: n ? "مسح ⌫" : "Clear ⌫"'
)

with open("assets/app-bundle.js", "w") as f:
    f.write(code)

with open("assets/index-BeRTxH1o.js", "w") as f:
    f.write(code)

for target in [
    "public/assets/app-bundle.js",
    "public/assets/index-BeRTxH1o.js",
    "dist/assets/app-bundle.js",
    "dist/assets/index-BeRTxH1o.js"
]:
    try:
        with open(target, "w") as f:
            f.write(code)
    except Exception as e:
        print(f"Could not write {target}: {e}")

for f_path in glob.glob("dist/assets/*.js"):
    if "index" in f_path or "bundle" in f_path:
        with open(f_path, "w") as f:
            f.write(code)

print("Full English localization applied successfully!")
