import subprocess

print("Applying fix for single daily decision and standalone daily regulations modal...")

for path in ["public/assets/app-bundle.js", "assets/app-bundle.js"]:
    print(f"Updating {path}...")
    with open(path, "r") as f:
        c = f.read()

    # 1. onOpenDailyRegulations explicitly sets window.__isMorningSequence = !1
    c = c.replace(
        "onOpenDailyRegulations:()=>p(!0)",
        "onOpenDailyRegulations:()=>{window.__isMorningSequence=!1;p(!0)}"
    )

    # 2. JDe onStartDay only advances to Story if window.__isMorningSequence is true
    c = c.replace(
        "onStartDay:()=>{p(!1);I.playRulebookOpen();is(!0)}",
        "onStartDay:()=>{p(!1);if(window.__isMorningSequence){window.__isMorningSequence=!1;I.playRulebookOpen();is(!0)}}"
    )

    # 3. Guard onStartGame and onStartMorningRoutine if day is already started
    old_start_game = 'onStartGame:()=>{window.__isMorningSequence=!0;I.playPaperRustle();'
    new_start_game = 'onStartGame:()=>{if(i.isDayStarted){u(!1);p(!1);is(!1);we(!1);Js(!1);c("desk");return}window.__isMorningSequence=!0;I.playPaperRustle();'

    old_start_morning = 'onStartMorningRoutine:()=>{window.__isMorningSequence=!0;I.playPaperRustle();'
    new_start_morning = 'onStartMorningRoutine:()=>{if(i.isDayStarted){u(!1);p(!1);is(!1);we(!1);Js(!1);c("desk");return}window.__isMorningSequence=!0;I.playPaperRustle();'

    if old_start_game in c:
        c = c.replace(old_start_game, new_start_game)
        print("  Added isDayStarted guard to onStartGame")
    else:
        print("  WARNING: old_start_game not found!")

    if old_start_morning in c:
        c = c.replace(old_start_morning, new_start_morning)
        print("  Added isDayStarted guard to onStartMorningRoutine")
    else:
        print("  WARNING: old_start_morning not found!")

    with open(path, "w") as f:
        f.write(c)

    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check!")
    else:
        print(f"  ERROR: {path} syntax error:\n{res.stderr[:400]}")
        exit(1)

print("All fixes applied successfully!")
