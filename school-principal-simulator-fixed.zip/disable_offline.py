import re

with open("assets/app-bundle.js", "r", encoding="utf-8") as f:
    text = f.read()

# Replace the offline event listener with an empty string or no-op
new_code = text.replace('window.addEventListener("offline",this.Ge)', '/* offline disabled */')

with open("assets/app-bundle.js", "w", encoding="utf-8") as f:
    f.write(new_code)
print("Disabled offline event listener")
