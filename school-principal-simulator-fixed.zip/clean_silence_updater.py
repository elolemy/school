import subprocess

print("Applying clean total silence and permanent music removal...")

replacements = [
    # 1. Purge localStorage on load to guarantee default muted sound and zero music
    ('try{const _st=localStorage.getItem("school_sim_game_state");',
     'try{const _st=localStorage.getItem("school_sim_game_state");if(_st){const _p=JSON.parse(_st);if(_p&&_p.settings){_p.settings.soundEnabled=!1;_p.settings.musicEnabled=!1;_p.settings.ambientSoundEnabled=!1;_p.settings.musicVolume=0;_p.settings.ambientVolume=0;localStorage.setItem("school_sim_game_state",JSON.stringify(_p))}}}catch(e){};try{const _st=localStorage.getItem("school_sim_game_state");'),

    # 2. Zd default state: soundEnabled: !1
    ('settings:{language:"ar",theme:"dark",soundEnabled:!0',
     'settings:{language:"ar",theme:"dark",soundEnabled:!1'),

    # 3. Exe constructor: isMuted: !0
    ('ft(this,"isMuted",!1)',
     'ft(this,"isMuted",!0)'),

    # 4. initContext: check isMuted immediately
    ('initContext(){try{if(!this.ctx&&typeof window<"u"){',
     'initContext(){if(this.isMuted)return;try{if(!this.ctx&&typeof window<"u"){'),

    # 5. Neutralize musical arpeggios, chords, and bells
    ('playAchievementFanfare(){if(this.initContext()',
     'playAchievementFanfare(){return;if(this.initContext()'),

    ('playUpgradeSuccess(){if(this.initContext()',
     'playUpgradeSuccess(){return;if(this.initContext()'),

    ('playInspectorAlert(){if(this.initContext()',
     'playInspectorAlert(){return;if(this.initContext()'),

    ('playSchoolBell(e=!0){if(this.initContext()',
     'playSchoolBell(e=!0){return;if(this.initContext()'),

    ('playSchoolBellStandard(){if(this.initContext()',
     'playSchoolBellStandard(){return;if(this.initContext()'),

    ('playSchoolBellFireAlarm(){if(this.initContext()',
     'playSchoolBellFireAlarm(){return;if(this.initContext()'),

    ('playSchoolBellRecess(){if(this.initContext()',
     'playSchoolBellRecess(){return;if(this.initContext()'),

    ('playChimeSuccess(){if(!this.ctx)return;',
     'playChimeSuccess(){return;if(!this.ctx)return;'),

    ('playApplePayChime(){if(this.initContext()',
     'playApplePayChime(){return;if(this.initContext()'),

    ('playDeskBell(){if(this.initContext()',
     'playDeskBell(){return;if(this.initContext()'),

    # 6. SJe mute button: when clicked, cleanly toggle and suspend audio context if muted
    ('onClick:()=>{const U=!T;n({...t,settings:{...t.settings,soundEnabled:U,musicEnabled:U}}),I.setSoundEnabled(U)},className:"p-2.5 rounded-xl bg-slate-850 hover:bg-slate-800 border border-slate-750 text-amber-300 transition-all shadow-sm",title:T?"كتم الصوت":"تشغيل الصوت"',
     'onClick:()=>{const U=!T;n({...t,settings:{...t.settings,soundEnabled:U,musicEnabled:!1,ambientSoundEnabled:!1}}),I.isMuted=!U,I.setSoundEnabled(U);if(!U&&I.ctx&&I.ctx.state!=="closed"){try{I.ctx.suspend().catch(()=>{})}catch(err){}}},className:"p-2.5 rounded-xl bg-slate-850 hover:bg-slate-800 border border-slate-750 text-amber-300 transition-all shadow-sm",title:T?"كتم الصوت (صامت)":"تشغيل المؤثرات"')
]

for path in ["public/assets/app-bundle.js", "assets/app-bundle.js"]:
    print(f"Processing {path}...")
    with open(path, "r") as f:
        c = f.read()

    for old_s, new_s in replacements:
        if old_s in c:
            c = c.replace(old_s, new_s)
        else:
            print(f"  Note: string not found: {old_s[:40]}")

    with open(path, "w") as f:
        f.write(c)

    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check!")
    else:
        print(f"  ERROR: {path} syntax error:\n{res.stderr[:400]}")
        exit(1)

print("All files updated cleanly and verified!")
