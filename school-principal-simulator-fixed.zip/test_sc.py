import subprocess

with open("inject_online_multiplayer.py") as f:
    text = f.read()

import re
m = re.search(r"script_content = \'\'\'(.*?)\'\'\'", text, re.DOTALL)
if m:
    sc = m.group(1)
    prefix = 'const React = {}; const v = React; const s = {}; const I = {};\n'
    res = subprocess.run(["node", "-c"], input=prefix + sc, text=True, capture_output=True)
    print("Standalone script_content exit:", res.returncode)
    if res.returncode != 0:
        print(res.stderr[:800])
    else:
        print("script_content is completely valid syntax!")
