import subprocess

print("Testing placing OnlineMultiplayerModal right before function Kat()...")

with open("assets/app-bundle.js", "r") as f:
    c = f.read()

from test_sc import sc

target_before_kat = "function Kat(){"
idx = c.find(target_before_kat)
print("Kat found at:", idx)

if idx != -1:
    modal_code = "\n" + sc + "\n"
    c_new = c[:idx] + modal_code + c[idx:]
    
    # 2. Add isMultiplayerOpen state to Kat
    old_state = 'useState(()=>localStorage.getItem("school_sim_active_user")),[me,Ae]=v.useState(!1),'
    new_state = 'useState(()=>localStorage.getItem("school_sim_active_user")),[me,Ae]=v.useState(!1),[isMultiplayerOpen,setIsMultiplayerOpen]=v.useState(()=>{if(typeof window!=="undefined"){const _p=new URLSearchParams(window.location.search);return _p.has("room")||_p.has("code")||_p.has("multiplayer");}return false;}),'
    if old_state in c_new:
        c_new = c_new.replace(old_state, new_state, 1)
        print("  Added isMultiplayerOpen state to Kat")
    else:
        print("  WARNING: old_state not found!")

    # 3. Add window event listener
    old_listener = 'window.addEventListener("open-eagle-stamp",rr)'
    new_listener = 'window.addEventListener("open-eagle-stamp",rr);const _hMulti=()=>setIsMultiplayerOpen(!0);window.addEventListener("open-online-multiplayer",_hMulti)'
    if old_listener in c_new:
        c_new = c_new.replace(old_listener, new_listener, 1)
        print("  Added open-online-multiplayer window event listener")
    else:
        print("  WARNING: old_listener not found!")

    # 4. Render OnlineMultiplayerModal in Kat's JSX
    old_render = 's.jsx(pO,{state:i,isOpen:!0,onClose:()=>c("desk")'
    new_render = 's.jsx(OnlineMultiplayerModal,{isOpen:isMultiplayerOpen,onClose:()=>setIsMultiplayerOpen(!1),gameState:i,onUpdateGameState:l,isArabic:i.settings.language==="ar"}),s.jsx(pO,{state:i,isOpen:!0,onClose:()=>c("desk")'
    if old_render in c_new:
        c_new = c_new.replace(old_render, new_render, 1)
        print("  Rendered OnlineMultiplayerModal in Kat")
    else:
        print("  WARNING: old_render not found!")

    # 5. Add Online button to Top Navbar right before quick actions
    old_nav = 'children:[s.jsxs("button",{id:"btn-navbar-quick-actions"'
    new_nav = 'children:[s.jsxs("button",{id:"btn-navbar-online-multiplayer",onClick:()=>{try{window.dispatchEvent(new CustomEvent("open-online-multiplayer"))}catch(e){}},className:"px-3 py-1.5 rounded-xl bg-gradient-to-r from-cyan-600 via-sky-500 to-blue-600 text-white font-black text-xs hover:from-cyan-500 hover:to-blue-500 transition-all duration-300 shadow-md shadow-cyan-500/25 ring-1 ring-cyan-400/50 flex items-center gap-1.5 hover:scale-105 active:scale-95 shrink-0",title:de==="ar"?"طور الأونلاين وتحدي المدارس المباشر":"Online Multiplayer Mode",children:[s.jsx("span",{className:"text-sm",children:"🌐"}),s.jsx("span",{children:de==="ar"?"أونلاين":"Online"}),s.jsx("span",{className:"w-2 h-2 rounded-full bg-emerald-400 animate-ping"})]}),s.jsxs("button",{id:"btn-navbar-quick-actions"'
    if old_nav in c_new:
        c_new = c_new.replace(old_nav, new_nav, 1)
        print("  Added Online button to top navbar")
    else:
        print("  WARNING: old_nav not found!")

    # 6. Add Online button to Start Menu (SJe) header buttons
    old_sje_header = 'title:E?"الإعدادات والمظهر":"Settings",children:s.jsx(w4,{className:"w-4 h-4"})})'
    new_sje_header = 'title:E?"الإعدادات والمظهر":"Settings",children:s.jsx(w4,{className:"w-4 h-4"})}),s.jsxs("button",{onClick:()=>{try{window.dispatchEvent(new CustomEvent("open-online-multiplayer"))}catch(e){}},className:"p-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 text-white border border-cyan-400/40 text-xs font-black transition-all shadow-md flex items-center gap-1.5 hover:scale-105 active:scale-95",title:E?"طور الأونلاين وغرف التحدي":"Online Multiplayer",children:[s.jsx("span",{children:"🌐"}),s.jsx("span",{className:"hidden sm:inline",children:E?"أونلاين":"Online"})]})'
    if old_sje_header in c_new:
        c_new = c_new.replace(old_sje_header, new_sje_header, 1)
        print("  Added Online button to Start Menu header")
    else:
        print("  WARNING: old_sje_header not found!")

    with open("public/assets/app-bundle.js", "w") as f:
        f.write(c_new)

    res = subprocess.run(["node", "-c", "public/assets/app-bundle.js"], capture_output=True, text=True)
    if res.returncode == 0:
        print("  SUCCESS: public/assets/app-bundle.js passed Node syntax check!")
        with open("assets/app-bundle.js", "w") as f:
            f.write(c_new)
        print("  Also updated assets/app-bundle.js!")
    else:
        print("  ERROR:\n", res.stderr[:500])
