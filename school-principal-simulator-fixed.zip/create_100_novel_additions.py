import re
import time
import glob

with open("assets/app-bundle.js", "r") as f:
    code = f.read()

pos_start = code.find("WSe=")
pos_end = code.find(";var QSe=", pos_start)
if pos_end == -1: pos_end = code.find("QSe=", pos_start)
assert pos_start != -1 and pos_end != -1, "WSe boundary not found"

new_code = '''WSe=({isOpen:t,onClose:e,gameState:r,onUpdateGameState:a,isAr:n=!0})=>{
  const [activeTab, setActiveTab] = v.useState("all");
  const [searchQuery, setSearchQuery] = v.useState("");
  const [activatedIds, setActivatedIds] = v.useState([]);
  const [lastActionMsg, setLastActionMsg] = v.useState(null);

  // 1. CCTV State
  const [selectedCam, setSelectedCam] = v.useState(1);
  const [cctvAlerts, setCctvAlerts] = v.useState([
    {id:1, cam:1, titleAr:"🚨 طالب يحاول القفز من سور الفناء الخلفي", titleEn:"Student attempting to climb back fence", severity:"high", actionAr:"إرسال الأمن فوراً", actionEn:"Dispatch Security", resolved:false, reward:300},
    {id:2, cam:2, titleAr:"🥪 زحام وتدافع أمام مقصف المدرسة في الفسحة", titleEn:"Canteen overcrowding during recess", severity:"medium", actionAr:"توجيه معلم النوبتجية", actionEn:"Send Duty Teacher", resolved:false, reward:150},
    {id:3, cam:4, titleAr:"💨 تصاعد دخان أزرق كثيف من تجربة الكيمياء", titleEn:"Blue smoke rising from chem experiment", severity:"urgent", actionAr:"تشغيل شفاطات الطوارئ", actionEn:"Emergency Exhaust", resolved:false, reward:400},
    {id:4, cam:3, titleAr:"🚗 سيارة تفتيش وزاري مفاجئة تقف أمام البوابة", titleEn:"Ministry surprise inspection car at gate", severity:"critical", actionAr:"استقبال الموجهين", actionEn:"Welcome Inspectors", resolved:false, reward:500},
    {id:5, cam:6, titleAr:"🐱 قطة بيضاء شقية دخلت ممر الفصول واحتفال الطلاب", titleEn:"Cute white kitten in classroom corridor", severity:"low", actionAr:"اعتمادها تميمة الحظ", actionEn:"Adopt as Mascot", resolved:false, reward:100}
  ]);
  const [cctvLog, setCctvLog] = v.useState([]);
  const [snapshotCount, setSnapshotCount] = v.useState(0);
  const [alarmActive, setAlarmActive] = v.useState(false);

  // 2. Disciplinary Court State
  const [activeCaseIdx, setActiveCaseIdx] = v.useState(0);
  const [verdictHistory, setVerdictHistory] = v.useState([]);
  const courtCases = [
    {
      id: "case-1",
      studentName: "يوسف مروان (الصف الثاني الثانوي)",
      studentNameEn: "Youssef Marwan (Grade 11)",
      chargeAr: "إطلاق شعاع ليزر أخضر عالي الطاقة على سبورة الرياضيات أثناء الشرح وإرباك الفصل",
      chargeEn: "Pointing high-powered laser at smart board during math class",
      evidenceAr: "قلم ليزر أخضر 5000mW + شهادة 4 طلاب + تسجيل كاميرا الممر",
      evidenceEn: "5000mW laser pointer + 4 student testimonies + corridor cam footage",
      confessionAr: "كنت أجرب انعكاس الضوء للدرس العملي ولم أقصد إزعاج الأستاذ يا فندم!",
      confessionEn: "I was just testing light reflection for practical physics!",
      witnessAr: "الأخصائي الاجتماعي: الطالب متفوق ولكنه متهور ويحتاج توجيهاً انضباطياً.",
      witnessEn: "Counselor: High-achieving student but prone to impulsive pranks."
    },
    {
      id: "case-2",
      studentName: "كريم شريف (الصف الثالث الإعدادي)",
      studentNameEn: "Kareem Sherif (Grade 9)",
      chargeAr: "إدارة متجر سري لبيع الشيبسي والعصائر المهربة داخل حقيبة الظهر بأسعار منافسة للمقصف",
      chargeEn: "Running underground backpack snack store competing with school canteen",
      evidenceAr: "حقيبة تحتوي على 20 كيس شيبسي مستورد + دفتر حسابات مالي دقيق + 450 جنيهاً أرباح",
      evidenceEn: "20 snack packs + detailed ledger book + 450 EGP cash seized",
      confessionAr: "أنا أتعلم ريادة الأعمال مبكراً وأسعار المقصف كانت مرتفعة جداً على زملائي!",
      confessionEn: "I am practicing early entrepreneurship, canteen prices were too high!",
      witnessAr: "مسؤول المقصف: الطالب تسبب في خسائر 30% لمبيعات المقصف اليومية.",
      witnessEn: "Canteen Manager: Caused 30% slump in daily canteen revenue."
    },
    {
      id: "case-3",
      studentName: "رامي خالد (الصف الأول الثانوي)",
      studentNameEn: "Ramy Khaled (Grade 10)",
      chargeAr: "محاكاة صوت جرس الفسحة بصفارة إلكترونية من شباك الطابق الثالث وتفريغ 5 فصول مبكراً",
      chargeEn: "Mimicking recess bell with audio buzzer from 3rd floor emptying 5 classes",
      evidenceAr: "جهاز صوتي إلكتروني مبرمج على تردد 440Hz + تسجيل صوتي",
      evidenceEn: "Electronic buzzer tuned to 440Hz + audio recording",
      confessionAr: "الجميع كان يشعر بالجوع الشديد وحصة التاريخ كانت طويلة جداً!",
      confessionEn: "Everyone was starving and history class felt like eternity!",
      witnessAr: "معلم التاريخ: خرج نصف الفصل للفناء قبل موعد الفسحة بعشر دقائق كاملة.",
      witnessEn: "History Teacher: Half the class stormed into the yard 10 minutes early."
    },
    {
      id: "case-4",
      studentName: "عمر سامح (الصف الثاني الإعدادي)",
      studentNameEn: "Omar Sameh (Grade 8)",
      chargeAr: "اختراق شاشة الفصل الذكية وعرض ملخص أهداف دوري أبطال أوروبا أثناء حصة الدراسات",
      chargeEn: "Streaming Champions League highlights onto interactive smartboard during class",
      evidenceAr: "فلاش ميموري + كابل بث لاسلكي مخفي خلف الشاشة",
      evidenceEn: "USB drive + wireless casting dongle hidden behind the screen",
      confessionAr: "ريال مدريد كان يلعب والأستاذ نفسه من عشاق الكرة وطلب معرفة النتيجة!",
      confessionEn: "Real Madrid was playing and the teacher is a football fanatic!",
      witnessAr: "معلم الدراسات: الطالب بارع تقنياً جداً ولكن التوقيت كان خاطئاً تماماً.",
      witnessEn: "Social Studies Teacher: Extremely talented in tech but wrong timing."
    }
  ];

  // 3. Desk Phone Intercom State
  const [dialNumber, setDialNumber] = v.useState("");
  const [callActive, setCallActive] = v.useState(false);
  const [callDetails, setCallDetails] = v.useState(null);
  const phoneBook = [
    {code:"101", deptAr:"غرفة الكنترول المركزي", deptEn:"Exam Control Hub", icon:"📊", replyAr:"أهلاً سيادة الناظر! درجات الطلاب مرصودة بنسبة 98% وجاهزة للاعتماد الفوري.", replyEn:"Hello Principal! 98% of student exam grades are processed."},
    {code:"102", deptAr:"غرفة المعلمين والاستراحة", deptEn:"Staff Lounge", icon:"☕", replyAr:"مساء الخير يا فندم! جميع المعلمين ملتزمون بجدول الحصص والتحضير مكتمل.", replyEn:"Good day! All teachers are on schedule with full lesson plans."},
    {code:"103", deptAr:"العيادة والزائرة الصحية", deptEn:"Health Clinic", icon:"🩺", replyAr:"د. منى: جميع الطلاب بصحة ممتازة وتم تطعيم 45 طالباً اليوم بدون أي مضاعفات.", replyEn:"Dr. Mona: All students are healthy, 45 vaccinations completed today."},
    {code:"104", deptAr:"أمن البوابة الرئيسية", deptEn:"Main Gate Security", icon:"🚪", replyAr:"عم فرج: البوابة مغلقة بإحكام ولا يسمح بدخول أي غريب بدون بطاقة الرقم القومي.", replyEn:"Farag: Gate is fully secured, no visitors allowed without national ID."},
    {code:"105", deptAr:"مقصف وتغذية المدرسة", deptEn:"Canteen & Nutrition", icon:"🥪", replyAr:"الشيف حسن: الوجبات طازجة 100% والفطائر الساخنة جاهزة للتوزيع بالفسحة.", replyEn:"Chef Hassan: Fresh meals ready, hot pastries prepped for recess."},
    {code:"106", deptAr:"مكتب مدير الإدارة التعليمية", deptEn:"Ministry District Director", icon:"🏛️", replyAr:"سعادتك! مدرستكم نموذجية ونتابع إنجازاتكم بكل فخر ودعم كامل من الوزارة.", replyEn:"Director: Your school is exemplary, full support from the Ministry!"},
    {code:"000", deptAr:"بوفيه مكتب الناظر (عم إبراهيم)", deptEn:"Principal Office Tea Master", icon:"🍵", replyAr:"أحلى كباية شاي خمسينة في حب مصر مظبوطة بالنعناع في ثواني يا باشا!", replyEn:"The finest mint tea is on its way to your desk right now, Sir!"},
    {code:"999", deptAr:"طوارئ الانضباط والنجدة المدرسية", deptEn:"School Discipline SWAT", icon:"🚨", replyAr:"فرقة الانضباط في حالة تأهب قصوى وجاهزة للتدخل السريع لضبط أي مخالفة.", replyEn:"Discipline squad on high alert ready for instant intervention."},
    {code:"777", deptAr:"رقم الحظ والمكافأة الذهبية", deptEn:"Golden Fortune Hotline", icon:"🍀", replyAr:"مبروك! اتصالك بالرقم الذهبي يمنح مدرستك منحة 500 جنيه لدعم الأنشطة!", replyEn:"Jackpot! Dialing 777 grants your school a 500 EGP activity bonus!", bonus:500}
  ];

  // 100 GRAND NOVEL ADDITIONS (20 Gadgets + 20 Secrets + 20 Decrees + 20 Trophies + 20 Festivals)
  const grand100List = [
    // --- CATEGORY 1: 20 DESK GADGETS & OFFICE INTERACTIVES (1 - 20) ---
    {num:1, cat:"gadgets", icon:"🕵️", titleAr:"جهاز كشف الكذب الصوتي للطلاب وأولياء الأمور", titleEn:"Voice-Stress Student Lie Detector", descAr:"يحلل نبرات الصوت والترددات لتحديد صحة الأعذار الغيابية واختلاق التبريرات بدقة 99%.", rewardAr:"+15 كفاءة تحقيق", cost:0, rep:5, morale:5, effect:"lie_detect"},
    {num:2, cat:"gadgets", icon:"⚖️", titleAr:"ميزان العدل الذهبي لفض نزاعات المعلمين والطلاب", titleEn:"Golden Scales of Justice Arbiter", descAr:"ميزان نحاسي كلاسيكي يزن الحجج والبراهين بمؤشر هيدروليكي عادل.", rewardAr:"+20 انضباط مدرسي", cost:0, rep:8, morale:10, effect:"justice"},
    {num:3, cat:"gadgets", icon:"🔮", titleAr:"كرة التنبؤ والتوقع الأكاديمي لمستقبل المدرسة", titleEn:"Mystic Academic Future Orb", descAr:"كرة زجاجية بلورية تومض بألوان الطيف وتتوقع نسب نجاح الثانوية العامة والتفتيش القادم.", rewardAr:"+12 بصيرة إدارية", cost:0, rep:6, morale:8, effect:"crystal_orb"},
    {num:4, cat:"gadgets", icon:"☕", titleAr:"ماكينة الإسبريسو والقهوة التركية على الرمل الساخن", titleEn:"Sand-Brewed Ottoman Turkish Coffee Hub", descAr:"تحضير فنجان قهوة تركي بوش سميك ومضبوط بالحبهان لشحذ تركيز المدير وطرد الإرهاق.", rewardAr:"-50% إجهاد المدير", cost:0, rep:5, morale:15, effect:"coffee"},
    {num:5, cat:"gadgets", icon:"📻", titleAr:"راديو الترانزستور العتيق لبرنامج إذاعة القرآن وصوت العرب", titleEn:"Vintage Transistor Wood Radio 1970", descAr:"يبث تسجيلات إذاعية نادرة ونشرات الأخبار القديمة مع صوت تشويش الإبرة التناظري.", rewardAr:"+10 هدوء وسكينة", cost:0, rep:4, morale:12, effect:"radio"},
    {num:6, cat:"gadgets", icon:"🖲️", titleAr:"زر الطوارئ الأحمر الكبير للتفريغ الأمني الفوري", titleEn:"Master Red Emergency Yard Buzzer", descAr:"زر أحمر هيدروليكي محمي بغطاء زجاجي لإطلاق نداء الطوارئ الموحد بضغطة واحدة.", rewardAr:"+100 ردع أمني", cost:0, rep:10, morale:5, effect:"alarm_button"},
    {num:7, cat:"gadgets", icon:"🖋️", titleAr:"قلم الريشة المذهب المغموس في الحبر الملكي الأزرق", titleEn:"Royal 24k Gold Feather Dip Pen", descAr:"توقيع قرارات التعيين والشهادات الشرفية بخط ديواني أصيل وختم شمعي أحمر.", rewardAr:"+25 فخامة وهيبة", cost:0, rep:15, morale:10, effect:"feather_pen"},
    {num:8, cat:"gadgets", icon:"🪓", titleAr:"مطرقة القاضي العاجية لفض الخلافات بمكتب الناظر", titleEn:"Ivory Gavel of Final Executive Ruling", descAr:"طرقات حاسمة على القاعدة الخشبية تنهي أي نقاش فوضوي وتفرض الصمت الفوري.", rewardAr:"+15 حسم وسيطرة", cost:0, rep:10, morale:8, effect:"gavel"},
    {num:9, cat:"gadgets", icon:"🧲", titleAr:"بندول نيوتن المغناطيسي للتأمل والتفكير الاستراتيجي", titleEn:"Newton Kinetic Executive Desktop Cradle", descAr:"كرات فولاذية تتصادم بإيقاع منتظم مهدئ للأعصاب يرفع من دقة اتخاذ القرارات المعقدة.", rewardAr:"+8 تركيز ذهني", cost:0, rep:6, morale:10, effect:"newton"},
    {num:10, cat:"gadgets", icon:"🔍", titleAr:"عدسة التكبير الجنائية المضيئة لكشف تزوير التواقيع", titleEn:"Illuminated Forensic Signature Magnifier", descAr:"عدسة زجاجية بضوء UV تكشف تزوير توقيعات أولياء الأمور وكشط درجات الشهادات.", rewardAr:"+18 كشف تزوير", cost:0, rep:12, morale:6, effect:"uv_lens"},
    {num:11, cat:"gadgets", icon:"⏳", titleAr:"ساعة رملية زجاجية عملاقة لإدارة وقت الاجتماعات الصعبة", titleEn:"Hourglass 15-Minute Executive Timer", descAr:"حبيبات رمل ذهبية تنهمر لتقييد وقت شكاوى أولياء الأمور إلى 15 دقيقة كحد أقصى.", rewardAr:"+15 تنظيم وقت", cost:0, rep:8, morale:10, effect:"hourglass"},
    {num:12, cat:"gadgets", icon:"🦜", titleAr:"ببغاء الدرة المتكلم المساعد الذكي لمكتب المدير", titleEn:"Talking Green Office Mascot Parrot", descAr:"يردد عبارات: (الهدوء يا بني! - تحيا مصر! - أين ولي أمرك؟) ويثير البهجة بين الزوار.", rewardAr:"+20 روح معنوية", cost:0, rep:10, morale:25, effect:"parrot"},
    {num:13, cat:"gadgets", icon:"🔒", titleAr:"خزينة المخطوطات السرية بقفل رقمي سري ثلاثي", titleEn:"Triple-Dial Classified Dossier Safe", descAr:"خزانة مصفحة من الفولاذ المقاوم للحريق لحفظ امتحانات الثانوية العامة قبل موعدها.", rewardAr:"+30 سرية مطلقة", cost:0, rep:20, morale:10, effect:"safe"},
    {num:14, cat:"gadgets", icon:"🔭", titleAr:"تلسكوب النحاس البحري لمراقبة سطح المدرسة والمدخنة", titleEn:"Brass Marine Courtyard Telescope", descAr:"منظار بصري طويل المدى لرصد حركة طيور الحمام فوق الأسطح ومتابعة طابور الصباح.", rewardAr:"+12 كشف ميداني", cost:0, rep:8, morale:6, effect:"telescope"},
    {num:15, cat:"gadgets", icon:"🎯", titleAr:"لوحة الرماية بالسهام المغناطيسية لتفريغ التوتر", titleEn:"Magnetic Dartboard Stress Buster", descAr:"رمي السهام على لوحة الأهداف لتفريغ ضغط العمل بعد لجان التفتيش الوزاري.", rewardAr:"-40% توتر إداري", cost:0, rep:5, morale:20, effect:"darts"},
    {num:16, cat:"gadgets", icon:"🖨️", titleAr:"طابعة بطاقات الهوية البلاستيكية الحرارية الفورية", titleEn:"Thermal PVC ID Card Instant Embosser", descAr:"طباعة كارنيهات الطلاب والمعلمين في 10 ثوانٍ بشريط مغناطيسي وصورة ليزرية.", rewardAr:"+15 سرعة إدارية", cost:0, rep:12, morale:10, effect:"id_printer"},
    {num:17, cat:"gadgets", icon:"🔔", titleAr:"جرس نحاسي يدوي كلاسيكي للإعلان عن القرارات الكبرى", titleEn:"Hand-Cast Brass Principal Call Bell", descAr:"رنين نحاسي نقي يتردد صداه في بهو الإدارة لجمع رؤساء الأقسام والمعلمين فوراً.", rewardAr:"+10 استجابة فورية", cost:0, rep:8, morale:8, effect:"brass_bell"},
    {num:18, cat:"gadgets", icon:"🗂️", titleAr:"منظم الملفات الدوار الآلي فائق السرعة (Rotary Carousel)", titleEn:"Motorized Rotary File Dossier Carousel", descAr:"أرشيف دوار يستدعي ملف أي طالب من بين 5000 ملف بضغطة زر ورقم الجلوس.", rewardAr:"+22 كفاءة أرشفة", cost:0, rep:15, morale:12, effect:"carousel"},
    {num:19, cat:"gadgets", icon:"📡", titleAr:"موجّه الإشارات اللاسلكية المشفرة لحراس البوابات", titleEn:"Encrypted Walkie-Talkie Command Base", descAr:"محطة إرسال لاسلكية مركزية للتواصل الفوري مع أفراد الأمن في أركان الحرم الأربعة.", rewardAr:"+25 أمان وسيطرة", cost:0, rep:16, morale:10, effect:"walkie"},
    {num:20, cat:"gadgets", icon:"🎰", titleAr:"عجلة الحظ والجوائز الصباحية لطابور الإذاعة المدرسية", titleEn:"Morning Assembly Golden Fortune Wheel", descAr:"تدوير العجلة أمام الطلاب في الطابور لمنح مكافآت وجوائز فورية للمتفوقين.", rewardAr:"+35 فرحة طلابية", cost:0, rep:25, morale:30, effect:"fortune_wheel"},

    // --- CATEGORY 2: 20 CAMPUS SECRETS & STUDENT LORE QUESTS (21 - 40) ---
    {num:21, cat:"secrets", icon:"🗺️", titleAr:"خريطة النفق السري القديم الممتد أسفل مسرح المدرسة", titleEn:"Old Secret Tunnel Under Main Stage", descAr:"نفق تاريخي بُني عام 1940 يربط مسرح المدرسة بالمكتبة المركزية القديمة.", rewardAr:"+300 ج.م + كنز أثري", cost:0, rep:15, morale:20, effect:"quest_tunnel"},
    {num:22, cat:"secrets", icon:"🗝️", titleAr:"المفتاح الصدئ لغرفة كؤوس وبطولات الثمانينات المفقودة", titleEn:"Rusty Key to Forgotten 1980s Trophy Vault", descAr:"غرفة مغلقة من 40 عاماً تحتوي على دروع وبطولات الجمهورية المنسية وكؤوس مذهبة.", rewardAr:"+400 ج.م + كؤوس ذهبية", cost:0, rep:25, morale:25, effect:"quest_trophy_vault"},
    {num:23, cat:"secrets", icon:"📜", titleAr:"مخطوطة قصيدة نشيد المدرسة الأصلي المفقود منذ 1965", titleEn:"Original 1965 Hand-Written School Anthem", descAr:"كلمات وألحان النشيد التأسيسي للمدرسة موقعة من رواد التعليم الأوائل.", rewardAr:"+35 سمعة تراثية", cost:0, rep:35, morale:30, effect:"quest_anthem"},
    {num:24, cat:"secrets", icon:"🔭", titleAr:"مرصد الفلك السري ونادي مراقبة الكواكب الليلي بالسطح", titleEn:"Rooftop Midnight Stargazer Observatory", descAr:"تلسكوب عاكس ضخم ركبه نادي العلوم القديم لرصد حلقات زحل وقمر المشتري.", rewardAr:"+20 تفوق علمي", cost:0, rep:20, morale:22, effect:"quest_stars"},
    {num:25, cat:"secrets", icon:"📻", titleAr:"شفرة مورس السرية في نغمات جرس المدرسة الصباحي", titleEn:"Secret Morse Code Hidden in School Chime", descAr:"نغمة خفية وضعها أستاذ الفيزياء القديم تهنئ المتفوقين وتبث الأمل.", rewardAr:"+15 ذكاء طلابي", cost:0, rep:18, morale:18, effect:"quest_morse"},
    {num:26, cat:"secrets", icon:"🌳", titleAr:"شجرة السدرة العتيقة الحافظة لرسائل وأمنيات الطلاب", titleEn:"Ancient Wish Tree of Student Dreams", descAr:"صندوق خشبي مخفي في تجويف الشجرة يحتوي على أحلام الطلاب منذ نصف قرن.", rewardAr:"+25 تعاطف وألفة", cost:0, rep:20, morale:35, effect:"quest_wish_tree"},
    {num:27, cat:"secrets", icon:"🧪", titleAr:"معادلة الحبر السري لكتابة الرسائل التقديرية الفخرية", titleEn:"Alchemical Invisible Ink Formula", descAr:"تركيبة نباتية تظهر الكتابة فقط عند تعريض الورقة لحرارة مصباح المكتب.", rewardAr:"+18 ابتكار علمي", cost:0, rep:15, morale:15, effect:"quest_secret_ink"},
    {num:28, cat:"secrets", icon:"🏆", titleAr:"لغز كأس الدوري المدرسي الذهبي المسروق عام 1999", titleEn:"The Missing 1999 Golden Football Cup", descAr:"حل اللغز واستعادة الكأس بعد العثور عليه مخبأ في مخزن الأنشطة القديم.", rewardAr:"+500 ج.م استرداد", cost:0, rep:30, morale:40, effect:"quest_missing_cup"},
    {num:29, cat:"secrets", icon:"♟️", titleAr:"رقعة الشطرنج الرخامية ذات المربعات السرية المتحركة", titleEn:"Marble Chessboard with Hidden Compartment", descAr:"تحريك الحصان إلى مربع E4 يفتح درباً سرياً يحتوي على قطع شطرنج عاجية نادرة.", rewardAr:"+22 دهاء استراتيجي", cost:0, rep:18, morale:20, effect:"quest_chess"},
    {num:30, cat:"secrets", icon:"🏛️", titleAr:"دفتر سجل زوار المدرسة الملكي الموقع من كبار الشخصيات", titleEn:"Royal VIP School Guestbook 1950", descAr:"توقيعات تاريخية بخط اليد لعلماء وأدباء زاروا المدرسة في منتصف القرن الماضي.", rewardAr:"+40 برستيج تاريخي", cost:0, rep:40, morale:25, effect:"quest_royal_book"},
    {num:31, cat:"secrets", icon:"🎨", titleAr:"اللوحة الجدارية الزيتية ذات العينين المتحركتين بالبهو", titleEn:"Historic Hallway Oil Painting Secret", descAr:"لوحة مؤسس المدرسة التي تخفي خلف إطارها الخشبي قائمة بأوائل الدفعات السابقة.", rewardAr:"+15 كشف تراثي", cost:0, rep:15, morale:15, effect:"quest_painting"},
    {num:32, cat:"secrets", icon:"🕰️", titleAr:"ساعة البرج الميكانيكية المعطلة وصندوق تروسها البرونزي", titleEn:"Campus Bell Tower Clockwork Mechanism", descAr:"إصلاح التروس البرونزية وإعادة عقارب ساعة البرج للدوران بعد توقف 20 عاماً.", rewardAr:"+30 دقة والتزام", cost:0, rep:30, morale:25, effect:"quest_clockwork"},
    {num:33, cat:"secrets", icon:"📚", titleAr:"موسوعة المعارف النادرة المطبوعة عام 1920 بالمكتبة", titleEn:"1920 Rare Encyclopedia First Edition", descAr:"مجلد تاريخي ضخم بخرائط ملونة يدوياً كان مفقوداً في قسم المراجع النادرة.", rewardAr:"+25 ثروة علمية", cost:0, rep:25, morale:20, effect:"quest_encyclopedia"},
    {num:34, cat:"secrets", icon:"🎭", titleAr:"قناع المسرح الإغريقي الفضي الفائز بجائزة الإبداع", titleEn:"Silver Greek Comedy Theatre Mask", descAr:"قناع مسرحي كلاسيكي كان تميمة مسرح المدرسة في عصره الذهبي.", rewardAr:"+20 تميز فني", cost:0, rep:20, morale:25, effect:"quest_theatre_mask"},
    {num:35, cat:"secrets", icon:"🌱", titleAr:"بذور الزهور النادرة المزروعة في حديقة المدرسة التأسيسية", titleEn:"Founding Campus Rare Botanical Seeds", descAr:"إعادة زراعة ورود الجوري الدمشقي والياسمين البلدي في الممشى الرئيسي.", rewardAr:"+18 بهجة بصرية", cost:0, rep:15, morale:30, effect:"quest_rare_seeds"},
    {num:36, cat:"secrets", icon:"🎖️", titleAr:"ميدالية بطل السباحة والغطس لعام 1975 بالمستودع", titleEn:"1975 Gold Swimming Champion Medal", descAr:"ميدالية ذهبية خالصة باسم كابتن المدرسة السابق تسلم لأفضل سباح بالجيل الحالي.", rewardAr:"+25 حافز رياضي", cost:0, rep:20, morale:30, effect:"quest_swimming_medal"},
    {num:37, cat:"secrets", icon:"🎻", titleAr:"كمان عتيق مصنوع يدوياً من خشب الصنوبر بغرفة الموسيقى", titleEn:"Handcrafted Pine Violin in Music Loft", descAr:"آلة وترية ساحرة تعود لأول معلم موسيقى بالمدرسة تعزف أنقى النغمات الكلاسيكية.", rewardAr:"+22 تناغم وذوق", cost:0, rep:20, morale:25, effect:"quest_violin"},
    {num:38, cat:"secrets", icon:"📮", titleAr:"صندوق بريد الأفكار والاقتراحات الصامتة مجهولة المصدر", titleEn:"Anonymous Student Innovation Mailbox", descAr:"استخراج أفضل 10 أفكار إبداعية من الطلاب وتطبيقها فوراً في الفصول.", rewardAr:"+35 تطوير مدرسي", cost:0, rep:30, morale:35, effect:"quest_ideas_box"},
    {num:39, cat:"secrets", icon:"🛡️", titleAr:"درع الحراسة الخشبي التذكاري لفرقة الكشافة البحرية", titleEn:"Sea Scouts Wooden Guard Shield 1968", descAr:"درع تذكاري نُحت عليه شعار فرقة الجوالة والبحرية يمنح روح المغامرة.", rewardAr:"+20 شجاعة وانضباط", cost:0, rep:20, morale:22, effect:"quest_scout_shield"},
    {num:40, cat:"secrets", icon:"🛸", titleAr:"نموذج الصاروخ الفضائي الخشبي لمسابقة ناسا للناشئين", titleEn:"Junior NASA Wooden Scale Rocket Model", descAr:"ابتكار ميكانيكي لصاروخ متعدد المراحل فاز بالمركز الأول في مسابقة الفضاء.", rewardAr:"+30 فخر وطني", cost:0, rep:30, morale:30, effect:"quest_rocket"},

    // --- CATEGORY 3: 20 SOVEREIGN PRINCIPAL EXECUTIVE DECREES (41 - 60) ---
    {num:41, cat:"decrees", icon:"🎮", titleAr:"مرسوم إعلان يوم الألعاب والماراثون الترفيهي المفتوح", titleEn:"Decree: Campus Sports & Gaming Day", descAr:"تعليق الحصص التقليدية لمدة يوم وإقامة بطولات كرة قدم وشطرنج وألعاب إلكترونية.", rewardAr:"+50 روح معنوية للطلاب", cost:200, rep:20, morale:50, effect:"decree_gaming_day"},
    {num:42, cat:"decrees", icon:"🤫", titleAr:"قرار فرض أسبوع الصمت والتركيز الذهني الخارق", titleEn:"Decree: Silent Focus & Study Week", descAr:"منع مكبرات الصوت والتنبيهات لتهيئة أهدأ بيئة مراجعة قبل الامتحانات النهائية.", rewardAr:"+25% تركيز أكاديمي", cost:100, rep:30, morale:15, effect:"decree_silent_week"},
    {num:43, cat:"decrees", icon:"🪙", titleAr:"تدشين عملة الحرم المدرسية (شلن التميز الذهبي)", titleEn:"Decree: Campus Golden Token Currency", descAr:"إصدار عملات رمزية خاصة بالمدرسة يربحها الطلاب بالاجتهاد ويشترون بها وجبات وكتب.", rewardAr:"+40 تحفيز دراسي", cost:300, rep:35, morale:40, effect:"decree_tokens"},
    {num:44, cat:"decrees", icon:"👔", titleAr:"اعتماد الزي المدرسي الشرفي الأنيق لكبار المتفوقين", titleEn:"Decree: Blazer of Honor for Top Achievers", descAr:"منح بليزر كحلي فاخر بشارة مذهبة لأول 10 طلاب على مستوى المدرسة لارتدائه بالطابور.", rewardAr:"+30 برستيج وتنافس", cost:400, rep:35, morale:30, effect:"decree_honor_blazer"},
    {num:45, cat:"decrees", icon:"🔄", titleAr:"يوم تبادل الأدوار (الطلاب يديرون المدرسة والمعلمون يتعلمون)", titleEn:"Decree: Role Reversal Day", descAr:"طالب متفوق يجلس على كرسي الناظر ويدير اليوم الدراسي لتعلم القيادة والمسؤولية.", rewardAr:"+45 ثقة قيادية", cost:150, rep:25, morale:45, effect:"decree_role_reversal"},
    {num:46, cat:"decrees", icon:"🕊️", titleAr:"إصدار العفو الرئاسي الشامل عن الإنذارات التأديبية البسيطة", titleEn:"Decree: General Amnesty for Minor Infractions", descAr:"مسح الغيابات والإنذارات البسيطة للطلاب الذين أثبتوا تحسن سلوكهم التام في شهر رمضان.", rewardAr:"+40 محبة وتسامح", cost:0, rep:20, morale:45, effect:"decree_amnesty"},
    {num:47, cat:"decrees", icon:"🍉", titleAr:"تخصيص يوم الفواكه الطازجة والمثلجات الطبيعية بالمقصف", titleEn:"Decree: Fresh Fruit & Natural Gelato Day", descAr:"توزيع البطيخ والمانجو والعصائر الطازجة بالمجان على كافة الطلاب في يوم صيفي حار.", rewardAr:"+35 انتعاش وسعادة", cost:350, rep:25, morale:40, effect:"decree_fruit_day"},
    {num:48, cat:"decrees", icon:"🎤", titleAr:"إطلاق إذاعة صوت الطلاب الحرة والبودكاست اليومي", titleEn:"Decree: Student Voice Independent Podcast", descAr:"منح الطلاب نصف ساعة يومياً لتقديم برامج علمية وحوارات صريحة ومناقشة مشاكلهم.", rewardAr:"+30 حرية تعبير", cost:200, rep:25, morale:35, effect:"decree_podcast"},
    {num:49, cat:"decrees", icon:"🌳", titleAr:"مرسوم الحرم الأخضر (غرس شجرة باسم كل متفوق)", titleEn:"Decree: Plant a Tree for Every Top Achiever", descAr:"تخليد أسماء المتفوقين بلوحة برونزية مثبتة على أشجار الحديقة المدرسية.", rewardAr:"+35 استدامة وفخر", cost:250, rep:30, morale:35, effect:"decree_green_tree"},
    {num:50, cat:"decrees", icon:"🥋", titleAr:"إدراج حصة الدفاع عن النفس واللياقة البدنية أسبوعياً", titleEn:"Decree: Weekly Self-Defense & Fitness Class", descAr:"تدريب الطلاب على الكاراتيه والتايكوندو لرفع اللياقة والثقة بالنفس ومحاربة التنمر.", rewardAr:"+25 قوة وشجاعة", cost:300, rep:25, morale:30, effect:"decree_karate"},
    {num:51, cat:"decrees", icon:"🚀", titleAr:"تأسيس نادي الفضاء وهندسة الأقمار الصناعية المصغرة", titleEn:"Decree: CubeSat & Space Engineering Club", descAr:"شراكة مع وكالة الفضاء لتدريب الطلاب على برمجة مستشعرات الأقمار النانوية.", rewardAr:"+45 ريادة تكنولوجية", cost:500, rep:45, morale:35, effect:"decree_cubesat"},
    {num:52, cat:"decrees", icon:"🎨", titleAr:"إلغاء الواجبات المنزلية ليوم الجمعة واستبدالها بنشاط حر", titleEn:"Decree: No-Homework Fun Friday", descAr:"تكليف الطلاب بقراءة كتاب مفضل أو ممارسة رياضة بدلاً من حل المسائل الروتينية.", rewardAr:"+40 راحة نفسية", cost:0, rep:20, morale:50, effect:"decree_fun_friday"},
    {num:53, cat:"decrees", icon:"📚", titleAr:"ساعة القراءة الحرة الهادئة لجميع فصول المدرسة معاً", titleEn:"Decree: All-Campus Synchronized Reading Hour", descAr:"إيقاف الحركة وتفرغ 1000 طالب ومعلم لقراءة كتبهم المفضلة في نفس الساعة.", rewardAr:"+30 ثقافة عامة", cost:100, rep:35, morale:25, effect:"decree_reading_hour"},
    {num:54, cat:"decrees", icon:"🧁", titleAr:"مبادرة كعكة عيد الميلاد لكل طالب ومعلم في يوم مولده", titleEn:"Decree: Birthday Cupcake for Everyone", descAr:"تهنئة عبر الإذاعة المدرسية مع كب كيك مخصص لكل فرد بالمدرسة في يوم ميلاده.", rewardAr:"+50 ترابط مجتمعي", cost:250, rep:30, morale:50, effect:"decree_birthday"},
    {num:55, cat:"decrees", icon:"🤖", titleAr:"اعتماد الروبوت المساعد رفيقاً رسمياً لمكتب الاستقبال", titleEn:"Decree: Official AI Reception Robot Companion", descAr:"تخصيص روبوت تفاعلي للترحيب بأولياء الأمور والإجابة عن استفسارات المصروفات.", rewardAr:"+40 حداثة رقمية", cost:450, rep:40, morale:30, effect:"decree_reception_bot"},
    {num:56, cat:"decrees", icon:"🛡️", titleAr:"ميثاق الشرف الأخلاقي ضد التنمر والتنابز بالألقاب", titleEn:"Decree: Zero-Bullying Honor Charter", descAr:"توقيع ميثاق ملزم يعاقب المتنمرين بخدمات عامة ويكافئ ناشري المحبة والسلام.", rewardAr:"+35 سلام مجتمعي", cost:0, rep:35, morale:40, effect:"decree_anti_bully"},
    {num:57, cat:"decrees", icon:"🌟", titleAr:"لوحة المشاهير وسفراء المدرسة في المحافل الدولية", titleEn:"Decree: Hall of Fame Global Alumni Wall", descAr:"جدارية رخامية بمدخل المدرسة تبرز إنجازات خريجي المدرسة الذين وصلوا للعالمية.", rewardAr:"+40 قدوة حسنة", cost:300, rep:40, morale:30, effect:"decree_hall_of_fame"},
    {num:58, cat:"decrees", icon:"🏕️", titleAr:"معسكر المبيت الفلكي الكشفي بالملعب ليلة اكتمال القمر", titleEn:"Decree: Full-Moon Campus Overnight Campout", descAr:"نصب خيام كشفية وتناول وجبات الشواء ورصد النجوم مع حكايات السمر.", rewardAr:"+45 مغامرة كشفية", cost:400, rep:30, morale:50, effect:"decree_campout"},
    {num:59, cat:"decrees", icon:"🩺", titleAr:"برنامج الفحص الطبي الشامل للعيون والأسنان والقامة", titleEn:"Decree: Comprehensive Health & Posture Screening", descAr:"استضافة قافلة طبية متخصصة لفحص كافة الطلاب وتوزيع نظارات مجانية للمحتاجين.", rewardAr:"+40 رعاية صحية", cost:350, rep:40, morale:35, effect:"decree_medical_convoy"},
    {num:60, cat:"decrees", icon:"🤝", titleAr:"صندوق التكافل الخيري لدعم الطلاب غير القادرين بالزي والكتب", titleEn:"Decree: Student Solidarity & Support Fund", descAr:"مبادرة خيرية سرية تضمن عدم شعور أي طالب بالنقص وتوفر له كافة المستلزمات.", rewardAr:"+50 بركة وتكافل", cost:500, rep:50, morale:50, effect:"decree_charity_fund"},

    // --- CATEGORY 4: 20 RARE BADGES OF HONOR & LEGENDARY TROPHIES (61 - 80) ---
    {num:61, cat:"trophies", icon:"🥇", titleAr:"قلادة النيل الذهبية للتميز التعليمي والإداري الاستثنائي", titleEn:"Golden Nile Necklace of Supreme Leadership", descAr:"أعلى وسام يمنحه وزير التربية والتعليم للمدير الذي يقود مدرسته للمركز الأول.", rewardAr:"+1000 نقطة فخر", cost:0, rep:50, morale:50, effect:"trophy_nile"},
    {num:62, cat:"trophies", icon:"💎", titleAr:"درع الحرم الذكي الخالي تماماً من الورق (Paperless Campus)", titleEn:"Diamond Paperless Green School Shield", descAr:"تحويل 100% من المعاملات المدرسية إلى رقمية وتوفير 50 ألف ورقة سنوياً.", rewardAr:"+45 استدامة رقمية", cost:0, rep:45, morale:35, effect:"trophy_paperless"},
    {num:63, cat:"trophies", icon:"🏆", titleAr:"كأس السوبر الذهبي لدوري مدارس الجمهورية لكرة القدم", titleEn:"National High School Super League Golden Cup", descAr:"تتويج فريق المدرسة بالبطولة القومية وسحق المنافسين في المباراة النهائية بالاستاد.", rewardAr:"+800 ج.م جائزة", cost:0, rep:50, morale:50, effect:"trophy_super_cup"},
    {num:64, cat:"trophies", icon:"🧠", titleAr:"وسام عباقرة الأولمبياد الدولي للرياضيات والفيزياء", titleEn:"International Olympiad Genius Grand Medal", descAr:"حصد ميداليتين ذهبيتين في أولمبياد العلوم العالمي ورفع علم مصر عالياً.", rewardAr:"+50 عبقرية دولية", cost:0, rep:50, morale:45, effect:"trophy_olympiad"},
    {num:65, cat:"trophies", icon:"📜", titleAr:"شهادة جينيس للأرقام القياسية لأكبر جدارية تراثية", titleEn:"Guinness World Record Certificate", descAr:"رسم أطول جدارية تحكي تاريخ مصر القديم بأيدي 500 طالب على سور المدرسة.", rewardAr:"+60 شهرة عالمية", cost:0, rep:60, morale:50, effect:"trophy_guinness"},
    {num:66, cat:"trophies", icon:"👑", titleAr:"تاج المعلم المثالي وجائزة صانع الأجيال الذهبية", titleEn:"Crown of the Master Educator Award", descAr:"تكريم أفضل معلم بالمدرسة ومنحه رحلة عمرة ومكافأة تميز برعاية مجلس الإدارة.", rewardAr:"+45 وفاء للمعلمين", cost:0, rep:40, morale:50, effect:"trophy_master_teacher"},
    {num:67, cat:"trophies", icon:"🤖", titleAr:"جائزة الابتكار التكنولوجي لمعرض القاهرة الدولي للاختراعات", titleEn:"Cairo International Tech Expo 1st Prize", descAr:"فوز مشروع الروبوت الزراعي المدرسي بالمركز الأول وسط منافسة 80 مدرسة.", rewardAr:"+45 تفوق هندسي", cost:0, rep:45, morale:40, effect:"trophy_tech_expo"},
    {num:68, cat:"trophies", icon:"🌍", titleAr:"وسام المدرسة الخضراء الصديقة للبيئة من منظمة اليونسكو", titleEn:"UNESCO Eco-School Platinum Accreditation", descAr:"اعتماد الحرم المدرسي كأول بيئة تعليمية محايدة للكربون وموفرة للمياه بنسبة 70%.", rewardAr:"+50 اعتماد دولي", cost:0, rep:50, morale:40, effect:"trophy_unesco"},
    {num:69, cat:"trophies", icon:"♟️", titleAr:"كأس الأساتذة الكبار للشطرنج الذهبي المدرسي", titleEn:"Grandmaster Golden Chess Tournament Trophy", descAr:"سحق منافسي الشطرنج بالدفاع الصقلي وهزيمة بطل المحافظة في 18 نقلة.", rewardAr:"+40 دهاء تكتيكي", cost:0, rep:40, morale:35, effect:"trophy_chess_cup"},
    {num:70, cat:"trophies", icon:"🎭", titleAr:"درع المسرح والخطابة والإلقاء الشعري الفصيح", titleEn:"National Classical Arabic Oratory Shield", descAr:"فوز فريق الخطابة بالمركز الأول في مسابقة الإلقاء الشعري والتمثيل المسرحي.", rewardAr:"+35 بلاغة وفصاحة", cost:0, rep:35, morale:40, effect:"trophy_oratory"},
    {num:71, cat:"trophies", icon:"🏊", titleAr:"وسام القرش الذهبي لسباحي المسافات الطويلة", titleEn:"Golden Shark Trophy for Endurance Swimming", descAr:"عبور مسافة 5 كم سباحة حرة بدون توقف في بطولة القناة للناشئين.", rewardAr:"+40 عزيمة حديدية", cost:0, rep:40, morale:35, effect:"trophy_shark"},
    {num:72, cat:"trophies", icon:"📖", titleAr:"وسام تاج الوقار لحفظ القرآن الكريم كاملاً بالسند", titleEn:"Crown of Dignity Full Quran Recitation Award", descAr:"تخريج 15 طالباً وطالبة يحملون إجازة الحفظ والتجويد بالقراءات العشر.", rewardAr:"+50 نور وبركة", cost:0, rep:50, morale:50, effect:"trophy_quran_crown"},
    {num:73, cat:"trophies", icon:"🏥", titleAr:"نجمة الصحة المدرسية والبيئة المعقمة الخالية من الأوبئة", titleEn:"School Health & Hygiene 5-Star Seal", descAr:"تسجيل صفر حالات غياب مرضي وتحقيق أعلى معايير النظافة والتغذية السليمة.", rewardAr:"+35 صحة وعافية", cost:0, rep:35, morale:35, effect:"trophy_health_star"},
    {num:74, cat:"trophies", icon:"🚌", titleAr:"كأس السلامة المرورية وأسطول الحافلات المنضبطة", titleEn:"Safe Transit & Bus Fleet Golden Plaque", descAr:"مليون كيلومتر بدون أي مخالفة مرورية وبمواعيد دقيقة بنسبة 99.8%.", rewardAr:"+30 أمان مروري", cost:0, rep:30, morale:30, effect:"trophy_safe_bus"},
    {num:75, cat:"trophies", icon:"🔭", titleAr:"ميدالية جاليليو لاكتشاف الكويكبات الفضائية الجديدة", titleEn:"Galileo Junior Asteroid Hunter Medal", descAr:"رصد كويكب جديد عبر التلسكوب المدرسي واعتماده في السجل الفلكي العالمي.", rewardAr:"+45 اكتشاف كوني", cost:0, rep:45, morale:40, effect:"trophy_galileo"},
    {num:76, cat:"trophies", icon:"🎵", titleAr:"القيثارة الذهبية لكورال الإنشاد الوطني والترانيم", titleEn:"Golden Lyre National Choir Trophy", descAr:"إحياء حفل عيد النصر بالأوبرا المصرية وتصفيق حار من الجمهور لمدة 10 دقائق.", rewardAr:"+40 إبداع صوتي", cost:0, rep:40, morale:45, effect:"trophy_choir"},
    {num:77, cat:"trophies", icon:"🏹", titleAr:"وسام القوس الذهبي للرماية والتركيز العالي", titleEn:"Golden Archer Bullseye Excellence Shield", descAr:"إصابة عين الهدف بدقة 100% في بطولة المدارس للرماية بالسهم.", rewardAr:"+35 دقة تصويب", cost:0, rep:35, morale:35, effect:"trophy_archer"},
    {num:78, cat:"trophies", icon:"🪡", titleAr:"درع الاقتصاد المنزلي والتطريز والنسيج التراثي الأصيل", titleEn:"Heritage Textile & Fashion Masterpiece Award", descAr:"تصميم أثواب وسجاد يدوي تراثي تم عرضه في معرض ديارنا للحرف اليدوية.", rewardAr:"+30 فن وحرفية", cost:0, rep:30, morale:35, effect:"trophy_textile"},
    {num:79, cat:"trophies", icon:"🛸", titleAr:"كأس سباق الطائرات المسيرة والدرونز الآلية للناشئين", titleEn:"Autonomous Drone Grand Prix Champions Cup", descAr:"اجتياز مسار الحواجز الصعب في 35 ثانية بطائرة درون برمجها الطلاب بأنفسهم.", rewardAr:"+45 سرعة وتحكم", cost:0, rep:45, morale:40, effect:"trophy_drone_gp"},
    {num:80, cat:"trophies", icon:"🌟", titleAr:"وسام نجمة الشرف التعليمية الكبرى للمدرسة الأسطورية", titleEn:"Grand Legendary School of the Century Trophy", descAr:"تخليد اسم المدرسة في كتاب التاريخ كأفضل منارة تربوية وعلمية للقرن.", rewardAr:"+100 خلود وتاريخ", cost:0, rep:60, morale:60, effect:"trophy_legendary"},

    // --- CATEGORY 5: 20 EPIC CAMPUS FESTIVALS & SEASONAL EVENTS (81 - 100) ---
    {num:81, cat:"festivals", icon:"🎪", titleAr:"مهرجان العلوم والابتكارات والفيزياء السحرية السنوي", titleEn:"Annual Science Magic & Innovation Carnival", descAr:"خيام علمية تفاعلية، تجارب نيتروجين سائل، وبراكين كيميائية مذهلة تبهر الزوار.", rewardAr:"+45 إبهار علمي", cost:300, rep:40, morale:45, effect:"fest_science"},
    {num:82, cat:"festivals", icon:"🎭", titleAr:"كرنفال الفنون والمسرح التراثي والشخصيات التاريخية", titleEn:"Heritage Carnival & Historical Cosplay", descAr:"طلاب يتقمصون شخصيات نجيب محفوظ وأحمد زويل وحتشبسوت وعروض مسرحية حية.", rewardAr:"+40 ثقافة وفن", cost:250, rep:35, morale:45, effect:"fest_theatre"},
    {num:83, cat:"festivals", icon:"🥘", titleAr:"مهرجان المأكولات التراثية والشعبية والمخبوزات الساخنة", titleEn:"Traditional Heritage Food & Pastry Festival", descAr:"أكشاك طهي تقدم الفطير المشلتت والكشري والأطباق التراثية بدعم أمهات الطلاب.", rewardAr:"+50 بهجة وألفة", cost:200, rep:30, morale:50, effect:"fest_food"},
    {num:84, cat:"festivals", icon:"⚽", titleAr:"أولمبياد المدرسة الكبرى وبطولة ألعاب القوى والماراثون", titleEn:"Grand Campus Athletics & Marathon Olympiad", descAr:"سباقات 100 متر، قفز عالي، ورمي الجلة مع منصات تتويج وأكاليل الزيتون.", rewardAr:"+45 لياقة ومنافسة", cost:350, rep:40, morale:45, effect:"fest_olympics"},
    {num:85, cat:"festivals", icon:"📚", titleAr:"معرض الكتاب السنوي وسوق تبادل الروايات والموسوعات", titleEn:"Campus Annual Book Fair & Novel Exchange", descAr:"استضافة 20 دار نشر وتخفيضات 70% على الكتب العلمية والأدبية لكل الطلاب.", rewardAr:"+40 قراءة ومعرفة", cost:150, rep:45, morale:35, effect:"fest_book_fair"},
    {num:86, cat:"festivals", icon:"🪁", titleAr:"مهرجان الطائرات الورقية الملونة في سماء الحرم المدرسي", titleEn:"Colorful Sky Kite Flying Spectacle", descAr:"إطلاق 500 طائرة ورقية ملونة تحمل عبارات الأمل والسلام في يوم ربيعي مشمس.", rewardAr:"+45 فرحة وبهجة", cost:180, rep:30, morale:50, effect:"fest_kites"},
    {num:87, cat:"festivals", icon:"🤖", titleAr:"بطولة صراع الروبوتات وتحدي المتاهة الذكية (RoboWars)", titleEn:"RoboWars Arena & Autonomous Maze Challenge", descAr:"حلبة مصارعة للروبوتات الصغيرة وتحكم لاسلكي وسط صيحات وتشجيع الطلاب.", rewardAr:"+50 حماس تقني", cost:400, rep:45, morale:45, effect:"fest_robowars"},
    {num:88, cat:"festivals", icon:"🎨", titleAr:"معرض الفنون التشكيلية والرسم الجداري ثلاثي الأبعاد", titleEn:"3D Fine Arts & Street Chalk Masterpieces", descAr:"تحويل ممرات الفناء إلى لوحات أرضية ثلاثية الأبعاد برسومات خدع بصرية مبهرة.", rewardAr:"+35 لمسة جمالية", cost:200, rep:35, morale:40, effect:"fest_art_expo"},
    {num:89, cat:"festivals", icon:"🌙", titleAr:"أمسية السمر الرمضانية وفوانيس الخير والإنشاد الديني", titleEn:"Ramadan Lanterns & Spiritual Chants Night", descAr:"توزيع فوانيس رمضان، موائد إفطار جماعية، وتواشيح وابتهالات دينية ساحرة.", rewardAr:"+50 روحانية وتراحم", cost:350, rep:45, morale:50, effect:"fest_ramadan"},
    {num:90, cat:"festivals", icon:"💼", titleAr:"سوق رواد الأعمال الصغار ومشاريع الطلاب الناشئة (BizKid)", titleEn:"Junior Startup Market & Entrepreneur Expo", descAr:"أجنحة تجارية يديرها الطلاب لبيع منتجاتهم اليدوية وبرمجياتهم وحساب الأرباح.", rewardAr:"+45 خبرة تجارية", cost:200, rep:40, morale:40, effect:"fest_bizkid"},
    {num:91, cat:"festivals", icon:"♟️", titleAr:"مهرجان الشطرنج المتزامن (الناظر يلاعب 30 طالباً معاً)", titleEn:"Grand Simultaneous Chess Exhibition (1 vs 30)", descAr:"استعراض ذكاء أسطوري يواجه فيه المدير 30 لوحة شطرنج في وقت واحد بالبهو.", rewardAr:"+50 إبهار تكتيكي", cost:100, rep:50, morale:45, effect:"fest_chess_simul"},
    {num:92, cat:"festivals", icon:"🌿", titleAr:"يوم التشجير والزراعة العضوية (حبة قمح ونخلة في كل زاوية)", titleEn:"Green Campus Afforestation & Organic Harvest", descAr:"مشاركة جماعية لغرس شتلات النعناع والريحان والزهور في كافة أحواض المدرسة.", rewardAr:"+35 طبيعة خلابة", cost:220, rep:35, morale:40, effect:"fest_planting"},
    {num:93, cat:"festivals", icon:"🎙️", titleAr:"مهرجان مواهب الصوت والبودكاست والتمثيل الإذاعي", titleEn:"Voice Master & Live Audio Drama Festival", descAr:"مسابقة لاكتشاف أجمل الأصوات الإذاعية ومقدمي البرامج والمعلقين الرياضيين.", rewardAr:"+40 اكتشاف مواهب", cost:150, rep:35, morale:45, effect:"fest_voice_talent"},
    {num:94, cat:"festivals", icon:"🚀", titleAr:"مهرجان إطلاق صواريخ ضغط الماء والمظلات الهوائية", titleEn:"Hydro-Rocket & Parachute Launch Derby", descAr:"إطلاق صواريخ مائية تصل لارتفاع 60 متراً في السماء مع هبوط آمن بالمظلات.", rewardAr:"+45 إثارة وهندسة", cost:200, rep:40, morale:45, effect:"fest_hydro_rocket"},
    {num:95, cat:"festivals", icon:"🌍", titleAr:"مهرجان الثقافات والشعوب ومعرض أزياء العالم الموحد", titleEn:"World Cultures & Global Heritage Showcase", descAr:"كل فصل يمثل دولة شقيقة ويعرض تراثها وموسيقاها وأكلاتها لتعزيز الانفتاح.", rewardAr:"+40 تسامح عالمي", cost:300, rep:45, morale:40, effect:"fest_world_cultures"},
    {num:96, cat:"festivals", icon:"🧩", titleAr:"أولمبياد حل الألغاز ومكعب روبيك وسودوكو السريع", titleEn:"Rubik Speedcubing & Logic Puzzle Masters", descAr:"منافسات حل مكعب روبيك في أقل من 15 ثانية وتحديات تفكير منطقي سريعة.", rewardAr:"+35 سرعة بديهة", cost:120, rep:35, morale:40, effect:"fest_rubik"},
    {num:97, cat:"festivals", icon:"🧙‍♂️", titleAr:"أمسية حكايات التراث والأساطير المصرية القديمة تحت النجوم", titleEn:"Folklore & Ancient Legends Night Under Stars", descAr:"جلسة سمر حول مدفأة الفناء لسماع قصص الشاطر حسن وتاريخ بناة الأهرامات.", rewardAr:"+40 شغف وتاريخ", cost:150, rep:35, morale:45, effect:"fest_legends_night"},
    {num:98, cat:"festivals", icon:"🏊", titleAr:"كرنفال الألعاب المائية وتحدي التجديف بالقوارب المطاطية", titleEn:"Summer Splash & Inflatable Raft Race", descAr:"ألعاب مائية ممتعة وتحديات سباحة في المسبح المدرسي لإنعاش الأجواء.", rewardAr:"+45 انتعاش وسرور", cost:300, rep:35, morale:50, effect:"fest_pool_splash"},
    {num:99, cat:"festivals", icon:"✨", titleAr:"حفل الألعاب النارية الصديقة للبيئة والدرونز المضيئة 3D", titleEn:"Eco-Friendly Fireworks & 3D Drone Light Show", descAr:"100 طائرة درون مضيئة ترسم شعار المدرسة وعلم مصر في سماء الحرم ليلاً.", rewardAr:"+55 فخامة وإبهار", cost:450, rep:50, morale:55, effect:"fest_drone_show"},
    {num:100, cat:"festivals", icon:"👑", titleAr:"مهرجان التخرج الملكي الأسطوري وحفل تتويج قادة المستقبل", titleEn:"Royal Grand Graduation & Future Leaders Coronation", descAr:"مسيرة تخرج ملكية مع قبعات التخرج الذهبية والشهادات المعتمدة من الوزير شخصياً.", rewardAr:"+100 فخر ومجد لا ينسى", cost:500, rep:60, morale:60, effect:"fest_royal_grad"}
  ];

  if(!t) return null;

  // Handlers
  const handleActivateItem = (item) => {
    if(activatedIds.includes(item.num)) {
      I.playClick();
      setLastActionMsg(n ? `ℹ️ (${item.titleAr}) مفعل بالفعل في منظومتك!` : `Already activated!`);
      setTimeout(() => setLastActionMsg(null), 3000);
      return;
    }
    if(item.cost > 0 && r.budget < item.cost) {
      I.playStampReject();
      setLastActionMsg(n ? `⚠️ الميزانية غير كافية لتنفيذ (${item.titleAr})! التكلفة: ${item.cost} ج.م` : `Insufficient budget!`);
      setTimeout(() => setLastActionMsg(null), 3000);
      return;
    }

    I.playAchievementFanfare();
    I.playCashRegister();
    setActivatedIds(prev => [...prev, item.num]);

    a(prev => ({
      ...prev,
      budget: Math.max(0, prev.budget - (item.cost || 0)),
      reputation: Math.min(100, (prev.reputation || 70) + (item.rep || 10)),
      teachers: (prev.teachers || []).map(tch => ({...tch, morale: Math.min(100, (tch.morale || 70) + (item.morale || 10))})),
      notifications: [
        {
          id: `notif-100-${Date.now()}`,
          day: prev.currentDay,
          title: n ? `✨ تفعيل الإضافة رقم #${item.num}: ${item.titleAr}` : `Activated Addition #${item.num}: ${item.titleEn}`,
          titleEn: `Activated Addition #${item.num}: ${item.titleEn}`,
          message: n ? `تم اعتماد وتشغيل (${item.titleAr}) بنجاح! الأثر: ${item.rewardAr} (+${item.rep} سمعة، +${item.morale}% معنويات)` : `Activated #${item.num} successfully!`,
          messageEn: `Activated #${item.num} successfully!`,
          timestamp: new Date().toLocaleTimeString(),
          read: false,
          type: "achievement",
          urgency: "high"
        },
        ...(prev.notifications || [])
      ]
    }));

    setLastActionMsg(n ? `✅ تم تفعيل وتشغيل الإضافة #${item.num}: (${item.titleAr}) بنجاح!` : `Activated #${item.num} successfully!`);
    setTimeout(() => setLastActionMsg(null), 4000);
  };

  const handleResolveAlert = (alert) => {
    I.playBell();
    I.playAchievementFanfare();
    setCctvAlerts(prev => prev.map(a => a.id === alert.id ? {...a, resolved:true} : a));
    setCctvLog(prev => [`[${new Date().toLocaleTimeString()}] تم حسم (${alert.titleAr}) بنجاح (+${alert.reward} ج.م)`, ...prev]);
    a(prev => ({
      ...prev,
      budget: prev.budget + alert.reward,
      reputation: Math.min(100, (prev.reputation || 70) + 5)
    }));
  };

  const handleTakeSnapshot = () => {
    I.playCardFlip();
    setSnapshotCount(prev => prev + 1);
    setCctvLog(prev => [`[${new Date().toLocaleTimeString()}] 📸 تم التقاط لقطة شاشة أمنية رسمية وحفظها في أرشيف الحرم.`, ...prev]);
  };

  const handleToggleAlarm = () => {
    if(!alarmActive) {
      I.playAlarm();
      setAlarmActive(true);
      setCctvLog(prev => [`[${new Date().toLocaleTimeString()}] 🚨 تم إطلاق صفارة الطوارئ وتفريق التجمعات بالممرات.`, ...prev]);
    } else {
      setAlarmActive(false);
    }
  };

  const handleIssueVerdict = (courtCase, verdictType) => {
    I.playStampAccept();
    I.playAchievementFanfare();
    const verdictNames = {
      service: "خدمة عامة وتنظيم المكتبة 10 أيام",
      suspension: "فصل تأديبي 3 أيام واستدعاء ولي الأمر",
      pledge: "تعهد خطي مشدد وغرامة صيانة",
      amnesty: "عفو تربوي وإحالة للإرشاد النفسي"
    };
    setVerdictHistory(prev => [{
      caseId: courtCase.id,
      studentName: courtCase.studentName,
      verdict: verdictNames[verdictType],
      time: new Date().toLocaleTimeString()
    }, ...prev]);
    a(prev => ({
      ...prev,
      reputation: Math.min(100, (prev.reputation || 70) + 8),
      teachers: (prev.teachers || []).map(t => ({...t, morale: Math.min(100, (t.morale || 70) + 6)}))
    }));
  };

  const handleDialNumber = (digit) => {
    I.playCalculatorBeep();
    if(dialNumber.length < 3) {
      setDialNumber(prev => prev + digit);
    }
  };

  const handleMakeCall = (codeToCall) => {
    const target = codeToCall || dialNumber;
    const found = phoneBook.find(p => p.code === target);
    I.playDeskPhoneRing();
    setCallActive(true);
    if(found) {
      setCallDetails(found);
      if(found.bonus) {
        a(prev => ({...prev, budget: prev.budget + found.bonus}));
      }
    } else {
      setCallDetails({
        code: target,
        deptAr: "رقم غير مدرج بالدليل الداخلي",
        deptEn: "Unlisted Extension",
        icon: "📵",
        replyAr: "عفواً الرقم الذي طلبته غير موجود بدليل مكتب الناظر، يرجى مراجعة الدليل السريع.",
        replyEn: "Number not in directory, please check speed dial list."
      });
    }
  };

  // Filter 100 additions
  const filtered100 = grand100List.filter(item => {
    const matchCat = activeTab === "all" || item.cat === activeTab;
    const matchSearch = searchQuery === "" || 
      item.titleAr.includes(searchQuery) || 
      item.descAr.includes(searchQuery) || 
      item.num.toString() === searchQuery;
    return matchCat && matchSearch;
  });

  return s.jsx("div", {
    className: "fixed inset-0 z-[100] bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 animate-in fade-in duration-200",
    children: s.jsxs("div", {
      className: "max-w-6xl w-full max-h-[94vh] rounded-3xl bg-slate-900 border-2 border-purple-500/80 text-white shadow-2xl flex flex-col overflow-hidden relative",
      children: [
        // Top Header
        s.jsxs("div", {
          className: "p-4 sm:p-5 border-b border-purple-500/30 bg-gradient-to-r from-purple-950/90 via-slate-900 to-indigo-950/90 flex items-center justify-between shrink-0",
          children: [
            s.jsxs("div", {
              className: "flex items-center gap-3",
              children: [
                s.jsx("div", {
                  className: "w-12 h-12 rounded-2xl bg-purple-500/20 border border-purple-400 flex items-center justify-center text-2xl shadow-lg",
                  children: "💯"
                }),
                s.jsxs("div", {
                  children: [
                    s.jsxs("div", {
                      className: "flex items-center gap-2",
                      children: [
                        s.jsx("h2", {
                          className: "text-lg sm:text-xl font-black text-purple-300",
                          children: n ? "موسوعة الـ 100 إضافة والاستثنائية الجديدة كلياً 🌟" : "100 Grand Novel Additions & Systems Hub"
                        }),
                        s.jsxs("span", {
                          className: "px-2.5 py-0.5 rounded-full text-[10px] font-black bg-purple-600 text-white font-mono",
                          children: [activatedIds.length, " / 100 مفعلة"]
                        })
                      ]
                    }),
                    s.jsx("p", {
                      className: "text-xs text-slate-300 mt-0.5",
                      children: n ? "100 إضافة جديدة بالكامل لم تضف من قبل: أدوات مكتب تفاعلية، أسرار وقصص الحرم، قرارات سيادية، أوسمة نادرة، ومهرجانات أسطورية." : "100 completely new features: interactive office gadgets, campus lore secrets, executive decrees, rare trophies & epic festivals."
                    })
                  ]
                })
              ]
            }),
            s.jsx("button", {
              onClick: e,
              className: "w-9 h-9 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition-all cursor-pointer",
              children: s.jsx(ps, { className: "w-5 h-5" })
            })
          ]
        }),

        // Feedback Banner
        lastActionMsg && s.jsx("div", {
          className: "px-4 py-2 bg-emerald-600 text-white text-xs font-black text-center animate-in slide-in-from-top-2 shrink-0 flex items-center justify-center gap-2",
          children: [
            s.jsx("span", { children: "⚡" }),
            s.jsx("span", { children: lastActionMsg })
          ]
        }),

        // Category Filters & Search
        s.jsxs("div", {
          className: "p-3 bg-slate-950/90 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2.5 shrink-0",
          children: [
            // Search Box
            s.jsxs("div", {
              className: "relative flex-1 min-w-[200px]",
              children: [
                s.jsx(vn, { className: "w-4 h-4 absolute start-3 top-1/2 -translate-y-1/2 text-purple-400" }),
                s.jsx("input", {
                  type: "text",
                  value: searchQuery,
                  onChange: (ev) => setSearchQuery(ev.target.value),
                  placeholder: n ? "ابحث بالاسم أو الرقم في الـ 100 إضافة..." : "Search in 100 additions...",
                  className: "w-full bg-slate-900 border border-slate-700 focus:border-purple-400 rounded-xl ps-9 pe-4 py-1.5 text-xs text-white placeholder-slate-400 focus:outline-none"
                })
              ]
            }),

            // Tab Buttons
            s.jsx("div", {
              className: "flex items-center gap-1.5 overflow-x-auto scrollbar-none",
              children: [
                {id:"all", icon:"💯", labelAr:"جميع الـ 100 إضافة (100)", labelEn:"All 100"},
                {id:"gadgets", icon:"🕹️", labelAr:"أدوات وألعاب المكتب (20)", labelEn:"Office Gadgets (20)"},
                {id:"secrets", icon:"🎭", labelAr:"أسرار وقصص الحرم (20)", labelEn:"Campus Secrets (20)"},
                {id:"decrees", icon:"🏛️", labelAr:"قرارات المدير السيادية (20)", labelEn:"Executive Decrees (20)"},
                {id:"trophies", icon:"🎖️", labelAr:"الأوسمة والجوائز النادرة (20)", labelEn:"Rare Trophies (20)"},
                {id:"festivals", icon:"🎪", labelAr:"المهرجانات والكرنفالات (20)", labelEn:"Festivals (20)"},
                {id:"cctv", icon:"📹", labelAr:"غرفة المراقبة 🔴", labelEn:"Live CCTV"},
                {id:"court", icon:"⚖️", labelAr:"محكمة التأديب 📜", labelEn:"Court"},
                {id:"phone", icon:"☎️", labelAr:"هاتف المكتب 📞", labelEn:"Phone"}
              ].map(tab => s.jsxs("button", {
                key: tab.id,
                onClick: () => { I.playCardFlip(); setActiveTab(tab.id); },
                className: `px-3 py-1.5 rounded-xl text-xs font-black flex items-center gap-1.5 whitespace-nowrap transition-all cursor-pointer ${activeTab === tab.id ? "bg-purple-600 text-white shadow-md shadow-purple-600/30 scale-102" : "bg-slate-850 hover:bg-slate-800 text-slate-300 border border-slate-700"}`,
                children: [
                  s.jsx("span", { children: tab.icon }),
                  s.jsx("span", { children: n ? tab.labelAr : tab.labelEn })
                ]
              }))
            })
          ]
        }),

        // Main Content Area
        s.jsxs("div", {
          className: "flex-1 overflow-y-auto p-4 sm:p-5 space-y-4",
          children: [
            // 1. CCTV Room View
            activeTab === "cctv" && s.jsxs("div", {
              className: "space-y-4 animate-in fade-in duration-150",
              children: [
                s.jsxs("div", {
                  className: "p-3 bg-slate-950/70 rounded-2xl border border-slate-800 flex flex-wrap items-center justify-between gap-2.5",
                  children: [
                    s.jsxs("div", {
                      className: "flex items-center gap-2 text-xs font-mono font-bold text-emerald-400",
                      children: [
                        s.jsx("span", { className: "w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" }),
                        s.jsx("span", { children: "SYSTEM OPERATIONAL: 6 CHANNELS ACTIVE" })
                      ]
                    }),
                    s.jsxs("div", {
                      className: "flex items-center gap-2",
                      children: [
                        s.jsxs("button", {
                          onClick: handleTakeSnapshot,
                          className: "px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-xs font-bold text-amber-300 border border-amber-500/40 flex items-center gap-1.5 cursor-pointer active:scale-95",
                          children: [
                            s.jsx("span", { children: "📸" }),
                            s.jsx("span", { children: n ? `التقاط صورة دليل (${snapshotCount})` : `Snapshot (${snapshotCount})` })
                          ]
                        }),
                        s.jsxs("button", {
                          onClick: handleToggleAlarm,
                          className: `px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer active:scale-95 ${alarmActive ? "bg-rose-600 text-white animate-bounce" : "bg-slate-800 text-rose-300 border border-rose-500/40"}`,
                          children: [
                            s.jsx("span", { children: "🚨" }),
                            s.jsx("span", { children: alarmActive ? (n ? "إيقاف الإنذار 🔕" : "Silence Siren") : (n ? "تشغيل صفارة الطوارئ 🚨" : "Trigger Siren") })
                          ]
                        })
                      ]
                    })
                  ]
                }),
                s.jsx("div", {
                  className: "grid grid-cols-1 md:grid-cols-3 gap-3",
                  children: [
                    {id:1, nameAr:"كاميرا 1: فناء الطابور والمقصف", nameEn:"Cam 1: Main Yard & Canteen", location:"Ground Floor", color:"from-slate-900 to-emerald-950/40", icon:"🏫", liveEvent:"طابور منتظم وأصوات النشيد الوطني بالخلفية"},
                    {id:2, nameAr:"كاميرا 2: ممر الفصول الدور الثاني", nameEn:"Cam 2: 2nd Floor Corridor", location:"2nd Floor", color:"from-slate-900 to-blue-950/40", icon:"🏢", liveEvent:"حركة معلمين منتظمة ودخول الفصول بهدوء"},
                    {id:3, nameAr:"كاميرا 3: البوابة الرئيسية وموقف السيارات", nameEn:"Cam 3: Main Gate & Parking", location:"Gate 1", color:"from-slate-900 to-amber-950/40", icon:"🚪", liveEvent:"حارس البوابة يتحقق من هويات الزائرين"},
                    {id:4, nameAr:"كاميرا 4: معمل العلوم والكمبيوتر", nameEn:"Cam 4: Science & IT Labs", location:"East Wing", color:"from-slate-900 to-purple-950/40", icon:"🧪", liveEvent:"الطلاب يرتدون بالطو المعمل لإجراء التجارب"},
                    {id:5, nameAr:"كاميرا 5: ملعب كرة القدم والمدرجات", nameEn:"Cam 5: Pro Turf Arena", location:"Sports Complex", color:"from-slate-900 to-teal-950/40", icon:"⚽", liveEvent:"تدريبات منتخب المدرسة وتمريرات كابتن الفريق"},
                    {id:6, nameAr:"كاميرا 6: السور الخلفي وحديقة المدرسة", nameEn:"Cam 6: Back Fence & Garden", location:"Perimeter", color:"from-slate-900 to-stone-950/40", icon:"🌳", liveEvent:"أشجار الزيتون ونظام الري الذكي يعمل بكفاءة"}
                  ].map(cam => {
                    const alert = cctvAlerts.find(a => a.cam === cam.id && !a.resolved);
                    return s.jsxs("div", {
                      key: cam.id,
                      onClick: () => setSelectedCam(cam.id),
                      className: `p-3 rounded-2xl bg-gradient-to-b ${cam.color} border-2 ${selectedCam === cam.id ? "border-amber-400" : "border-slate-800"} flex flex-col justify-between min-h-[170px] relative overflow-hidden cursor-pointer`,
                      children: [
                        s.jsxs("div", {
                          className: "flex items-center justify-between text-[11px] font-mono text-slate-400 z-10",
                          children: [
                            s.jsxs("div", { className: "flex items-center gap-1.5 font-bold text-white", children: [s.jsx("span", {children:cam.icon}), s.jsx("span", {children:n ? cam.nameAr : cam.nameEn})] }),
                            s.jsx("span", { className: "text-emerald-400 font-bold", children: "● LIVE" })
                          ]
                        }),
                        s.jsxs("div", {
                          className: "my-2 p-2 rounded-xl bg-black/40 text-center z-10",
                          children: [
                            alert ? s.jsxs("div", {
                              className: "space-y-1 animate-pulse",
                              children: [
                                s.jsx("div", { className: "text-xs font-black text-rose-400", children: alert.titleAr }),
                                s.jsx("div", { className: "text-[10px] text-amber-300 font-bold", children: `⚠️ مستوى الخطورة: ${alert.severity}` })
                              ]
                            }) : s.jsx("div", { className: "text-xs text-slate-300 font-bold", children: cam.liveEvent })
                          ]
                        }),
                        s.jsxs("div", {
                          className: "flex items-center justify-between text-[10px] z-10 pt-1 border-t border-white/10",
                          children: [
                            s.jsx("span", { className: "text-slate-400 font-mono", children: cam.location }),
                            alert ? s.jsxs("button", {
                              onClick: (ev) => { ev.stopPropagation(); handleResolveAlert(alert); },
                              className: "px-2 py-0.5 rounded bg-rose-600 hover:bg-rose-500 text-white font-bold cursor-pointer",
                              children: ["⚡ ", n ? alert.actionAr : alert.actionEn]
                            }) : s.jsx("span", { className: "text-emerald-400", children: "آمن 🟢" })
                          ]
                        })
                      ]
                    });
                  })
                })
              ]
            }),

            // 2. Disciplinary Court View
            activeTab === "court" && s.jsxs("div", {
              className: "space-y-4 animate-in fade-in duration-150",
              children: [
                s.jsxs("div", {
                  className: "p-4 bg-gradient-to-r from-amber-950/60 to-slate-950 rounded-2xl border border-amber-500/30 flex items-center justify-between",
                  children: [
                    s.jsxs("div", {
                      children: [
                        s.jsx("h3", { className: "text-base font-black text-amber-300", children: n ? "⚖️ جلسة مجلس التأديب والانضباط المدرسي" : "Disciplinary Court" }),
                        s.jsx("p", { className: "text-xs text-slate-300 mt-0.5", children: n ? "افحص أدلة القضية واعترافات الطالب ثم أصدر الحكم الإداري الملزم." : "Review evidence and issue disciplinary verdict." })
                      ]
                    }),
                    s.jsxs("div", { className: "text-xs font-bold text-amber-400 bg-amber-500/10 px-3 py-1 rounded-xl border border-amber-500/30", children: ["قضية ", activeCaseIdx + 1, " من ", courtCases.length] })
                  ]
                }),
                (() => {
                  const currentCase = courtCases[activeCaseIdx];
                  return s.jsxs("div", {
                    className: "p-4 rounded-3xl bg-slate-850 border border-slate-700 space-y-3",
                    children: [
                      s.jsxs("div", {
                        className: "flex items-center justify-between pb-2 border-b border-slate-700",
                        children: [
                          s.jsxs("div", {
                            className: "flex items-center gap-2",
                            children: [
                              s.jsx("span", { className: "text-2xl", children: "👨‍🎓" }),
                              s.jsxs("div", {
                                children: [
                                  s.jsx("h4", { className: "text-sm font-black text-white", children: currentCase.studentName }),
                                  s.jsx("span", { className: "text-xs text-rose-400 font-bold", children: currentCase.chargeAr })
                                ]
                              })
                            ]
                          }),
                          s.jsxs("div", {
                            className: "flex items-center gap-1",
                            children: courtCases.map((c, i) => s.jsx("button", {
                              key: c.id,
                              onClick: () => setActiveCaseIdx(i),
                              className: `w-6 h-6 rounded text-xs font-bold ${i === activeCaseIdx ? "bg-amber-500 text-slate-950" : "bg-slate-800 text-slate-400"}`,
                              children: i + 1
                            }))
                          })
                        ]
                      }),
                      s.jsxs("div", {
                        className: "grid grid-cols-1 md:grid-cols-3 gap-2 text-xs",
                        children: [
                          s.jsxs("div", { className: "p-2.5 rounded-xl bg-slate-900 border border-rose-500/30", children: [s.jsx("div", {className:"font-bold text-rose-300 mb-1", children:"📦 الأحراز:"}), s.jsx("p", {className:"text-slate-300 text-[11px]", children:currentCase.evidenceAr})] }),
                          s.jsxs("div", { className: "p-2.5 rounded-xl bg-slate-900 border border-amber-500/30", children: [s.jsx("div", {className:"font-bold text-amber-300 mb-1", children:"🗣️ الاعتراف:"}), s.jsx("p", {className:"text-slate-300 text-[11px] italic", children:`"${currentCase.confessionAr}"`})] }),
                          s.jsxs("div", { className: "p-2.5 rounded-xl bg-slate-900 border border-blue-500/30", children: [s.jsx("div", {className:"font-bold text-blue-300 mb-1", children:"👨‍🏫 رأي الأخصائي:"}), s.jsx("p", {className:"text-slate-300 text-[11px]", children:currentCase.witnessAr})] })
                        ]
                      }),
                      s.jsxs("div", {
                        className: "grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2",
                        children: [
                          s.jsx("button", { onClick: () => handleIssueVerdict(currentCase, "service"), className: "p-2 rounded-xl bg-emerald-600/20 border border-emerald-500/50 hover:bg-emerald-600/40 text-emerald-300 text-xs font-bold cursor-pointer", children: "🧹 خدمة مجتمعية بالمكتبة" }),
                          s.jsx("button", { onClick: () => handleIssueVerdict(currentCase, "suspension"), className: "p-2 rounded-xl bg-rose-600/20 border border-rose-500/50 hover:bg-rose-600/40 text-rose-300 text-xs font-bold cursor-pointer", children: "🚫 فصل تأديبي 3 أيام" }),
                          s.jsx("button", { onClick: () => handleIssueVerdict(currentCase, "pledge"), className: "p-2 rounded-xl bg-amber-600/20 border border-amber-500/50 hover:bg-amber-600/40 text-amber-300 text-xs font-bold cursor-pointer", children: "📝 تعهد واستدعاء ولي الأمر" }),
                          s.jsx("button", { onClick: () => handleIssueVerdict(currentCase, "amnesty"), className: "p-2 rounded-xl bg-blue-600/20 border border-blue-500/50 hover:bg-blue-600/40 text-blue-300 text-xs font-bold cursor-pointer", children: "🕊️ عفو تربوي وإرشاد" })
                        ]
                      })
                    ]
                  });
                })()
              ]
            }),

            // 3. Desk Phone Intercom View
            activeTab === "phone" && s.jsxs("div", {
              className: "grid grid-cols-1 md:grid-cols-2 gap-4 animate-in fade-in duration-150",
              children: [
                s.jsxs("div", {
                  className: "p-4 rounded-3xl bg-slate-850 border border-amber-500/40 space-y-3",
                  children: [
                    s.jsx("div", { className: "text-xs font-black text-amber-300", children: "☎️ لوحة الاتصال الداخلي بمكتب الناظر:" }),
                    s.jsxs("div", {
                      className: "p-2.5 rounded-xl bg-black/60 border border-amber-500/40 flex items-center justify-between font-mono",
                      children: [
                        s.jsx("span", { className: "text-2xl font-bold text-amber-400 tracking-widest", children: dialNumber || "طلب رقم..." }),
                        s.jsx("button", { onClick: () => setDialNumber(""), className: "text-xs text-rose-400 font-bold cursor-pointer", children: "مسح ✖" })
                      ]
                    }),
                    s.jsx("div", {
                      className: "grid grid-cols-3 gap-2",
                      children: ["1","2","3","4","5","6","7","8","9","*","0","#"].map(num => s.jsx("button", {
                        key: num,
                        onClick: () => handleDialNumber(num),
                        className: "h-10 rounded-xl bg-slate-800 hover:bg-amber-500 hover:text-slate-950 text-white font-bold text-base border border-slate-700 cursor-pointer active:scale-95 transition-all font-mono",
                        children: num
                      }))
                    }),
                    s.jsx("button", {
                      onClick: () => handleMakeCall(dialNumber),
                      disabled: !dialNumber,
                      className: "w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white font-black text-xs flex items-center justify-center gap-1.5 cursor-pointer",
                      children: [s.jsx("span", {children:"📞"}), s.jsx("span", {children:"اتصال بالخط الداخلي"})]
                    })
                  ]
                }),
                s.jsxs("div", {
                  className: "space-y-2.5",
                  children: [
                    callActive && callDetails && s.jsxs("div", {
                      className: "p-3 rounded-2xl bg-emerald-950/60 border-2 border-emerald-500 space-y-1.5 animate-in zoom-in-95",
                      children: [
                        s.jsxs("div", { className: "flex items-center justify-between", children: [s.jsxs("div", {className:"flex items-center gap-1.5 font-bold text-emerald-300 text-xs", children:[s.jsx("span", {children:callDetails.icon}), s.jsx("span", {children:callDetails.deptAr})]}), s.jsx("span", {className:"text-[10px] text-emerald-400 animate-pulse font-mono", children:"● CONNECTED"})] }),
                        s.jsx("p", { className: "text-xs text-slate-100 font-bold", children: `"${callDetails.replyAr}"` }),
                        s.jsx("button", { onClick: () => setCallActive(false), className: "w-full py-1 rounded-lg bg-rose-600/80 hover:bg-rose-600 text-[11px] font-bold text-white cursor-pointer", children: "إنهاء المكالمة 📵" })
                      ]
                    }),
                    s.jsxs("div", {
                      className: "p-3 rounded-2xl bg-slate-850 border border-slate-700 space-y-1.5 max-h-[300px] overflow-y-auto",
                      children: [
                        s.jsx("div", { className: "text-xs font-black text-amber-300 mb-1", children: "📖 دليل الخطوط السريعة:" }),
                        phoneBook.map(contact => s.jsxs("button", {
                          key: contact.code,
                          onClick: () => { setDialNumber(contact.code); handleMakeCall(contact.code); },
                          className: "w-full p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-right flex items-center justify-between cursor-pointer",
                          children: [
                            s.jsxs("div", { className: "flex items-center gap-2", children: [s.jsx("span", {children:contact.icon}), s.jsx("span", {className:"text-xs font-bold text-slate-200", children:contact.deptAr})] }),
                            s.jsx("span", { className: "text-xs font-mono font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded", children: contact.code })
                          ]
                        }))
                      ]
                    })
                  ]
                })
              ]
            }),

            // 4. THE 100 GRAND ADDITIONS GRID (Filtered by tab or all)
            (activeTab === "all" || ["gadgets","secrets","decrees","trophies","festivals"].includes(activeTab)) && s.jsxs("div", {
              className: "space-y-3 animate-in fade-in duration-150",
              children: [
                s.jsxs("div", {
                  className: "flex items-center justify-between text-xs text-slate-400 px-1 font-bold",
                  children: [
                    s.jsxs("span", { children: ["عرض ", filtered100.length, " من أصل 100 إضافة فريدة"] }),
                    s.jsxs("span", { className: "text-purple-300 font-mono", children: ["المفعل: ", activatedIds.length, " / 100"] })
                  ]
                }),
                s.jsx("div", {
                  className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3",
                  children: filtered100.map(item => {
                    const isActivated = activatedIds.includes(item.num);
                    return s.jsxs("div", {
                      key: item.num,
                      className: `p-3.5 rounded-2xl bg-slate-850 border transition-all flex flex-col justify-between min-h-[175px] relative overflow-hidden ${isActivated ? "border-emerald-500/80 bg-gradient-to-b from-slate-850 to-emerald-950/20 shadow-lg shadow-emerald-500/10" : "border-slate-750 hover:border-purple-500/60"}`,
                      children: [
                        // Top badge & number
                        s.jsxs("div", {
                          className: "flex items-center justify-between pb-2 border-b border-slate-700/80",
                          children: [
                            s.jsxs("div", {
                              className: "flex items-center gap-2",
                              children: [
                                s.jsx("div", { className: "w-8 h-8 rounded-xl bg-purple-500/20 border border-purple-400 flex items-center justify-center text-lg shrink-0", children: item.icon }),
                                s.jsxs("div", {
                                  children: [
                                    s.jsxs("div", { className: "flex items-center gap-1.5", children: [s.jsx("span", {className:"text-[10px] font-mono font-black text-purple-400", children:`#${item.num}`}), s.jsx("h4", {className:"text-xs font-black text-white line-clamp-1", children:n ? item.titleAr : item.titleEn})] }),
                                    s.jsx("span", { className: "text-[10px] text-amber-400 font-bold", children: item.rewardAr })
                                  ]
                                })
                              ]
                            }),
                            isActivated ? s.jsx("span", { className: "px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-400 text-emerald-300 text-[10px] font-black shrink-0", children: "✓ مفعل" }) : (item.cost > 0 ? s.jsxs("span", { className: "px-2 py-0.5 rounded-full bg-amber-500/20 border border-amber-400 text-amber-300 text-[10px] font-black font-mono shrink-0", children: [item.cost, " ج.م"] }) : s.jsx("span", { className: "px-2 py-0.5 rounded-full bg-blue-500/20 border border-blue-400 text-blue-300 text-[10px] font-black shrink-0", children: "مجاني ✨" }))
                          ]
                        }),

                        // Description
                        s.jsx("p", {
                          className: "text-[11px] text-slate-300 leading-relaxed my-2 line-clamp-2",
                          children: n ? item.descAr : item.descEn
                        }),

                        // Bottom Action Button
                        s.jsxs("div", {
                          className: "pt-1 border-t border-slate-700/50 flex items-center justify-between text-[10px]",
                          children: [
                            s.jsxs("span", { className: "text-slate-400 font-bold", children: ["+ ", item.rep, " سمعة | + ", item.morale, "% معنويات"] }),
                            s.jsxs("button", {
                              onClick: () => handleActivateItem(item),
                              className: `px-3 py-1.5 rounded-xl font-black flex items-center gap-1 transition-all cursor-pointer active:scale-95 ${isActivated ? "bg-slate-800 text-emerald-300 border border-emerald-500/40 hover:bg-slate-750" : "bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-md shadow-purple-600/30"}`,
                              children: [
                                s.jsx("span", { children: isActivated ? "🔄" : "⚡" }),
                                s.jsx("span", { children: isActivated ? (n ? "إعادة تشغيل" : "Re-trigger") : (n ? "تفعيل واعتماد" : "Activate") })
                              ]
                            })
                          ]
                        })
                      ]
                    });
                  })
                })
              ]
            })
          ]
        })
      ]
    })
  });
};
'''

code = code[:pos_start] + new_code + code[pos_end:]

with open("assets/app-bundle.js", "w") as f:
    f.write(code)
with open("assets/index-BeRTxH1o.js", "w") as f:
    f.write(code)

for dist_js in glob.glob("dist/assets/*.js"):
    if "index" in dist_js or "app" in dist_js or "BeRTxH1o" in dist_js or "Bmv5j8km" in dist_js:
        with open(dist_js, "w") as f:
            f.write(code)
        print("Updated dist file:", dist_js)

ts = int(time.time())
with open("index.html", "r") as f:
    html = f.read()

html = re.sub(r'app-bundle\.js\?v=\d+', f'app-bundle.js?v={ts}', html)
html = re.sub(r'app-bundle\.css\?v=\d+', f'app-bundle.css?v={ts}', html)

with open("index.html", "w") as f:
    f.write(html)
with open("dist/index.html", "w") as f:
    f.write(html)

print("SUCCESS: 100 BRAND NEW NOVEL ADDITIONS & SIMULATION SUITE INJECTED!")
