
import fs from "fs";
import vm from "vm";

const code = fs.readFileSync("public/assets/app-bundle.js", "utf8");
const lines = code.split("\n");
console.log("Total lines:", lines.length);

let low = 0;
let high = lines.length;
let errLine = -1;

while (low <= high) {
  let mid = Math.floor((low + high) / 2);
  let chunk = lines.slice(0, mid).join("\n") + "\nexport default 1;";
  try {
    new vm.SourceTextModule(chunk);
    low = mid + 1;
  } catch(e) {
    if (e.message && e.message.includes("missing ) after argument list")) {
      errLine = mid;
      high = mid - 1;
    } else {
      low = mid + 1;
    }
  }
}

console.log("Error line index:", errLine);
if (errLine > 0) {
  console.log("Line content:", lines[errLine - 1]);
}
