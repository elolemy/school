import re
import time
import glob

with open("assets/app-bundle.js", "r") as f:
    code = f.read()

# 1. Remove from Eo
eo_item = '{id:"student_national_id",labelAr:"🪪 بطاقة الطالب القومية",labelEn:"🪪 Student National ID",icon:"🪪"},'
assert eo_item in code, "eo_item not found in code"
code = code.replace(eo_item, "")
print("1. Removed student_national_id from Eo array")

# 2. Also remove the old conditional spread render if present
old_render = '(Zt==="all"||Zt==="student_national_id")&&Oi&&s.jsxs("div",{className:"space-y-3 animate-in fade-in duration-150 flex flex-col items-center py-2",children:[s.jsx("div",{className:"w-full max-w-md bg-blue-900/10 p-2.5 rounded-2xl border border-blue-500/30 text-xs text-center font-black text-blue-900 dark:text-blue-300",children:"🪪 بطاقة الرقم القومي المصرية للطالب (صادرة حصرياً لطلاب مرحلة الثانوية العامة - 16 سنة فما فوق)"}),s.jsx(GDe,{student:a})]}),'
if old_render in code:
    code = code.replace(old_render, "")
    print("2. Removed student_national_id render section")
else:
    print("Old render pattern not exact match, let us search via regex")
    code = re.sub(r'\(Zt==="all"\|\|Zt==="student_national_id"\)[^;]*?s\.jsx\(GDe,\{student:a\}\)\]\}\),?', '', code)

with open("assets/app-bundle.js", "w") as f:
    f.write(code)
with open("assets/index-BeRTxH1o.js", "w") as f:
    f.write(code)

for dist_js in glob.glob("dist/assets/*.js"):
    if "index" in dist_js or "app" in dist_js or "BeRTxH1o" in dist_js or "CwhFnn8I" in dist_js:
        with open(dist_js, "w") as f:
            f.write(code)
        print("Updated dist file:", dist_js)

ts = int(time.time())
with open("index.html", "r") as f:
    html = f.read()

html = re.sub(r'app-bundle\.js\?v=\d+', f'app-bundle.js?v={ts}', html)
html = re.sub(r'app-bundle\.css\?v=\d+', f'app-bundle.css?v={ts}', html)

with open("index.html", "w") as f:
    f.write(html)
with open("dist/index.html", "w") as f:
    f.write(html)

print("SUCCESS: Removed student national ID card completely!")
