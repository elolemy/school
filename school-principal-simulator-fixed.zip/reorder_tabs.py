import re
import time
import glob

with open("assets/app-bundle.js", "r") as f:
    code = f.read()

eo_start = code.find("Eo=[")
eo_end = code.find("tc=()=>{", eo_start)
assert eo_start != -1 and eo_end != -1, "Eo not found"

new_eo_items = '''Eo=[
  {id:"all",labelAr:(a==null?void 0:a.stage)==="university"||a!=null&&a.universityDossier?"📑 فرد جميع الأوراق والملف الجامعي":"📑 فرد جميع الأوراق",labelEn:"📑 Spread All Sheets",icon:"📑"},
  {id:"main",labelAr:"📄 استمارة التقديم",labelEn:"📄 Application Form",icon:"📄"},
  {id:"student_profile_card",labelAr:"🧑‍🎓 بطاقة الطالب الشخصية",labelEn:"🧑‍🎓 Student Profile",icon:"🧑‍🎓"},
  {id:"birth_cert",labelAr:"📜 شهادة الميلاد المميكنة",labelEn:"📜 Birth Certificate",icon:"📜"},
  {id:"receipt",labelAr:"🧾 إيصال المصروفات البنكي",labelEn:"🧾 Tuition Receipt",icon:"🧾"},
  {id:"vaccine",labelAr:"💉 كارت التطعيمات والصحة",labelEn:"💉 Health Card",icon:"💉"},
  {id:"transfer",labelAr:"🏫 إخلاء طرف المدرسة السابقة",labelEn:"🏫 School Transfer",icon:"🏫"},
  {id:"national_id",labelAr:"🪪 بطاقة ولي الأمر",labelEn:"🪪 Guardian ID",icon:"🪪"},
  {id:"residence_proof",labelAr:"🏠 إثبات السكن والمرافق",labelEn:"🏠 Residence Proof",icon:"🏠"},
  {id:"parent_work_cert",labelAr:"🏢 جهة عمل ولي الأمر",labelEn:"🏢 Guardian Work Cert",icon:"🏢"},
  {id:"conduct_cert",labelAr:"🎖️ حسن السير والسلوك",labelEn:"🎖️ Conduct Cert",icon:"🎖️"},
  {id:"talents_cert",labelAr:"🏆 كشف المواهب والبطولات",labelEn:"🏆 Talents & Awards",icon:"🏆"},
  {id:"health_dossier",labelAr:"🩺 الفحص الإكلينيكي",labelEn:"🩺 Clinical Health",icon:"🩺"},
  {id:"medical_fitness",labelAr:"🏥 فحص النظر والسمع",labelEn:"🏥 Vision & Hearing",icon:"🏥"},
  {id:"tablet_receipt",labelAr:"📱 إقرار استلام التابلت",labelEn:"📱 Tablet Bond",icon:"📱"},
  {id:"social_worker_report",labelAr:"📋 تقرير الأخصائي الاجتماعي",labelEn:"📋 Social Worker Report",icon:"📋"},
  {id:"bus_subscription",labelAr:"🚌 تصريح الحافلة المدرسية",labelEn:"🚌 Bus Pass",icon:"🚌"},
  {id:"food_allergy_cert",labelAr:"🥗 بطاقة التغذية المدرسية",labelEn:"🥗 Nutrition Card",icon:"🥗"},
  {id:"language_proficiency",labelAr:"🌐 إفادة المستوى الرفيع للغات",labelEn:"🌐 Languages Cert",icon:"🌐"},
  {id:"iq_olympiad_cert",labelAr:"🧠 شهادة اختبار الذكاء IQ",labelEn:"🧠 Gifted IQ Cert",icon:"🧠"},
  {id:"scout_camp_permit",labelAr:"⛺ تصريح المعسكرات الكشفية",labelEn:"⛺ Scout Camp Permit",icon:"⛺"},
  {id:"arabic_calligraphy_diploma",labelAr:"✍️ إجازة الخط العربي",labelEn:"✍️ Calligraphy Diploma",icon:"✍️"},
  {id:"anti_bullying_pledge",labelAr:"🛡️ وثيقة مكافحة التنمر",labelEn:"🛡️ Anti-Bullying Charter",icon:"🛡️"},
  {id:"library_membership",labelAr:"📚 بطاقة عضوية المكتبة",labelEn:"📚 Library Card",icon:"📚"},
  {id:"robotics_badge",labelAr:"🤖 شهادة دوري الروبوتات والـAI",labelEn:"🤖 Robotics & AI",icon:"🤖"},
  {id:"chess_accreditation",labelAr:"♟️ بطاقة اتحاد الشطرنج",labelEn:"♟️ Chess Federation",icon:"♟️"},
  {id:"innovation_patent",labelAr:"💡 براءة الاختراع للناشئين",labelEn:"💡 Junior Patent",icon:"💡"},
  {id:"club_membership",labelAr:"⚽ كارنيه النادي الرياضي",labelEn:"⚽ Sports Club Card",icon:"⚽"},
  {id:"pledge",labelAr:"✍️ وثيقة تعهد ولي الأمر",labelEn:"✍️ Parent Pledge",icon:"✍️"},
  {id:"donation",labelAr:"🤝 استمارة تبرع الأنشطة",labelEn:"🤝 School Donation",icon:"🤝"},
  {id:"mother_id",labelAr:"👩 بطاقة الرقم القومي للأم",labelEn:"👩 Mother ID",icon:"👩"},
  {id:"sibling_cert",labelAr:"👶 شهادة قيد الأخوة",labelEn:"👶 Sibling Cert",icon:"👶"},
  {id:"pregnancy_cert",labelAr:"🩺 الحالة الصحية للأسرة",labelEn:"🩺 Family Health",icon:"🩺"},
  {id:"marriage_cert",labelAr:"💍 قيد الأسرة المميكن",labelEn:"💍 Family Registry",icon:"💍"},
  {id:"disciplinary_record",labelAr:"📝 تقويم السلوك والانضباط",labelEn:"📝 Behavior Log",icon:"📝"},
  {id:"visa_card",labelAr:"💳 فيزا ميزة للطالب",labelEn:"💳 Student Meeza Card",icon:"💳"},
  ...(a==null?void 0:a.gender)==="male"?[{id:"military_cert",labelAr:"🛡️ نموذج 2 جند (التجنيد)",labelEn:"🛡️ Military Service",icon:"🛡️"}]:[],
  ...bi?[{id:"nomination_card",labelAr:"🏛️ بطاقة الترشيح (3 ثانوي)",labelEn:"🏛️ Nomination Card",icon:"🏛️"}]:[],
  ...(a==null?void 0:a.stage)==="university"||a!=null&&a.universityDossier?[{id:"university_dossier",labelAr:"🏛️ بطاقة الترشيح والملف الجامعي",labelEn:"🏛️ University Dossier",icon:"🏛️"}]:[]
],'''

code = code[:eo_start] + new_eo_items + code[eo_end:]

with open("assets/app-bundle.js", "w") as f:
    f.write(code)
with open("assets/index-BeRTxH1o.js", "w") as f:
    f.write(code)

for dist_js in glob.glob("dist/assets/*.js"):
    if "index" in dist_js or "app" in dist_js or "BeRTxH1o" in dist_js or "BoWY_e0a" in dist_js or "CwhFnn8I" in dist_js or "C9sCu8NM" in dist_js or "QB4pRpBj" in dist_js:
        with open(dist_js, "w") as f:
            f.write(code)
        print("Updated dist file:", dist_js)

ts = int(time.time())
with open("index.html", "r") as f:
    html = f.read()

html = re.sub(r'app-bundle\.js\?v=\d+', f'app-bundle.js?v={ts}', html)
html = re.sub(r'app-bundle\.css\?v=\d+', f'app-bundle.css?v={ts}', html)

with open("index.html", "w") as f:
    f.write(html)
with open("dist/index.html", "w") as f:
    f.write(html)

print("SUCCESS: Put 'فرد جميع الأوراق' first and 'استمارة التقديم' directly after it!")
