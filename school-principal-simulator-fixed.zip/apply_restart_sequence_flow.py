import subprocess

print("Applying ordered onboarding sequence [Regulations -> Story -> Instructions] and suppressing morning routine popups...")

for path in ["public/assets/app-bundle.js", "assets/app-bundle.js"]:
    print(f"Updating {path}...")
    with open(path, "r") as f:
        c = f.read()

    # 0. Global variable
    c = c.replace(
        "window.__morningRoutineGuard=window.__morningRoutineGuard||",
        "window.__isRestartSequence=window.__isRestartSequence||!1;window.__morningRoutineGuard=window.__morningRoutineGuard||"
    )

    # 1. onRestartStory handler (e)
    target1 = "u(!0),Js(!1),p(!1),is(!1)}"
    repl1 = "window.__isRestartSequence=!0,u(!1),p(!0),is(!1),we(!1),Js(!1),c(\"desk\")}"
    if target1 in c:
        c = c.replace(target1, repl1)
        print("  Updated e (onRestartStory) to initialize sequence and open JDe")
    else:
        print("  WARNING: target1 not found!")

    # 2. onStartGame & onStartMorningRoutine
    target2 = 'onStartGame:()=>{window.__morningRoutineGuard.start();I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!0);is(!1);we(!1);Js(!1);c("desk")},onStartMorningRoutine:()=>{window.__morningRoutineGuard.start();I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!0);is(!1);we(!1);Js(!1);c("desk")}'
    repl2 = 'onStartGame:()=>{window.__isRestartSequence=!1;I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:null}));u(!1);p(!1);is(!1);we(!1);Js(!1);c("desk")},onStartMorningRoutine:()=>{window.__isRestartSequence=!1;I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:null}));u(!1);p(!1);is(!1);we(!1);Js(!1);c("desk")}'
    if target2 in c:
        c = c.replace(target2, repl2)
        print("  Updated onStartGame and onStartMorningRoutine to go straight to desk")
    else:
        print("  WARNING: target2 not found!")

    # 3. JDe onStartDay
    target3 = 'onStartDay:()=>{p(!1);window.__morningRoutineGuard.advanceFrom("decisions");I.playSchoolBell();l(ae=>({...ae,isDayStarted:!0}))}'
    repl3 = 'onStartDay:()=>{p(!1);if(window.__isRestartSequence){I.playRulebookOpen();is(!0)}else{I.playSchoolBell();l(ae=>({...ae,isDayStarted:!0,currentEvent:null}))}}'
    if target3 in c:
        c = c.replace(target3, repl3)
        print("  Updated JDe onStartDay to chain to Story if restarting")
    else:
        print("  WARNING: target3 not found!")

    # 4. aZe onClose
    target4 = 's.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1);l(pe=>({...pe,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));window.__morningRoutineGuard.reset();we(!1);p(!1)},'
    repl4 = 's.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1);if(window.__isRestartSequence){I.playPaperSlide();Js(!0)}else{l(pe=>({...pe,currentEvent:null}))}},'
    if target4 in c:
        c = c.replace(target4, repl4)
        print("  Updated aZe onClose to chain to Instructions if restarting")
    else:
        print("  WARNING: target4 not found!")

    # 5. wXe onClose
    target5 = 's.jsx(wXe,{isOpen:fr,onClose:()=>{Js(!1);try{localStorage.setItem("school_tutorial_completed","true")}catch{}const next=window.__morningRoutineGuard.advanceFrom("instructions");if(next==="story"){p(!1);we(!1);is(!0)}},language:i.settings.language})'
    repl5 = 's.jsx(wXe,{isOpen:fr,onClose:()=>{Js(!1);try{localStorage.setItem("school_tutorial_completed","true")}catch{}if(window.__isRestartSequence){window.__isRestartSequence=!1;l(pe=>({...pe,isDayStarted:!0,currentEvent:null}));c("desk")}},language:i.settings.language})'
    if target5 in c:
        c = c.replace(target5, repl5)
        print("  Updated wXe onClose to finish sequence cleanly on desk")
    else:
        print("  WARNING: target5 not found!")

    with open(path, "w") as f:
        f.write(c)

    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check!")
    else:
        print(f"  ERROR: {path} syntax error:\n{res.stderr[:400]}")
        exit(1)

print("All updates successfully applied!")
