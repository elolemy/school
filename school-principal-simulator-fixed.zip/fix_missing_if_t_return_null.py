import subprocess

print("Fixing missing if(!t)return null; in wXe and aZe...")

for target_file in ["assets/app-bundle.js", "public/assets/app-bundle.js"]:
    print(f"Updating {target_file}...")
    with open(target_file, "r") as f:
        code = f.read()

    # 1. Add if(!t)return null; at start of wXe
    # wXe=({isOpen:t,onClose:e,language:r="ar"})=>{
    code = code.replace(
        'wXe=({isOpen:t,onClose:e,language:r="ar"})=>{',
        'wXe=({isOpen:t,onClose:e,language:r="ar"})=>{if(!t)return null;'
    )

    # 2. Add if(!t)return null; at start of aZe
    # aZe=({isOpen:t,onClose:e,currentDay:r
    code = code.replace(
        'aZe=({isOpen:t,onClose:e,currentDay:r',
        'aZe=({isOpen:t,onClose:e,currentDay:r,schoolName:a,reputation:n,budget:i,isInternetConnected:l,dailyStoryProgress:o,storyChaptersState:c,onStoryChoiceMade:d,onClaimChapterReward:u,onClaimSagaReward:m,onToggleBookmarkDay:p,difficulty:h="medium",onRestartStory:E})=>{if(!t)return null;'
    )
    # also handle if signature differs slightly
    if 'aZe=({isOpen:t' in code and 'if(!t)return null;' not in code[code.find('aZe='):code.find('aZe=')+200]:
        idx = code.find('aZe=({isOpen:t')
        brace_idx = code.find('=>{', idx)
        code = code[:brace_idx+3] + 'if(!t)return null;' + code[brace_idx+3:]

    with open(target_file, "w") as f:
        f.write(code)

    # Validate with node
    res = subprocess.run(["node", "--input-type=module", "-c"], input=code, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"SUCCESS: {target_file} passed syntax validation!")
    else:
        print(f"ERROR in {target_file}:\n{res.stderr}")
        exit(1)

print("All files updated successfully!")
