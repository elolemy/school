import re

print("Fixing all broken syntax snippets in both bundles...")

clean_on_start_game = 'onStartGame:()=>{I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!1);is(!1);we(!1);window.__morningRoutineStep="tutorial";Js(!0);c("desk")}'

clean_on_start_morning_routine = 'onStartMorningRoutine:()=>{I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!1);is(!1);we(!1);window.__morningRoutineStep="tutorial";Js(!0);c("desk")}'

for target_file in ["assets/app-bundle.js", "public/assets/app-bundle.js"]:
    print(f"Cleaning {target_file}...")
    with open(target_file, "r") as f:
        code = f.read()

    # Replace broken onStartGame
    code = re.sub(
        r'onStartGame:\(\)=>\{[^\}]+c\("desk"\)[^\}]*\}',
        clean_on_start_game,
        code
    )

    # Replace broken onStartMorningRoutine
    code = re.sub(
        r'onStartMorningRoutine:\(\)=>\{[^\}]+c\("desk"\)[^\}]*\}',
        clean_on_start_morning_routine,
        code
    )

    # Replace any stray leftovers between c("desk") and onRestartStory
    code = re.sub(
        r'c\("desk"\)\}[^\}]+onRestartStory:',
        'c("desk")},onRestartStory:',
        code
    )

    # Replace any stray leftovers between c("desk") and onStartMorningRoutine
    code = re.sub(
        r'c\("desk"\)\}[^\}]+onStartMorningRoutine:',
        'c("desk")},onStartMorningRoutine:',
        code
    )

    with open(target_file, "w") as f:
        f.write(code)

print("Finished cleaning bundles.")
