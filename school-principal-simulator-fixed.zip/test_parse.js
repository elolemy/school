
const fs = require("fs");
const code = fs.readFileSync("./public/assets/app-bundle.js", "utf8");
try {
  new Function(code);
  console.log("No syntax error in Function(code)");
} catch (e) {
  console.log("Syntax error msg:", e.message);
  console.log("Syntax error stack:", e.stack);
}
