import re

print("Applying fixes for Regulations Guide, Educational Tutorial Guide, and Story flow...")

with open("assets/app-bundle.js", "r") as f:
    code = f.read()

# 1. Update uDe navbar to include both Tutorial Guide and Rulebook buttons prominently
old_rulebook_nav = 'l&&s.jsx("button",{id:"btn-navbar-rulebook",onClick:l,title:we.rulebookTitle,className:"p-2 rounded-lg border border-amber-500/40 bg-amber-500/15 text-amber-400 hover:bg-amber-500/25 transition-all shadow-sm",children:s.jsx(ya,{className:"w-4 h-4"})})'

new_nav_guides = '''s.jsxs("button",{id:"btn-navbar-tutorial",onClick:()=>{window.dispatchEvent(new CustomEvent("open-tutorial"))},title:de==="ar"?"الدليل التعليمي الشامل وتوجيهات المدير":"Comprehensive Educational & Tutorial Guide",className:"p-2 rounded-lg border border-emerald-500/40 bg-emerald-500/15 text-emerald-300 hover:bg-emerald-500/25 transition-all shadow-sm flex items-center gap-1.5 font-bold text-xs",children:[s.jsx(Vt,{className:"w-4 h-4 text-emerald-400"}),s.jsx("span",{className:"hidden sm:inline",children:de==="ar"?"الدليل التعليمي 🎓":"Tutorial 🎓"})]}),s.jsxs("button",{id:"btn-navbar-rulebook",onClick:l||(()=>{window.dispatchEvent(new CustomEvent("open-rulebook"))}),title:de==="ar"?"دليل اللوائح الوزارية والاشتراطات الرسمية":"Ministerial Regulations & Rulebook",className:"p-2 rounded-lg border border-amber-500/40 bg-amber-500/15 text-amber-300 hover:bg-amber-500/25 transition-all shadow-sm flex items-center gap-1.5 font-bold text-xs",children:[s.jsx(ya,{className:"w-4 h-4 text-amber-400"}),s.jsx("span",{className:"hidden sm:inline",children:de==="ar"?"دليل اللوائح 📘":"Rulebook 📘"})]}),C&&s.jsxs("button",{id:"btn-navbar-daily-story",onClick:C,title:de==="ar"?`قصة ووقائع اليوم الدراسي (${t.currentDay})`:`Academic Day Story (${t.currentDay})`,className:"p-2 rounded-lg border border-indigo-500/40 bg-indigo-500/15 text-indigo-300 hover:bg-indigo-500/25 transition-all shadow-sm flex items-center gap-1.5 font-bold text-xs",children:[s.jsx(Fr,{className:"w-4 h-4 text-indigo-400"}),s.jsx("span",{className:"hidden sm:inline",children:de==="ar"?`قصة يوم ${t.currentDay} 📖`:`Day ${t.currentDay} Story 📖`})]})'''

if old_rulebook_nav in code:
    code = code.replace(old_rulebook_nav, new_nav_guides, 1)
    print("✓ Successfully replaced navbar buttons in uDe")
else:
    print("✗ Could not find exact old_rulebook_nav string")

# 2. Update JDe component signature and buttons
old_jde_sig = 'JDe=({state:t,language:e,onStartDay:r,onOpenTutorial:a,onOpenDailyStory:n})=>'
new_jde_sig = 'JDe=({state:t,language:e,onStartDay:r,onOpenTutorial:a,onOpenDailyStory:n,onOpenRulebook:l})=>'

if old_jde_sig in code:
    code = code.replace(old_jde_sig, new_jde_sig, 1)
    print("✓ Successfully updated JDe signature")
else:
    print("! Checking JDe signature variant...")
    code = re.sub(r'JDe=\(\{state:t,language:e,onStartDay:r,onOpenTutorial:a,onOpenDailyStory:n(\})=>', r'JDe=({state:t,language:e,onStartDay:r,onOpenTutorial:a,onOpenDailyStory:n,onOpenRulebook:l})=>', code)

# In JDe footer buttons, make sure we have Story, Tutorial Guide, and Rulebook Guide all nicely displayed:
old_jde_buttons = '''s.jsxs("div",{className:"flex flex-wrap items-center justify-between gap-3 p-3 rounded-2xl bg-slate-950/80 border border-slate-800 mb-4 text-xs",children:[n&&s.jsxs("button",{type:"button",onClick:()=>{I.playRulebookOpen(),n()},className:"px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-600/30 to-amber-700/40 hover:from-amber-600/50 hover:to-amber-700/60 text-amber-200 border border-amber-500/40 font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all",children:[s.jsx(ya,{className:"w-4 h-4 text-amber-400"}),s.jsx("span",{children:i?`📖 قراءة وقائع ورواية اليوم (${t.currentDay})`:`📖 Read Today's Story (Day ${t.currentDay})`})]}),a&&s.jsxs("button",{type:"button",onClick:()=>{I.playPaperSlide(),a()},className:"px-2.5 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 font-bold text-[11px] flex items-center gap-1 transition-colors",children:[s.jsx(L$,{className:"w-3.5 h-3.5 text-amber-400"}),s.jsx("span",{children:i?"عرض التعليمات":"Instructions"})]})]})'''

new_jde_buttons = '''s.jsxs("div",{className:"flex flex-wrap items-center justify-between gap-2.5 p-3 rounded-2xl bg-slate-950/90 border-2 border-amber-500/40 mb-4 text-xs",children:[n&&s.jsxs("button",{type:"button",onClick:()=>{I.playRulebookOpen(),n()},className:"px-3 py-2 rounded-xl bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-200 border border-indigo-500/50 font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all",children:[s.jsx(Fr,{className:"w-4 h-4 text-indigo-400"}),s.jsx("span",{children:i?`📖 قصة ووقائع اليوم (${t.currentDay})`:`📖 Today Story (Day ${t.currentDay})`})]}),a&&s.jsxs("button",{type:"button",onClick:()=>{I.playPaperSlide(),a()},className:"px-3 py-2 rounded-xl bg-emerald-600/30 hover:bg-emerald-600/50 text-emerald-200 border border-emerald-500/50 font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all",children:[s.jsx(Vt,{className:"w-4 h-4 text-emerald-400"}),s.jsx("span",{children:i?"🎓 الدليل التعليمي للمدير":"🎓 Tutorial Guide"})]}),s.jsxs("button",{type:"button",onClick:()=>{I.playRulebookOpen(),l?l():window.dispatchEvent(new CustomEvent("open-rulebook"))},className:"px-3 py-2 rounded-xl bg-amber-600/30 hover:bg-amber-600/50 text-amber-200 border border-amber-500/50 font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all",children:[s.jsx(ya,{className:"w-4 h-4 text-amber-400"}),s.jsx("span",{children:i?"📘 دليل اللوائح الوزارية":"📘 Ministerial Rulebook"})]})]})'''

if old_jde_buttons in code:
    code = code.replace(old_jde_buttons, new_jde_buttons, 1)
    print("✓ Successfully replaced JDe buttons")
else:
    print("! Looking for JDe buttons with regex...")
    code = re.sub(r's\.jsxs\("div",\{className:"flex flex-wrap items-center justify-between gap-3 p-3 rounded-2xl bg-slate-950/80 border border-slate-800 mb-4 text-xs",children:\[n&&s\.jsxs\("button",.+?Instructions"\}\)\]\}\)\]\}\)', new_jde_buttons, code)

# 3. Update Kat component:
# When daily story aZe is closed, immediately open morning routine JDe: p(!0)
old_story_render = 's.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1),l(pe=>({...pe,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}))},currentDay:i.currentDay'
new_story_render = 's.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1),p(!0),l(pe=>({...pe,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}))},currentDay:i.currentDay'

if old_story_render in code:
    code = code.replace(old_story_render, new_story_render, 1)
    print("✓ Successfully updated aZe onClose to trigger morning briefing p(!0)")
else:
    print("! Could not find exact old_story_render, searching...")

# 4. In Kat, pass onOpenRulebook to JDe
old_jde_render = 'm&&!d&&s.jsx(JDe,{state:i,event:i.currentEvent,language:i.settings.language,onStartDay:()=>{p(!1),I.playSchoolBell(),l(ae=>({...ae,isDayStarted:!0})),is(!0)},onOpenTutorial:()=>{Js(!0)},onOpenDailyStory:()=>{is(!0)},onMakeChoice:lc})'
new_jde_render = 'm&&!d&&s.jsx(JDe,{state:i,event:i.currentEvent,language:i.settings.language,onStartDay:()=>{p(!1),I.playSchoolBell(),l(ae=>({...ae,isDayStarted:!0}))},onOpenTutorial:()=>{Js(!0)},onOpenDailyStory:()=>{is(!0)},onOpenRulebook:()=>{we(!0)},onMakeChoice:lc})'

if old_jde_render in code:
    code = code.replace(old_jde_render, new_jde_render, 1)
    print("✓ Successfully updated JDe render in Kat")
else:
    print("! Looking for JDe render variant in Kat...")
    code = code.replace('onOpenDailyStory:()=>{is(!0)},onMakeChoice:lc})', 'onOpenDailyStory:()=>{is(!0)},onOpenRulebook:()=>{we(!0)},onMakeChoice:lc})', 1)

# 5. Add window event listeners for open-tutorial and open-rulebook
old_event_listener = 'window.addEventListener("open-eagle-stamp",rr)'
new_event_listener = 'window.addEventListener("open-eagle-stamp",rr),window.addEventListener("open-tutorial",()=>Js(!0)),window.addEventListener("open-rulebook",()=>we(!0))'

if old_event_listener in code:
    code = code.replace(old_event_listener, new_event_listener, 1)
    print("✓ Successfully added open-tutorial and open-rulebook event listeners")

with open("assets/app-bundle.js", "w") as f:
    f.write(code)

print("Finished applying updates.")
