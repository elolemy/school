import subprocess
import re
import time

print("Updating sheet rendering to hide donation voucher and discipline pledge from 'Spread All Sheets'...")

for path in ["assets/app-bundle.js", "public/assets/app-bundle.js"]:
    print(f"\nProcessing {path}...")
    with open(path, "r") as f:
        c = f.read()

    # 1. Hide donation voucher in 'all' (Spread All Sheets)
    old_donation = '(Zt==="all"||Zt==="donation")&&s.jsxs("div",{className:"space-y-3 animate-in fade-in duration-150 relative bg-white dark:bg-slate-900 p-6 sm:p-8 rounded-2xl shadow-xl border-2 border-emerald-600'
    new_donation = 'Zt==="donation"&&s.jsxs("div",{className:"space-y-3 animate-in fade-in duration-150 relative bg-white dark:bg-slate-900 p-6 sm:p-8 rounded-2xl shadow-xl border-2 border-emerald-600'

    if old_donation in c:
        c = c.replace(old_donation, new_donation, 1)
        print("  Updated donation voucher condition to Zt==='donation' only!")
    else:
        print("  Warning: old_donation not found directly!")

    # 2. Hide guardian discipline pledge in 'all' (Spread All Sheets)
    old_pledge = '(Zt==="all"||Zt==="pledge")&&s.jsx("div",{className:"space-y-3 animate-in fade-in duration-150 relative bg-slate-50 dark:bg-slate-900 p-6 sm:p-8 rounded-lg shadow-sm border-2 border-slate-300'
    new_pledge = 'Zt==="pledge"&&s.jsx("div",{className:"space-y-3 animate-in fade-in duration-150 relative bg-slate-50 dark:bg-slate-900 p-6 sm:p-8 rounded-lg shadow-sm border-2 border-slate-300'

    if old_pledge in c:
        c = c.replace(old_pledge, new_pledge, 1)
        print("  Updated guardian discipline pledge condition to Zt==='pledge' only!")
    else:
        print("  Warning: old_pledge not found directly!")

    with open(path, "w") as f:
        f.write(c)

    res = subprocess.run(["node", "-e", """
const parser = require("@babel/parser");
const fs = require("fs");
const code = fs.readFileSync('""" + path + """', "utf8");
try {
  parser.parse(code, { sourceType: "module", plugins: ["jsx"] });
  console.log("SUCCESS: Babel parsed without error for '""" + path + """'!");
} catch (e) {
  console.log("Error at index:", e.pos, "line:", e.loc.line, "col:", e.loc.column);
  console.log(code.substring(Math.max(0, e.pos - 50), Math.min(code.length, e.pos + 50)));
  process.exit(1);
}
"""], capture_output=True, text=True)
    print(res.stdout)
    if res.returncode != 0:
        print(res.stderr)
        exit(1)

# Update index.html cache buster timestamp
with open("index.html", "r") as f:
    h = f.read()

ts = int(time.time())
h = re.sub(r'app-bundle\.js\?v=[^\"]+', f'app-bundle.js?v={ts}', h)
h = re.sub(r'app-bundle\.css\?v=[^\"]+', f'app-bundle.css?v={ts}', h)

with open("index.html", "w") as f:
    f.write(h)

print(f"\nUpdated index.html cache buster to ?v={ts}!")
print("Done!")
