import subprocess

print("Disabling the administrative principal decision modal after morning routine...")

for path in ["public/assets/app-bundle.js", "assets/app-bundle.js"]:
    print(f"Updating JS bundle at {path}...")
    with open(path, "r") as f:
        c = f.read()

    # 1. Disable _Je (the post-morning routine directive/decision modal)
    if "s.jsx(_Je,{isOpen:xr," in c:
        c = c.replace("s.jsx(_Je,{isOpen:xr,", "s.jsx(_Je,{isOpen:!1,")
        print("  Disabled _Je (isOpen: !1)")
    else:
        print("  WARNING: _Je target not found!")

    # 2. Disable TJe (the morning inspection/decision modal)
    if "s.jsx(TJe,{isOpen:bs," in c:
        c = c.replace("s.jsx(TJe,{isOpen:bs,", "s.jsx(TJe,{isOpen:!1,")
        print("  Disabled TJe (isOpen: !1)")
    else:
        print("  WARNING: TJe target not found!")

    # 3. Replace Tr(!0) with Tr(!1) so state is never set to true
    if "Tr(!0)" in c:
        c = c.replace("Tr(!0)", "Tr(!1)")
        print("  Replaced Tr(!0) with Tr(!1)")

    # 4. Ensure JDe is also disabled
    if "s.jsx(JDe,{" in c and "!1&&s.jsx(JDe,{" not in c:
        c = c.replace("s.jsx(JDe,{", "!1&&s.jsx(JDe,{")
        print("  Ensured JDe is disabled")

    with open(path, "w") as f:
        f.write(c)

    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check!")
    else:
        print(f"  ERROR: {path} syntax error:\n{res.stderr[:400]}")
        exit(1)

print("Finished disabling post-morning routine administrative decision modal!")
