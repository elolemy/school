import subprocess

print("Gating focus subjects and mandatory attendance to advanced days (currentDay >= 10)...")

target = "dren:l.ageRequirements.secondary})]})]})]})]})]}),,\ns.jsxs(\"div\",{className:\"grid grid-cols-1 md:grid-cols-2 gap-3 mb-4\","
replacement = "dren:l.ageRequirements.secondary})]})]})]})]})]}),t.currentDay>=10&&s.jsxs(\"div\",{className:\"grid grid-cols-1 md:grid-cols-2 gap-3 mb-4\","

for path in ["public/assets/app-bundle.js", "assets/app-bundle.js"]:
    print(f"Updating {path}...")
    with open(path, "r") as f:
        c = f.read()

    if target in c:
        c = c.replace(target, replacement)
        print("  Successfully gated focus subjects and attendance with t.currentDay>=10")
    else:
        print("  WARNING: target not found!")

    with open(path, "w") as f:
        f.write(c)

    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check!")
    else:
        print(f"  ERROR: {path} syntax error:\n{res.stderr[:400]}")
        exit(1)

print("Gate successfully applied!")
