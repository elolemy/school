import re
import subprocess

print("Inspecting and updating onStartGame and onStartMorningRoutine...")

clean_start_routine = '()=>{I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!1);is(!1);we(!1);window.__morningRoutineStep="tutorial";Js(!0);c("desk")}'

for target_file in ["assets/app-bundle.js", "public/assets/app-bundle.js"]:
    print(f"Updating {target_file}...")
    with open(target_file, "r") as f:
        code = f.read()

    # Find SJe rendering block
    idx = code.find("s.jsx(SJe,{")
    if idx != -1:
        end_idx = code.find("}),m&&!d&&s.jsx(JDe", idx)
        if end_idx != -1:
            old_block = code[idx:end_idx+3]
            print("Old SJe block length:", len(old_block))

            # Construct clean SJe props block
            new_block = 's.jsx(SJe,{gameState:i,onStartGame:' + clean_start_routine + ',onStartMorningRoutine:' + clean_start_routine + ',onRestartStory:e,onUpdateGameState:ae=>{l(ae),ri(ae)},onOpenSettings:()=>Ae(!0),onOpenRulebook:()=>{window.__morningRoutineStep=null;we(!0)},onOpenTutorial:()=>Js(!0),onOpenAchievements:()=>ye(!0),onOpenSupportChat:()=>Tt(!0),onLogout:r})'
            code = code[:idx] + new_block + code[end_idx+3:]

    # Also update wXe (Tutorial / Instructions) onClose handler
    # Step 1 -> Step 2 (Story: is(!0))
    code = re.sub(
        r's\.jsx\(wXe,\{isOpen:fr,onClose:\(\)=>\{[^\}]+\},language:i\.settings\.language\}\)',
        's.jsx(wXe,{isOpen:fr,onClose:()=>{Js(!1);try{localStorage.setItem("school_tutorial_completed","true")}catch{}if(window.__morningRoutineStep==="tutorial"){window.__morningRoutineStep="story";is(!0)}else{window.__morningRoutineStep=null}},language:i.settings.language})',
        code
    )

    # Also update aZe (Story) onClose handler
    # Step 2 -> Step 3 (Regulations: we(!0))
    code = re.sub(
        r's\.jsx\(aZe,\{isOpen:ms,onClose:\(\)=>\{[^\}]+\},currentDay:i\.currentDay',
        's.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1);l(pe=>({...pe,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));if(window.__morningRoutineStep==="story"){window.__morningRoutineStep="regulations";we(!0)}else{window.__morningRoutineStep=null}},currentDay:i.currentDay',
        code
    )

    # Also update CJe (Regulations) onClose handler
    # Step 3 -> Step 4 (Decisions: p(!0))
    code = re.sub(
        r's\.jsx\(CJe,\{isOpen:de,onClose:\(\)=>\{[^\}]+\},language:i\.settings\.language,isDark:vi\}\)',
        's.jsx(CJe,{isOpen:de,onClose:()=>{we(!1);if(window.__morningRoutineStep==="regulations"){window.__morningRoutineStep=null;p(!0)}else{window.__morningRoutineStep=null}},language:i.settings.language,isDark:vi})',
        code
    )

    with open(target_file, "w") as f:
        f.write(code)

    # Syntax check
    res = subprocess.run(["node", "--input-type=module", "-c"], input=code, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"SUCCESS: {target_file} passed syntax validation!")
    else:
        print(f"ERROR in {target_file}:\n{res.stderr}")
        exit(1)

print("Finished update successfully!")
