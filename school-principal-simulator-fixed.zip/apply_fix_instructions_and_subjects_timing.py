import subprocess

print("Fixing instructions z-index and gating focus subjects & attendance to advanced days...")

for path in ["public/assets/app-bundle.js", "assets/app-bundle.js"]:
    print(f"Updating {path}...")
    with open(path, "r") as f:
        c = f.read()

    # 1. Fix wXe z-index so it appears in front of JDe (zIndex: 9999)
    old_wxe_ret = 'return t?s.jsx("div",{className:"fixed inset-0 z-70 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-in fade-in select-none",children:'
    new_wxe_ret = 'return t?s.jsx("div",{className:"fixed inset-0 z-[200] bg-black/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-in fade-in select-none",style:{zIndex:9999},children:'

    if old_wxe_ret in c:
        c = c.replace(old_wxe_ret, new_wxe_ret)
        print("  Updated wXe z-index to z-[200] + style:{zIndex: 9999}")
    else:
        print("  WARNING: old_wxe_ret not found!")

    # 2. Fix aZe (Daily Story Modal) z-index to be on top of JDe as well
    old_aze_ret = 'return s.jsx("div",{className:"fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-2 md:p-5 overflow-y-auto font-sans",children:'
    new_aze_ret = 'return s.jsx("div",{className:"fixed inset-0 z-[200] flex items-center justify-center bg-black/85 backdrop-blur-md p-2 md:p-5 overflow-y-auto font-sans",style:{zIndex:9999},children:'

    if old_aze_ret in c:
        c = c.replace(old_aze_ret, new_aze_ret)
        print("  Updated aZe z-index to z-[200] + style:{zIndex: 9999}")
    else:
        print("  WARNING: old_aze_ret not found!")

    # 3. Gate core subjects and attendance to advanced days (currentDay >= 10)
    # Search for the grid containing Focus Subjects in JDe
    old_grid_prefix = ',s.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-3 mb-4",children:[  s.jsxs("div",{className:"bg-indigo-950/40 border-2 border-indigo-500/40'
    new_grid_prefix = ',t.currentDay>=10&&s.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-3 mb-4",children:[  s.jsxs("div",{className:"bg-indigo-950/40 border-2 border-indigo-500/40'

    if old_grid_prefix in c:
        c = c.replace(old_grid_prefix, new_grid_prefix)
        print("  Gated focus subjects & attendance grid with t.currentDay>=10")
    else:
        # try without formatting spaces if needed
        import re
        m = re.search(r',s\.jsxs\("div",\{className:"grid grid-cols-1 md:grid-cols-2 gap-3 mb-4",children:\[\s*s\.jsxs\("div",\{className:"bg-indigo-950/40', c)
        if m:
            c = c[:m.start()] + ',t.currentDay>=10&&' + c[m.start()+1:]
            print("  Gated focus subjects & attendance grid using regex match")
        else:
            print("  WARNING: focus subjects grid prefix not found!")

    with open(path, "w") as f:
        f.write(c)

    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check!")
    else:
        print(f"  ERROR: {path} syntax error:\n{res.stderr[:400]}")
        exit(1)

print("All modifications applied successfully!")
