import subprocess

print("Setting Instructions before Daily Regulations in morning sequence...")

for path in ["public/assets/app-bundle.js", "assets/app-bundle.js"]:
    print(f"Updating {path}...")
    with open(path, "r") as f:
        c = f.read()

    # 1. onStartGame and onStartMorningRoutine: Step 1 is Instructions (Js(!0))
    old_start = 'onStartGame:()=>{if(i.isDayStarted){u(!1);p(!1);is(!1);we(!1);Js(!1);c("desk");return}window.__isMorningSequence=!0;I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty),cleanQueue=ae.map(st=>({...st,decision:"pending"}));l(pe=>({...pe,isDayStarted:!1,currentDailyQueue:cleanQueue,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!0);is(!1);we(!1);Js(!1);c("desk")},onStartMorningRoutine:()=>{if(i.isDayStarted){u(!1);p(!1);is(!1);we(!1);Js(!1);c("desk");return}window.__isMorningSequence=!0;I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty),cleanQueue=ae.map(st=>({...st,decision:"pending"}));l(pe=>({...pe,isDayStarted:!1,currentDailyQueue:cleanQueue,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!0);is(!1);we(!1);Js(!1);c("desk")}'
    new_start = 'onStartGame:()=>{if(i.isDayStarted){u(!1);p(!1);is(!1);we(!1);Js(!1);c("desk");return}window.__isMorningSequence=!0;I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty),cleanQueue=ae.map(st=>({...st,decision:"pending"}));l(pe=>({...pe,isDayStarted:!1,currentDailyQueue:cleanQueue,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);Js(!0);p(!1);is(!1);we(!1);c("desk")},onStartMorningRoutine:()=>{if(i.isDayStarted){u(!1);p(!1);is(!1);we(!1);Js(!1);c("desk");return}window.__isMorningSequence=!0;I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty),cleanQueue=ae.map(st=>({...st,decision:"pending"}));l(pe=>({...pe,isDayStarted:!1,currentDailyQueue:cleanQueue,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);Js(!0);p(!1);is(!1);we(!1);c("desk")}'
    if old_start in c:
        c = c.replace(old_start, new_start)
        print("  Updated onStartGame & onStartMorningRoutine: Step 1 is Instructions (Js(!0))")
    else:
        print("  WARNING: old_start not found!")

    # 2. wXe onClose: Step 2 is Daily Regulations (p(!0))
    old_wxe = 's.jsx(wXe,{isOpen:fr,onClose:()=>{Js(!1);try{localStorage.setItem("school_tutorial_completed","true")}catch{}l(pe=>({...pe,isDayStarted:!0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));c("desk")},language:i.settings.language})'
    new_wxe = 's.jsx(wXe,{isOpen:fr,onClose:()=>{Js(!1);try{localStorage.setItem("school_tutorial_completed","true")}catch{}if(window.__isMorningSequence){I.playPaperRustle();p(!0)}else{c("desk")}},language:i.settings.language})'
    if old_wxe in c:
        c = c.replace(old_wxe, new_wxe)
        print("  Updated wXe onClose: Step 2 is Daily Regulations (p(!0))")
    else:
        print("  WARNING: old_wxe not found!")

    # 3. JDe onStartDay: Step 3 is Story (is(!0))
    old_jde = 'onStartDay:()=>{p(!1);if(window.__isMorningSequence){window.__isMorningSequence=!1;I.playRulebookOpen();is(!0)}}'
    new_jde = 'onStartDay:()=>{p(!1);if(window.__isMorningSequence){I.playRulebookOpen();is(!0)}else{c("desk")}}'
    if old_jde in c:
        c = c.replace(old_jde, new_jde)
        print("  Updated JDe onStartDay: Step 3 is Story (is(!0))")
    else:
        print("  WARNING: old_jde not found!")

    # 4. aZe onClose: Step 4 is Administrative Decision (starts day with currentEvent)
    old_aze = 's.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1);I.playPaperSlide();Js(!0)},'
    new_aze = 's.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1);if(window.__isMorningSequence){window.__isMorningSequence=!1;l(pe=>({...pe,isDayStarted:!0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));c("desk")}else{l(pe=>({...pe,currentEvent:null}))}},'
    if old_aze in c:
        c = c.replace(old_aze, new_aze)
        print("  Updated aZe onClose: Step 4 is Administrative Decision")
    else:
        print("  WARNING: old_aze not found!")

    # 5. Set window.__isMorningSequence = !1 on manual opens of tutorial and story
    c = c.replace("onOpenTutorial:()=>Js(!0)", "onOpenTutorial:()=>{window.__isMorningSequence=!1;Js(!0)}")
    c = c.replace("onOpenDailyStory:()=>is(!0)", "onOpenDailyStory:()=>{window.__isMorningSequence=!1;is(!0)}")

    with open(path, "w") as f:
        f.write(c)

    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check!")
    else:
        print(f"  ERROR: {path} syntax error:\n{res.stderr[:400]}")
        exit(1)

print("All updates applied successfully!")
