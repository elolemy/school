
const fs = require('fs');
const vm = require('vm');
const text = fs.readFileSync('assets/index-BeRTxH1o.js', 'utf8');

// Use acorn or esprima if available, else test chunks
let low = 0, high = text.length;
// Check if full file fails
try {
  new vm.Script(text);
  console.log('Script compiles fully!');
  process.exit(0);
} catch(e) {
  console.log('Full file error:', e.message);
}
