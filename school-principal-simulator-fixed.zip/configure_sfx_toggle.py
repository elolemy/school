import subprocess

print("Configuring SFX audio toggle for start menu button and settings modal...")

for path in ["public/assets/app-bundle.js", "assets/app-bundle.js"]:
    print(f"Updating {path}...")
    with open(path, "r") as f:
        c = f.read()

    # 1. Update setSoundEnabled to properly resume context and enable SFX when e is true
    old_set_sound = 'setSoundEnabled(e){this.isMuted=!e;this.musicVolume=0;this.ambientVolume=0;this.isMusicPlaying=!1;this.isAmbientRunning=!1;this.ambientEnabled=!1;if(this.timerId){window.clearTimeout(this.timerId);this.timerId=null;}if(this.ambientTimerId){window.clearTimeout(this.ambientTimerId);this.ambientTimerId=null;}if(!e&&this.ctx&&this.ctx.state!=="closed"){try{this.ctx.suspend().catch(()=>{})}catch(err){}}}'
    new_set_sound = 'setSoundEnabled(e){this.isMuted=!e;this.musicVolume=0;this.ambientVolume=0;this.isMusicPlaying=!1;this.isAmbientRunning=!1;this.ambientEnabled=!1;if(this.timerId){window.clearTimeout(this.timerId);this.timerId=null;}if(this.ambientTimerId){window.clearTimeout(this.ambientTimerId);this.ambientTimerId=null;}if(e){if(this.sfxVolume<=0){this.sfxVolume=.6;}this.initContext();if(this.ctx&&this.ctx.state==="suspended"){try{this.ctx.resume().catch(()=>{})}catch(err){}}}else{if(this.ctx&&this.ctx.state!=="closed"){try{this.ctx.suspend().catch(()=>{})}catch(err){}}}}'
    if old_set_sound in c:
        c = c.replace(old_set_sound, new_set_sound)
        print("  Updated setSoundEnabled with proper SFX resume and mute")
    else:
        print("  WARNING: old_set_sound not found!")

    # 2. Update the Start Menu header button:
    # When enabled, show green speaker and play a click sound, otherwise mute
    old_sje_btn = 'onClick:()=>{const U=!T;n({...t,settings:{...t.settings,soundEnabled:U,musicEnabled:!1,ambientSoundEnabled:!1}}),I.setSoundEnabled(U),!U&&(I.toggleMusic(!1),I.setAmbientEnabled(!1),I.ctx&&I.ctx.state!=="closed"&&I.ctx.suspend().catch(()=>{}));},className:"p-2.5 rounded-xl bg-slate-850 hover:bg-slate-800 border border-slate-750 text-amber-300 transition-all shadow-sm",title:T?"كتم الصوت والموسيقى بالكامل":"تشغيل المؤثرات الصوتية",children:T?s.jsx(P0,{className:"w-4 h-4"}):s.jsx(Kg,{className:"w-4 h-4 text-slate-500"})'
    new_sje_btn = 'onClick:()=>{const U=!T;n({...t,settings:{...t.settings,soundEnabled:U,musicEnabled:!1,ambientSoundEnabled:!1}}),I.setSoundEnabled(U),U?setTimeout(()=>{try{I.playClick()}catch(e){}},30):null;},className:`p-2.5 rounded-xl border transition-all shadow-sm ${T?"bg-emerald-500/20 hover:bg-emerald-500/30 border-emerald-500/40 text-emerald-300 shadow-emerald-500/10":"bg-slate-850 hover:bg-slate-800 border-slate-750 text-slate-400"}`,title:T?"الصوت مفعّل (المؤثرات المكتبية فقط) - اضغط للكتم":"الصوت مكتوم - اضغط للتشغيل",children:T?s.jsx(P0,{className:"w-4 h-4 text-emerald-300"}):s.jsx(Kg,{className:"w-4 h-4 text-slate-500"})'
    if old_sje_btn in c:
        c = c.replace(old_sje_btn, new_sje_btn)
        print("  Updated Start Menu button with active sound feedback")
    else:
        print("  WARNING: old_sje_btn not found!")

    # 3. Update Settings Modal sound toggle button:
    old_settings_btn = 'onClick:()=>{const w=!d.soundEnabled;u({...d,soundEnabled:w}),I.setSoundEnabled(w)},className:`px-2.5 py-1 rounded-lg border text-xs font-bold transition-all flex items-center gap-1.5 ${d.soundEnabled?"bg-emerald-500/20 text-emerald-300 border-emerald-500/40":"bg-rose-500/20 text-rose-300 border-rose-500/40"}`,children:[d.soundEnabled?s.jsx(P0,{className:"w-3.5 h-3.5"}):s.jsx(Kg,{className:"w-3.5 h-3.5"}),s.jsx("span",{children:d.soundEnabled?o==="ar"?"الصوت العام مفعّل":"Master Audio On":o==="ar"?"الصوت العام مكتوم":"Master Muted"})]'
    new_settings_btn = 'onClick:()=>{const w=!d.soundEnabled;u({...d,soundEnabled:w,musicEnabled:!1,ambientSoundEnabled:!1}),I.setSoundEnabled(w),w?setTimeout(()=>{try{I.playClick()}catch(e){}},30):null;},className:`px-2.5 py-1 rounded-lg border text-xs font-bold transition-all flex items-center gap-1.5 ${d.soundEnabled?"bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-sm":"bg-rose-500/20 text-rose-300 border-rose-500/40"}`,children:[d.soundEnabled?s.jsx(P0,{className:"w-3.5 h-3.5 text-emerald-300"}):s.jsx(Kg,{className:"w-3.5 h-3.5 text-rose-400"}),s.jsx("span",{children:d.soundEnabled?o==="ar"?"مؤثرات الصوت مفعّلة 🔊":"SFX Audio On 🔊":o==="ar"?"الصوت مكتوم 🔇":"Muted 🔇"})]'
    if old_settings_btn in c:
        c = c.replace(old_settings_btn, new_settings_btn)
        print("  Updated Settings Modal sound toggle with active sound feedback")
    else:
        print("  WARNING: old_settings_btn not found!")

    with open(path, "w") as f:
        f.write(c)

    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check!")
    else:
        print(f"  ERROR: {path} syntax error:\n{res.stderr[:400]}")
        exit(1)

print("Audio system successfully re-enabled for SFX!")
