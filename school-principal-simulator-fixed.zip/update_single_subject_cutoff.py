import re
import subprocess

print("Updating subjectCutoffs to be exclusively a single specific subject (Mathematics)...")

for path in ["assets/app-bundle.js", "public/assets/app-bundle.js"]:
    print(f"Processing {path}...")
    with open(path, "r", encoding="utf-8") as f:
        c = f.read()

    # Replace any multi-subject or single-subject cutoff array with a single math cutoff
    c = re.sub(
        r'subjectCutoffs\s*:\s*\[\s*\{[^}]+\}(?:\s*,\s*\{[^}]+\})*\s*\]',
        'subjectCutoffs:[{subjectKey:"math",nameAr:"الرياضيات",nameEn:"Mathematics",minScore:80}]',
        c
    )

    with open(path, "w", encoding="utf-8") as f:
        f.write(c)

    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check!")
    else:
        print(f"  ERROR: {path} syntax error:\n{res.stderr[:400]}")
        exit(1)

# Also update sync_public_bundle.py if needed
with open("sync_public_bundle.py", "r", encoding="utf-8") as f:
    sb = f.read()

sb = re.sub(
    r'subjectCutoffs\s*:\s*\[\s*\{[^}]+\}(?:\s*,\s*\{[^}]+\})*\s*\]',
    'subjectCutoffs:[{subjectKey:"math",nameAr:"الرياضيات",nameEn:"Mathematics",minScore:80}]',
    sb
)

with open("sync_public_bundle.py", "w", encoding="utf-8") as f:
    f.write(sb)

print("Successfully restricted specialization subject cutoffs to a single subject (Mathematics)!")
