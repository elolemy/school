import subprocess
import re
import time

print("Updating JDe Daily Regulations Modal to show only Current Day regulations cleanly with return to desk button...")

for path in ["assets/app-bundle.js", "public/assets/app-bundle.js"]:
    print(f"\nProcessing {path}...")
    with open(path, "r") as f:
        c = f.read()

    # 1. Add close button in header of JDe
    old_header_start = 's.jsxs("div",{className:"flex items-center justify-between gap-3 pb-3 mb-4 border-b border-slate-800",children:[s.jsxs("div",{className:"flex items-center gap-2.5",'
    new_header_start = 's.jsxs("div",{className:"flex items-center justify-between gap-3 pb-3 mb-4 border-b border-slate-800",children:[s.jsxs("div",{className:"flex items-center gap-2.5",children:[s.jsx("button",{type:"button",onClick:()=>r(!1),className:"w-8 h-8 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 flex items-center justify-center font-bold text-sm transition-colors border border-slate-700 shrink-0",title:i?"إغلاق":"Close",children:"✕"}),'

    if old_header_start in c:
        c = c.replace(old_header_start, new_header_start, 1)
        print("  Added top close button in JDe header")

    # 2. Update bottom action button when day is started vs not started
    old_bottom_btn = 's.jsxs("button",{id:"btn-start-daily-dossiers",onClick:d,className:"w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-black text-base sm:text-lg shadow-xl shadow-amber-500/30 transition-all hover:scale-[1.01] active:scale-[0.98] flex items-center justify-center gap-3 border-2 border-amber-300",children:[s.jsx("span",{children:i?"📋 اعتماد اللائحة وبدء رواية وأحداث اليوم (5 طلاب)":"Approve Directives & Start Day\'s Story (5 Students)"}),i?s.jsx(Zge,{className:"w-5 h-5"}):s.jsx(pf,{className:"w-5 h-5"})]})'
    new_bottom_btn = 's.jsxs("button",{id:"btn-start-daily-dossiers",onClick:()=>{if(t.isDayStarted){r(!1)}else{d()}},className:"w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-black text-base shadow-xl shadow-amber-500/30 transition-all hover:scale-[1.01] active:scale-[0.98] flex items-center justify-center gap-3 border-2 border-amber-300",children:[s.jsx("span",{children:t.isDayStarted?(i?"العودة إلى طاولة فحص ملفات اليوم ◄":"Return to Desk & Resume Daily Dossiers ◄"):(i?"📋 اعتماد اللائحة وبدء رواية وأحداث اليوم (5 طلاب)":"Approve Directives & Start Day\'s Story (5 Students)")}),i?s.jsx(Zge,{className:"w-5 h-5"}):s.jsx(pf,{className:"w-5 h-5"})]})'

    if old_bottom_btn in c:
        c = c.replace(old_bottom_btn, new_bottom_btn, 1)
        print("  Updated JDe bottom button to adapt when day is already started")

    # 3. Clean up the focus subjects section in JDe to only appear if day >= 10 AND not on Day 1
    # Ensure t.currentDay >= 10 condition is preserved and clean
    with open(path, "w") as f:
        f.write(c)

    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check!")
    else:
        print(f"  ERROR: {path} syntax error:\n{res.stderr[:400]}")
        exit(1)

# Update index.html cache buster timestamp
with open("index.html", "r") as f:
    h = f.read()

ts = int(time.time())
h = re.sub(r'app-bundle\.js\?v=[^\"]+', f'app-bundle.js?v={ts}', h)
h = re.sub(r'app-bundle\.css\?v=[^\"]+', f'app-bundle.css?v={ts}', h)

with open("index.html", "w") as f:
    f.write(h)

print(f"\nUpdated index.html cache buster to ?v={ts}!")
print("Done!")
