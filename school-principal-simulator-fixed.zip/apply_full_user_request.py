import subprocess
import re
import time

print("Applying full user request:")
print("1. 4-step morning routine: Instructions (wXe) -> Story (aZe) -> Regulations (CJe) -> Day intro/Decisions (JDe)")
print("2. Online mode: Same as normal mode with same menus, student papers, and visible live rivalry clash banner")
print("3. Official papers spread cards in dossier")

for path in ["assets/app-bundle.js", "public/assets/app-bundle.js"]:
    print(f"\nProcessing {path}...")
    with open(path, "r") as f:
        c = f.read()

    # --- 1. Fix Morning Routine 4-step sequence ---
    # Update onStartMorningRoutine to ALWAYS start with tutorial step
    clean_routine = 'onStartMorningRoutine:()=>{I.playPaperRustle();const queue=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:queue,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!1);is(!1);we(!1);window.__morningRoutineStep="tutorial";Js(!0);c("desk")}'
    c = re.sub(r'onStartMorningRoutine:\([^\)]*\)=>\{[^\}]+\}', clean_routine, c)
    c = re.sub(r'onStartMorningRoutine:()=>{[^\}]+c\("desk"\)\}', clean_routine, c)

    # Chain wXe (Instructions): onClose moves to "story" (is(!0))
    target_wxe = 's.jsx(wXe,{isOpen:fr,onClose:()=>{Js(!1);try{localStorage.setItem("school_tutorial_completed","true")}catch{}i.currentDay===1&&!i.isDayStarted&&!ms&&p(!0)},language:i.settings.language})'
    replacement_wxe = 's.jsx(wXe,{isOpen:fr,onClose:()=>{Js(!1);try{localStorage.setItem("school_tutorial_completed","true")}catch{}if(window.__morningRoutineStep==="tutorial"){window.__morningRoutineStep="story";is(!0)}else{window.__morningRoutineStep=null}},language:i.settings.language})'
    if target_wxe in c:
        c = c.replace(target_wxe, replacement_wxe, 1)
        print("  wXe onClose chained to story successfully")
    else:
        # Regex replacement if not exact
        c = re.sub(r's\.jsx\(wXe,\{isOpen:fr,onClose:\(\)=>\{[^\}]+try\{localStorage\.setItem\("school_tutorial_completed"[^\}]+\}[^\}]*\},language:i\.settings\.language\}\)', replacement_wxe, c)
        print("  wXe onClose chained via regex")

    # Chain aZe (Story): onClose moves to "regulations" (we(!0))
    target_aze_start = 's.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1),l(pe=>({...pe,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}))},currentDay:i.currentDay'
    replacement_aze_start = 's.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1);l(pe=>({...pe,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));if(window.__morningRoutineStep==="story"){window.__morningRoutineStep="regulations";we(!0)}else{window.__morningRoutineStep=null}},currentDay:i.currentDay'
    if target_aze_start in c:
        c = c.replace(target_aze_start, replacement_aze_start, 1)
        print("  aZe onClose chained to regulations successfully")
    else:
        c = re.sub(r's\.jsx\(aZe,\{isOpen:ms,onClose:\(\)=>\{is\(!1\)[^\}]+\},currentDay:i\.currentDay', replacement_aze_start, c)
        print("  aZe onClose chained via regex")

    # Chain CJe (Regulations): onClose moves to "decisions/day intro" (p(!0))
    target_cje = 's.jsx(CJe,{isOpen:de,onClose:()=>we(!1),language:i.settings.language,isDark:vi})'
    replacement_cje = 's.jsx(CJe,{isOpen:de,onClose:()=>{we(!1);if(window.__morningRoutineStep==="regulations"){window.__morningRoutineStep=null;p(!0)}else{window.__morningRoutineStep=null}},language:i.settings.language,isDark:vi})'
    if target_cje in c:
        c = c.replace(target_cje, replacement_cje, 1)
        print("  CJe onClose chained to p(!0) successfully")
    else:
        c = re.sub(r's\.jsx\(CJe,\{isOpen:de,onClose:\(\)=>we\(!1\),language:i\.settings\.language,isDark:vi\}\)', replacement_cje, c)
        print("  CJe onClose chained via regex")

    # --- 2. Make the Live Clash Banner visible on ALL screen sizes (remove hidden xl:flex) ---
    old_banner = 'className:"hidden xl:flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-slate-950/60 border border-indigo-500/30'
    new_banner = 'className:"flex items-center gap-2 px-3 py-1 rounded-xl bg-slate-950/80 border border-cyan-500/40 text-xs font-bold text-white shadow-md select-none shrink-0'
    if old_banner in c:
        c = c.replace(old_banner, new_banner, 1)
        print("  Made Live Clash Banner visible on all screens (removed hidden xl:flex)")

    # Also update the inner clash banner text to be compact and beautiful on any screen
    old_inner_banner = 't.settings.language==="ar"?"العب أونلاين وتحدَ المدارس الأخرى في نفس الوقت!":"Play online and challenge other schools live!"'
    new_inner_banner = 't.settings.language==="ar"?"⚡ طور الأونلاين وتحدي المدارس المباشر":"⚡ Live School Multiplayer Clash"'
    if old_inner_banner in c:
        c = c.replace(old_inner_banner, new_inner_banner, 1)

    # --- 3. Add desk spread cards if not present ---
    spread_closing = ']}),Zt==="birth_cert"'
    if spread_closing in c and 'Wt("tablet_receipt")' not in c:
        extra_spread_cards = ''',
s.jsxs("button",{type:"button",onClick:()=>{I.playPageFlip(),Wt("tablet_receipt")},className:"p-3 bg-white/95 rounded-xl border-2 border-indigo-300 hover:border-indigo-500 shadow-sm text-right transition-all hover:scale-102 flex flex-col justify-between",children:[
  s.jsxs("div",{className:"flex items-center gap-1.5 text-indigo-700 font-bold mb-1",children:[s.jsx("span",{className:"text-base",children:"📱"}),s.jsx("span",{className:"text-[11px]",children:M==="ar"?"إقرار التابلت":"Tablet Bond"})]}),
  s.jsxs("div",{className:"text-[10px] text-slate-600 font-mono",children:["TAB-2026-",a.id.slice(-4)]}),
  s.jsx("div",{className:"mt-2 text-[10px] text-indigo-600 font-bold underline",children:M==="ar"?"عرض الورقة 🔍":"Open Sheet 🔍"})
]}),
s.jsxs("button",{type:"button",onClick:()=>{I.playPageFlip(),Wt("social_worker_report")},className:"p-3 bg-white/95 rounded-xl border-2 border-teal-300 hover:border-teal-500 shadow-sm text-right transition-all hover:scale-102 flex flex-col justify-between",children:[
  s.jsxs("div",{className:"flex items-center gap-1.5 text-teal-700 font-bold mb-1",children:[s.jsx("span",{className:"text-base",children:"📋"}),s.jsx("span",{className:"text-[11px]",children:M==="ar"?"الأخصائي الاجتماعي":"Social Worker"})]}),
  s.jsx("div",{className:"text-[10px] text-emerald-600 font-bold",children:M==="ar"?"توصية إيجابية":"Approved"}),
  s.jsx("div",{className:"mt-2 text-[10px] text-teal-600 font-bold underline",children:M==="ar"?"عرض الورقة 🔍":"Open Sheet 🔍"})
]}),
s.jsxs("button",{type:"button",onClick:()=>{I.playPageFlip(),Wt("bus_subscription")},className:"p-3 bg-white/95 rounded-xl border-2 border-yellow-300 hover:border-yellow-500 shadow-sm text-right transition-all hover:scale-102 flex flex-col justify-between",children:[
  s.jsxs("div",{className:"flex items-center gap-1.5 text-yellow-700 font-bold mb-1",children:[s.jsx("span",{className:"text-base",children:"🚌"}),s.jsx("span",{className:"text-[11px]",children:M==="ar"?"الحافلة المدرسية":"School Bus"})]}),
  s.jsx("div",{className:"text-[10px] text-slate-600 font-mono",children:M==="ar"?"خط (أ) النطاق المعتمد":"Route A"}),
  s.jsx("div",{className:"mt-2 text-[10px] text-yellow-600 font-bold underline",children:M==="ar"?"عرض الورقة 🔍":"Open Sheet 🔍"})
]}),
s.jsxs("button",{type:"button",onClick:()=>{I.playPageFlip(),Wt("food_allergy_cert")},className:"p-3 bg-white/95 rounded-xl border-2 border-lime-300 hover:border-lime-500 shadow-sm text-right transition-all hover:scale-102 flex flex-col justify-between",children:[
  s.jsxs("div",{className:"flex items-center gap-1.5 text-lime-700 font-bold mb-1",children:[s.jsx("span",{className:"text-base",children:"🥗"}),s.jsx("span",{className:"text-[11px]",children:M==="ar"?"التغذية والحساسية":"Nutrition"})]}),
  s.jsx("div",{className:"text-[10px] text-emerald-600 font-bold",children:M==="ar"?"لائق غذائياً":"Fit"}),
  s.jsx("div",{className:"mt-2 text-[10px] text-lime-600 font-bold underline",children:M==="ar"?"عرض الورقة 🔍":"Open Sheet 🔍"})
]}),
s.jsxs("button",{type:"button",onClick:()=>{I.playPageFlip(),Wt("language_proficiency")},className:"p-3 bg-white/95 rounded-xl border-2 border-sky-300 hover:border-sky-500 shadow-sm text-right transition-all hover:scale-102 flex flex-col justify-between",children:[
  s.jsxs("div",{className:"flex items-center gap-1.5 text-sky-700 font-bold mb-1",children:[s.jsx("span",{className:"text-base",children:"🌐"}),s.jsx("span",{className:"text-[11px]",children:M==="ar"?"اللغات الأجنبية":"Languages"})]}),
  s.jsx("div",{className:"text-[10px] text-sky-700 font-mono font-bold",children:"C1 Advanced (98%)"}),
  s.jsx("div",{className:"mt-2 text-[10px] text-sky-600 font-bold underline",children:M==="ar"?"عرض الورقة 🔍":"Open Sheet 🔍"})
]}),
s.jsxs("button",{type:"button",onClick:()=>{I.playPageFlip(),Wt("iq_olympiad_cert")},className:"p-3 bg-white/95 rounded-xl border-2 border-violet-300 hover:border-violet-500 shadow-sm text-right transition-all hover:scale-102 flex flex-col justify-between",children:[
  s.jsxs("div",{className:"flex items-center gap-1.5 text-violet-700 font-bold mb-1",children:[s.jsx("span",{className:"text-base",children:"🧠"}),s.jsx("span",{className:"text-[11px]",children:M==="ar"?"اختبار الذكاء (IQ)":"Mensa IQ"})]}),
  s.jsx("div",{className:"text-[10px] text-violet-700 font-bold",children:"IQ 142 (موهوب)"}),
  s.jsx("div",{className:"mt-2 text-[10px] text-violet-600 font-bold underline",children:M==="ar"?"عرض الورقة 🔍":"Open Sheet 🔍"})
]}),
s.jsxs("button",{type:"button",onClick:()=>{I.playPageFlip(),Wt("scout_camp_permit")},className:"p-3 bg-white/95 rounded-xl border-2 border-emerald-300 hover:border-emerald-500 shadow-sm text-right transition-all hover:scale-102 flex flex-col justify-between",children:[
  s.jsxs("div",{className:"flex items-center gap-1.5 text-emerald-700 font-bold mb-1",children:[s.jsx("span",{className:"text-base",children:"⛺"}),s.jsx("span",{className:"text-[11px]",children:M==="ar"?"المعسكرات الكشفية":"Scout Camp"})]}),
  s.jsx("div",{className:"text-[10px] text-emerald-600 font-bold",children:M==="ar"?"موافقة ولي الأمر ✓":"Approved ✓"}),
  s.jsx("div",{className:"mt-2 text-[10px] text-emerald-600 font-bold underline",children:M==="ar"?"عرض الورقة 🔍":"Open Sheet 🔍"})
]}),
s.jsxs("button",{type:"button",onClick:()=>{I.playPageFlip(),Wt("arabic_calligraphy_diploma")},className:"p-3 bg-white/95 rounded-xl border-2 border-amber-300 hover:border-amber-500 shadow-sm text-right transition-all hover:scale-102 flex flex-col justify-between",children:[
  s.jsxs("div",{className:"flex items-center gap-1.5 text-amber-700 font-bold mb-1",children:[s.jsx("span",{className:"text-base",children:"✍️"}),s.jsx("span",{className:"text-[11px]",children:M==="ar"?"إجازة الخط العربي":"Calligraphy"})]}),
  s.jsx("div",{className:"text-[10px] text-amber-600 font-bold",children:M==="ar"?"امتياز مع الشرف":"Honors"}),
  s.jsx("div",{className:"mt-2 text-[10px] text-amber-600 font-bold underline",children:M==="ar"?"عرض الورقة 🔍":"Open Sheet 🔍"})
]}),
s.jsxs("button",{type:"button",onClick:()=>{I.playPageFlip(),Wt("anti_bullying_pledge")},className:"p-3 bg-white/95 rounded-xl border-2 border-rose-300 hover:border-rose-500 shadow-sm text-right transition-all hover:scale-102 flex flex-col justify-between",children:[
  s.jsxs("div",{className:"flex items-center gap-1.5 text-rose-700 font-bold mb-1",children:[s.jsx("span",{className:"text-base",children:"🛡️"}),s.jsx("span",{className:"text-[11px]",children:M==="ar"?"ميثاق الأمان والتنمر":"Safety Charter"})]}),
  s.jsx("div",{className:"text-[10px] text-rose-600 font-bold",children:M==="ar"?"ميثاق معتمد ✓":"Signed ✓"}),
  s.jsx("div",{className:"mt-2 text-[10px] text-rose-600 font-bold underline",children:M==="ar"?"عرض الورقة 🔍":"Open Sheet 🔍"})
]}),
s.jsxs("button",{type:"button",onClick:()=>{I.playPageFlip(),Wt("library_membership")},className:"p-3 bg-white/95 rounded-xl border-2 border-stone-300 hover:border-stone-500 shadow-sm text-right transition-all hover:scale-102 flex flex-col justify-between",children:[
  s.jsxs("div",{className:"flex items-center gap-1.5 text-stone-700 font-bold mb-1",children:[s.jsx("span",{className:"text-base",children:"📚"}),s.jsx("span",{className:"text-[11px]",children:M==="ar"?"عضوية المكتبة":"Library Card"})]}),
  s.jsx("div",{className:"text-[10px] text-stone-600 font-mono",children:"Dewey: 962.05"}),
  s.jsx("div",{className:"mt-2 text-[10px] text-stone-600 font-bold underline",children:M==="ar"?"عرض الورقة 🔍":"Open Sheet 🔍"})
]}),
s.jsxs("button",{type:"button",onClick:()=>{I.playPageFlip(),Wt("robotics_badge")},className:"p-3 bg-white/95 rounded-xl border-2 border-cyan-300 hover:border-cyan-500 shadow-sm text-right transition-all hover:scale-102 flex flex-col justify-between",children:[
  s.jsxs("div",{className:"flex items-center gap-1.5 text-cyan-700 font-bold mb-1",children:[s.jsx("span",{className:"text-base",children:"🤖"}),s.jsx("span",{className:"text-[11px]",children:M==="ar"?"الروبوتات والـAI":"Robotics & AI"})]}),
  s.jsx("div",{className:"text-[10px] text-cyan-600 font-bold",children:M==="ar"?"ميدالية الابتكار 🥇":"Gold Medal 🥇"}),
  s.jsx("div",{className:"mt-2 text-[10px] text-cyan-600 font-bold underline",children:M==="ar"?"عرض الورقة 🔍":"Open Sheet 🔍"})
]}),
s.jsxs("button",{type:"button",onClick:()=>{I.playPageFlip(),Wt("chess_accreditation")},className:"p-3 bg-white/95 rounded-xl border-2 border-purple-300 hover:border-purple-500 shadow-sm text-right transition-all hover:scale-102 flex flex-col justify-between",children:[
  s.jsxs("div",{className:"flex items-center gap-1.5 text-purple-700 font-bold mb-1",children:[s.jsx("span",{className:"text-base",children:"♟️"}),s.jsx("span",{className:"text-[11px]",children:M==="ar"?"اتحاد الشطرنج":"Chess Rating"})]}),
  s.jsx("div",{className:"text-[10px] text-purple-600 font-bold",children:"ELO 1650 Master"}),
  s.jsx("div",{className:"mt-2 text-[10px] text-purple-600 font-bold underline",children:M==="ar"?"عرض الورقة 🔍":"Open Sheet 🔍"})
]})'''
        pos = c.find(spread_closing)
        c = c[:pos] + extra_spread_cards + c[pos:]
        print("  Added all 12 missing official spread paper cards to desk spread grid")

    with open(path, "w") as f:
        f.write(c)

    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check!")
    else:
        print(f"  ERROR: {path} syntax error:\n{res.stderr[:400]}")
        exit(1)

# Update index.html version parameter to bust browser cache
with open("index.html", "r") as f:
    h = f.read()

ts = int(time.time())
h = re.sub(r'app-bundle\.js\?v=[^\"]+', f'app-bundle.js?v={ts}', h)
h = re.sub(r'app-bundle\.css\?v=[^\"]+', f'app-bundle.css?v={ts}', h)

with open("index.html", "w") as f:
    f.write(h)

print(f"\nUpdated index.html cache buster to ?v={ts}!")
print("All tasks completed successfully!")
