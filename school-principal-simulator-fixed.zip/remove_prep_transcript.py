import re
import time
import glob

with open("assets/app-bundle.js", "r") as f:
    code = f.read()

# 1. Remove highschool_transcript from Eo
pattern = r'\{id:"highschool_transcript",labelAr:"📜 بيان درجات الإعدادية",labelEn:"📜 Prep Transcript",icon:"📜"\},?'
code = re.sub(pattern, "", code)

# 2. Check if student_national_id is completely absent from Eo
assert "student_national_id" not in code.split("tc=()=>{")[0], "student_national_id still present in Eo"
assert "highschool_transcript" not in code.split("tc=()=>{")[0], "highschool_transcript still present in Eo"

print("1. Successfully removed highschool_transcript & student_national_id from Eo tabs!")

with open("assets/app-bundle.js", "w") as f:
    f.write(code)
with open("assets/index-BeRTxH1o.js", "w") as f:
    f.write(code)

for dist_js in glob.glob("dist/assets/*.js"):
    if "index" in dist_js or "app" in dist_js or "BeRTxH1o" in dist_js or "BoWY_e0a" in dist_js or "CwhFnn8I" in dist_js:
        with open(dist_js, "w") as f:
            f.write(code)
        print("Updated dist file:", dist_js)

ts = int(time.time())
with open("index.html", "r") as f:
    html = f.read()

html = re.sub(r'app-bundle\.js\?v=\d+', f'app-bundle.js?v={ts}', html)
html = re.sub(r'app-bundle\.css\?v=\d+', f'app-bundle.css?v={ts}', html)

with open("index.html", "w") as f:
    f.write(html)
with open("dist/index.html", "w") as f:
    f.write(html)

print("SUCCESS: Removed preparatory transcript & student national ID card completely!")
