import glob
import re

with open("assets/app-bundle.js", "r") as f:
    code = f.read()

kse_def = '''var KSe=({isOpen:t,onClose:e,state:r,onUpdateState:a,onOpenEagleStampDesk:n,onOpenDoctorClinic:i,onOpenCctvSecurity:l,onOpenCashDrawer:o,onTriggerEmergencyDispute:c,onOpenBellSchedule:d,onSelectTab:u,onOpenHundredInnovations:m,onOpenFootballLeague:p,lang:h="ar",isDark:x=!0})=>{if(!t)return null;const f=h==="ar",g=action=>{if(typeof I!=="undefined"&&I&&I.playCardFlip)I.playCardFlip();if(e)e();if(action)action();};return s.jsx("div",{className:"fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 animate-in fade-in duration-200",children:s.jsxs("div",{className:"max-w-2xl w-full rounded-3xl bg-slate-900 border-2 border-amber-500/80 text-white shadow-2xl flex flex-col overflow-hidden relative",children:[s.jsxs("div",{className:"p-4 sm:p-5 border-b border-amber-500/30 bg-gradient-to-r from-amber-950/80 via-slate-900 to-indigo-950/80 flex items-center justify-between shrink-0",children:[s.jsxs("div",{className:"flex items-center gap-3",children:[s.jsx("div",{className:"w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-400 flex items-center justify-center text-xl shadow-lg",children:"⚡"}),s.jsxs("div",{children:[s.jsx("h2",{className:"text-base sm:text-lg font-black text-amber-300",children:f?"مركز الإجراءات السريعة والمباشرة ⚡":"Quick Actions Hub ⚡"}),s.jsx("p",{className:"text-xs text-slate-300 mt-0.5",children:f?"وصول فوري ومباشر لكافة أركان ومنظومات إدارة المدرسة ومكتب الناظر.":"Instant access to all principal management desks and features."})]})]}),s.jsx("button",{onClick:e,className:"w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition-all cursor-pointer",children:s.jsx(ps,{className:"w-4 h-4"})})]}),s.jsx("div",{className:"p-4 sm:p-5 grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[70vh] overflow-y-auto",children:[{icon:"💯",titleAr:"موسوعة الـ 100 إضافة الجديدة",titleEn:"100 Grand Innovations",color:"from-purple-600/30 to-indigo-600/30 border-purple-500/50 text-purple-300",action:m},{icon:"🦅",titleAr:"مكتب ختم النسر وفحص الأوراق",titleEn:"Eagle Stamp & Dossier Desk",color:"from-amber-600/30 to-yellow-600/30 border-amber-500/50 text-amber-300",action:n},{icon:"📹",titleAr:"غرفة كاميرات المراقبة الحية",titleEn:"Live CCTV Surveillance Room",color:"from-emerald-600/30 to-teal-600/30 border-emerald-500/50 text-emerald-300",action:l},{icon:"💵",titleAr:"درج الخزينة والنقدية بالمكتب",titleEn:"Desk Cash Drawer",color:"from-green-600/30 to-emerald-600/30 border-green-500/50 text-green-300",action:o},{icon:"🩺",titleAr:"عيادة الطبيب والزائرة الصحية",titleEn:"Health & Medical Clinic",color:"from-rose-600/30 to-pink-600/30 border-rose-500/50 text-rose-300",action:i},{icon:"⚽",titleAr:"أكاديمية ودوري كرة القدم FC27",titleEn:"Football League & Academy",color:"from-cyan-600/30 to-blue-600/30 border-cyan-500/50 text-cyan-300",action:p},{icon:"🚨",titleAr:"طوارئ وفض النزاعات المدرسية",titleEn:"Emergency Dispute Center",color:"from-red-600/30 to-rose-600/30 border-red-500/50 text-red-300",action:c},{icon:"🔔",titleAr:"جدول مواعيد الحصص والجرس",titleEn:"Bell Schedule & Class Timetable",color:"from-blue-600/30 to-indigo-600/30 border-blue-500/50 text-blue-300",action:d}].map((btn,idx)=>s.jsxs("button",{key:idx,onClick:()=>g(btn.action),className:`p-3 rounded-2xl bg-gradient-to-r ${btn.color} border hover:scale-102 active:scale-98 transition-all flex items-center justify-between text-right cursor-pointer`,children:[s.jsxs("div",{className:"flex items-center gap-2.5",children:[s.jsx("span",{className:"text-2xl",children:btn.icon}),s.jsx("span",{className:"text-xs font-black text-white",children:f?btn.titleAr:btn.titleEn})]}),s.jsx("span",{className:"text-xs font-bold opacity-60",children:"➜"})]}))})]})});};
'''

# Insert kse_def right before var QSe=
pos = code.find("var QSe=")
if pos != -1:
    code = code[:pos] + kse_def + code[pos:]
    print("Injected KSe successfully before QSe!")
else:
    print("var QSe= not found")

with open("assets/app-bundle.js", "w") as f:
    f.write(code)

with open("assets/index-BeRTxH1o.js", "w") as f:
    f.write(code)

with open("public/assets/app-bundle.js", "w") as f:
    f.write(code)

with open("public/assets/index-BeRTxH1o.js", "w") as f:
    f.write(code)

for js_file in glob.glob("dist/assets/*.js"):
    if "index" in js_file or "app" in js_file:
        with open(js_file, "w") as f:
            f.write(code)
        print("Updated dist:", js_file)

print("SUCCESS: KSe injected and synchronized!")
