import shutil
import re
import subprocess

print("1. Restoring app-bundle.js from pristine index-BeRTxH1o.js...")
shutil.copy("assets/index-BeRTxH1o.js", "assets/app-bundle.js")
shutil.copy("assets/index-BeRTxH1o.js", "public/assets/app-bundle.js")

clean_on_start_routine = '()=>{I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!1);is(!1);we(!1);window.__morningRoutineStep="tutorial";Js(!0);c("desk")}'

for target_file in ["assets/app-bundle.js", "public/assets/app-bundle.js"]:
    print(f"Applying modifications to {target_file}...")
    with open(target_file, "r") as f:
        code = f.read()

    # 1. Update onStartGame & onStartMorningRoutine
    code = re.sub(
        r'onStartGame:\(\)=>\{[^\}]+\}',
        f'onStartGame:{clean_on_start_routine}',
        code
    )

    code = re.sub(
        r'onStartMorningRoutine:\(\)=>\{[^\}]+\}',
        f'onStartMorningRoutine:{clean_on_start_routine}',
        code
    )

    # 2. Update wXe (Instructions/Tutorial) onClose:
    # Moves to story step
    code = re.sub(
        r's\.jsx\(wXe,\{isOpen:fr,onClose:\(\)=>\{[^\}]+\},language:i\.settings\.language\}\)',
        's.jsx(wXe,{isOpen:fr,onClose:()=>{Js(!1);try{localStorage.setItem("school_tutorial_completed","true")}catch{}if(window.__morningRoutineStep==="tutorial"){window.__morningRoutineStep="story";is(!0)}else{window.__morningRoutineStep=null}},language:i.settings.language})',
        code
    )

    # 3. Update aZe (Story) onClose:
    # Moves to regulations step
    code = re.sub(
        r's\.jsx\(aZe,\{isOpen:ms,onClose:\(\)=>\{[^\}]+\},currentDay:i\.currentDay',
        's.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1),l(pe=>({...pe,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));if(window.__morningRoutineStep==="story"){window.__morningRoutineStep="regulations";we(!0)}else{window.__morningRoutineStep=null}},currentDay:i.currentDay',
        code
    )

    # 4. Update CJe (Regulations) onClose:
    # Moves to decisions step
    code = re.sub(
        r's\.jsx\(CJe,\{isOpen:de,onClose:\(\)=>\{[^\}]+\},language:i\.settings\.language,isDark:vi\}\)',
        's.jsx(CJe,{isOpen:de,onClose:()=>{we(!1);if(window.__morningRoutineStep==="regulations"){window.__morningRoutineStep=null;p(!0)}else{window.__morningRoutineStep=null}},language:i.settings.language,isDark:vi})',
        code
    )

    # 5. Top X button on CJe header:
    code = code.replace(
        's.jsx("button",{onClick:()=>{I.playStampAccept(),e()}',
        's.jsx("button",{onClick:()=>{I.playStampAccept();window.__morningRoutineStep=null;e()}'
    )

    # 6. Manual Desk Quickbar for Regulations:
    manual_reg_handler = "()=>{p(!1);is(!1);Js(!1);window.__morningRoutineStep=null;we(!0)}"
    code = code.replace('onOpenDailyRegulations:()=>{p(!1);is(!1);Js(!1);window.__morningRoutineStep=null;we(!0)}', f'onOpenDailyRegulations:{manual_reg_handler}')
    code = code.replace('onOpenDailyRegulations:()=>we(!0)', f'onOpenDailyRegulations:{manual_reg_handler}')
    code = code.replace('onOpenRulebook:()=>{p(!1);is(!1);Js(!1);window.__morningRoutineStep=null;we(!0)}', f'onOpenRulebook:{manual_reg_handler}')
    code = code.replace('onOpenRulebook:()=>we(!0)', f'onOpenRulebook:{manual_reg_handler}')

    with open(target_file, "w") as f:
        f.write(code)

    # Validate with node
    res = subprocess.run(["node", "--input-type=module", "-c"], input=code, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"SUCCESS: {target_file} passed syntax validation!")
    else:
        print(f"ERROR in {target_file}:\n{res.stderr}")
        exit(1)

print("All bundles restored, modified, and validated with 0 errors!")
