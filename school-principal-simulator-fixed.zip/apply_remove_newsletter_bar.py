import subprocess

print("Removing red newsletter ticker bar completely...")

for path in ["public/assets/app-bundle.js", "assets/app-bundle.js"]:
    print(f"Updating JS bundle at {path}...")
    with open(path, "r") as f:
        c = f.read()

    red_bar_start = "s.jsxs(\"div\",{className:\"w-full bg-red-700 dark:bg-red-950"
    red_bar_end = "children:de===\"ar\"?Mt.ar:Mt.en})]})]}),"

    idx1 = c.find(red_bar_start)
    idx2 = c.find(red_bar_end, idx1) if idx1 != -1 else -1

    if idx1 != -1 and idx2 != -1:
        snippet = c[idx1:idx2 + len(red_bar_end)]
        # Replace the red bar div with empty string
        c = c[:idx1] + c[idx2 + len(red_bar_end):]
        print(f"  Successfully removed red newsletter ticker snippet ({len(snippet)} chars)")
    else:
        print("  WARNING: Red newsletter ticker snippet not found!")

    with open(path, "w") as f:
        f.write(c)

    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check!")
    else:
        print(f"  ERROR: {path} syntax error:\n{res.stderr[:400]}")
        exit(1)

css_addition = """
.newsletter-marquee,
div[class*="bg-red-700"] {
  display: none !important;
}
"""

for css_path in ["public/assets/app-bundle.css", "assets/app-bundle.css"]:
    with open(css_path, "r") as f:
        css = f.read()
    if ".newsletter-marquee" not in css:
        css += "\n" + css_addition
        with open(css_path, "w") as f:
            f.write(css)
        print(f"  Updated CSS at {css_path}")

print("Red newsletter ticker bar completely removed!")
