import re

print("Starting precise implementation of the Morning Sequence and Regulations behavior...")

with open("assets/app-bundle.js", "r") as f:
    code = f.read()

# 1. Update SJe start button to call r (onStartMorningRoutine)
old_sje_start = 'id:"btn-start-morning-routine-5-files",type:"button",onClick:()=>{I.playPaperRustle(),w(!0)}'
new_sje_start = 'id:"btn-start-morning-routine-5-files",type:"button",onClick:()=>{I.playPaperRustle(),r?r():e()}'

if old_sje_start in code:
    code = code.replace(old_sje_start, new_sje_start, 1)
    print("✓ Updated SJe start morning routine button")
else:
    print("! Checking SJe start button variant...")
    code = re.sub(r'id:"btn-start-morning-routine-5-files",type:"button",onClick:\(\)=>\{I\.playPaperRustle\(\),[a-zA-Z0-9_$]+\(!0\)\}', new_sje_start, code)

# 2. Add rnStep state to Kat
old_state_target = '[Ao,Fi]=v.useState(!1),'
new_state_target = '[rnStep,setRnStep]=v.useState(null),[Ao,Fi]=v.useState(!1),'

if old_state_target in code:
    code = code.replace(old_state_target, new_state_target, 1)
    print("✓ Added rnStep state to Kat")
else:
    print("✗ Could not find old_state_target")

# 3. Update onStartMorningRoutine in SJe instantiation in Kat:
# Pattern: onStartMorningRoutine:()=>{I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)})),u(!1),p(!1),Js(!1),is(!0),c("desk")}
old_start_routine = 'onStartMorningRoutine:()=>{I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)})),u(!1),p(!1),Js(!1),is(!0),c("desk")}'
new_start_routine = 'onStartMorningRoutine:()=>{I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)})),u(!1),p(!1),is(!1),we(!1),setRnStep("tutorial"),Js(!0),c("desk")}'

if old_start_routine in code:
    code = code.replace(old_start_routine, new_start_routine, 1)
    print("✓ Updated onStartMorningRoutine in Kat")
else:
    print("! Looking for onStartMorningRoutine with regex...")
    code = re.sub(
        r'onStartMorningRoutine:\(\)=>\{I\.playPaperRustle\(\);const ae=\$E\(i\.currentDay,i\.difficulty==="hard"\?5:i\.difficulty==="easy"\?3:4,i\.difficulty\);l\(pe=>\(\{.+?\}\)\),u\(!1\),p\(!1\),Js\(!1\),is\(!0\),c\("desk"\)\}',
        new_start_routine,
        code
    )

# 4. Update wXe onClose in Kat:
# Old: s.jsx(wXe,{isOpen:fr,onClose:()=>{Js(!1);try{localStorage.setItem("school_tutorial_completed","true")}catch{}i.currentDay===1&&!i.isDayStarted&&!ms&&p(!0)},language:i.settings.language})
# New: s.jsx(wXe,{isOpen:fr,onClose:()=>{Js(!1);try{localStorage.setItem("school_tutorial_completed","true")}catch{}if(rnStep==="tutorial"){setRnStep("story"),is(!0)}},language:i.settings.language})
old_wxe = 's.jsx(wXe,{isOpen:fr,onClose:()=>{Js(!1);try{localStorage.setItem("school_tutorial_completed","true")}catch{}i.currentDay===1&&!i.isDayStarted&&!ms&&p(!0)},language:i.settings.language})'
new_wxe = 's.jsx(wXe,{isOpen:fr,onClose:()=>{Js(!1);try{localStorage.setItem("school_tutorial_completed","true")}catch{}if(rnStep==="tutorial"){setRnStep("story"),is(!0)}},language:i.settings.language})'

if old_wxe in code:
    code = code.replace(old_wxe, new_wxe, 1)
    print("✓ Updated wXe modal onClose in Kat")
else:
    print("! Replacing wXe with regex...")
    code = re.sub(r's\.jsx\(wXe,\{isOpen:fr,onClose:\(\)=>\{.+?\},language:i\.settings\.language\}\)', new_wxe, code)

# 5. Update aZe onClose in Kat:
# Old: s.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1),p(!0),l(pe=>({...pe,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}))},currentDay:i.currentDay
# New: s.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1),l(pe=>({...pe,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));if(rnStep==="story"){setRnStep("regulations"),we(!0)}},currentDay:i.currentDay
old_aze = 's.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1),p(!0),l(pe=>({...pe,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}))},currentDay:i.currentDay'
new_aze = 's.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1),l(pe=>({...pe,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));if(rnStep==="story"){setRnStep("regulations"),we(!0)}},currentDay:i.currentDay'

if old_aze in code:
    code = code.replace(old_aze, new_aze, 1)
    print("✓ Updated aZe modal onClose in Kat")
else:
    print("! Replacing aZe with regex...")
    code = re.sub(r's\.jsx\(aZe,\{isOpen:ms,onClose:\(\)=>\{is\(!1\),.+?\},currentDay:i\.currentDay', new_aze, code)

# 6. Update CJe onClose in Kat:
# Old: s.jsx(CJe,{isOpen:de,onClose:()=>we(!1),language:i.settings.language,isDark:vi})
# New: s.jsx(CJe,{isOpen:de,onClose:()=>{we(!1);if(rnStep==="regulations"){setRnStep(null),p(!0)}},language:i.settings.language,isDark:vi})
old_cje = 's.jsx(CJe,{isOpen:de,onClose:()=>we(!1),language:i.settings.language,isDark:vi})'
new_cje = 's.jsx(CJe,{isOpen:de,onClose:()=>{we(!1);if(rnStep==="regulations"){setRnStep(null),p(!0)}},language:i.settings.language,isDark:vi})'

if old_cje in code:
    code = code.replace(old_cje, new_cje, 1)
    print("✓ Updated CJe modal onClose in Kat")
else:
    print("! Replacing CJe with regex...")
    code = re.sub(r's\.jsx\(CJe,\{isOpen:de,onClose:\(\)=>we\(!1\),language:i\.settings\.language,isDark:vi\}\)', new_cje, code)

# 7. Update onOpenDailyRegulations to open rulebook directly (we(!0)) without story or decisions
code = code.replace('onOpenDailyRegulations:()=>p(!0)', 'onOpenDailyRegulations:()=>we(!0)')
print("✓ Updated onOpenDailyRegulations to directly open rulebook (we(!0))")

with open("assets/app-bundle.js", "w") as f:
    f.write(code)

print("All modifications applied successfully.")
