import re
import time
import glob

with open("assets/app-bundle.js", "r") as f:
    code = f.read()

pos_start = code.find("WSe=")
pos_end = code.find(";var QSe=", pos_start)
if pos_end == -1: pos_end = code.find("QSe=", pos_start)

assert pos_start != -1 and pos_end != -1, "WSe boundary not found"

new_wse_code = '''WSe=({isOpen:t,onClose:e,gameState:r,onUpdateGameState:a,isAr:n=!0})=>{
  const [activeTab, setActiveTab] = v.useState("cctv");
  
  // 1. CCTV State
  const [selectedCam, setSelectedCam] = v.useState(1);
  const [cctvAlerts, setCctvAlerts] = v.useState([
    {id:1, cam:1, titleAr:"🚨 طالب يحاول القفز من سور الفناء الخلفي", titleEn:"Student attempting to climb back fence", severity:"high", actionAr:"إرسال الأمن فوراً", actionEn:"Dispatch Security", resolved:false, reward:300},
    {id:2, cam:2, titleAr:"🥪 زحام وتدافع أمام مقصف المدرسة في الفسحة", titleEn:"Canteen overcrowding during recess", severity:"medium", actionAr:"توجيه معلم النوبتجية", actionEn:"Send Duty Teacher", resolved:false, reward:150},
    {id:3, cam:4, titleAr:"💨 تصاعد دخان أزرق كثيف من تجربة الكيمياء", titleEn:"Blue smoke rising from chem experiment", severity:"urgent", actionAr:"تشغيل شفاطات الطوارئ", actionEn:"Emergency Exhaust", resolved:false, reward:400},
    {id:4, cam:3, titleAr:"🚗 سيارة تفتيش وزاري مفاجئة تقف أمام البوابة", titleEn:"Ministry surprise inspection car at gate", severity:"critical", actionAr:"استقبال الموجهين", actionEn:"Welcome Inspectors", resolved:false, reward:500},
    {id:5, cam:6, titleAr:"🐱 قطة بيضاء شقية دخلت ممر الفصول واحتفال الطلاب", titleEn:"Cute white kitten in classroom corridor", severity:"low", actionAr:"اعتمادها تميمة الحظ", actionEn:"Adopt as Mascot", resolved:false, reward:100}
  ]);
  const [cctvLog, setCctvLog] = v.useState([]);
  const [snapshotCount, setSnapshotCount] = v.useState(0);
  const [alarmActive, setAlarmActive] = v.useState(false);

  // 2. Disciplinary Court State
  const [activeCaseIdx, setActiveCaseIdx] = v.useState(0);
  const [verdictHistory, setVerdictHistory] = v.useState([]);
  const courtCases = [
    {
      id: "case-1",
      studentName: "يوسف مروان (الصف الثاني الثانوي)",
      studentNameEn: "Youssef Marwan (Grade 11)",
      chargeAr: "إطلاق شعاع ليزر أخضر عالي الطاقة على سبورة الرياضيات أثناء الشرح وإرباك الفصل",
      chargeEn: "Pointing high-powered laser at smart board during math class",
      evidenceAr: "قلم ليزر أخضر 5000mW + شهادة 4 طلاب + تسجيل كاميرا الممر",
      evidenceEn: "5000mW laser pointer + 4 student testimonies + corridor cam footage",
      confessionAr: "كنت أجرب انعكاس الضوء للدرس العملي ولم أقصد إزعاج الأستاذ يا فندم!",
      confessionEn: "I was just testing light reflection for practical physics!",
      witnessAr: "الأخصائي الاجتماعي: الطالب متفوق ولكنه متهور ويحتاج توجيهاً انضباطياً.",
      witnessEn: "Counselor: High-achieving student but prone to impulsive pranks."
    },
    {
      id: "case-2",
      studentName: "كريم شريف (الصف الثالث الإعدادي)",
      studentNameEn: "Kareem Sherif (Grade 9)",
      chargeAr: "إدارة متجر سري لبيع الشيبسي والعصائر المهربة داخل حقيبة الظهر بأسعار منافسة للمقصف",
      chargeEn: "Running underground backpack snack store competing with school canteen",
      evidenceAr: "حقيبة تحتوي على 20 كيس شيبسي مستورد + دفتر حسابات مالي دقيق + 450 جنيهاً أرباح",
      evidenceEn: "20 snack packs + detailed ledger book + 450 EGP cash seized",
      confessionAr: "أنا أتعلم ريادة الأعمال مبكراً وأسعار المقصف كانت مرتفعة جداً على زملائي!",
      confessionEn: "I am practicing early entrepreneurship, canteen prices were too high!",
      witnessAr: "مسؤول المقصف: الطالب تسبب في خسائر 30% لمبيعات المقصف اليومية.",
      witnessEn: "Canteen Manager: Caused 30% slump in daily canteen revenue."
    },
    {
      id: "case-3",
      studentName: "رامي خالد (الصف الأول الثانوي)",
      studentNameEn: "Ramy Khaled (Grade 10)",
      chargeAr: "محاكاة صوت جرس الفسحة بصفارة إلكترونية من شباك الطابق الثالث وتفريغ 5 فصول مبكراً",
      chargeEn: "Mimicking recess bell with audio buzzer from 3rd floor emptying 5 classes",
      evidenceAr: "جهاز صوتي إلكتروني مبرمج على تردد 440Hz + تسجيل صوتي",
      evidenceEn: "Electronic buzzer tuned to 440Hz + audio recording",
      confessionAr: "الجميع كان يشعر بالجوع الشديد وحصة التاريخ كانت طويلة جداً!",
      confessionEn: "Everyone was starving and history class felt like eternity!",
      witnessAr: "معلم التاريخ: خرج نصف الفصل للفناء قبل موعد الفسحة بعشر دقائق كاملة.",
      witnessEn: "History Teacher: Half the class stormed into the yard 10 minutes early."
    },
    {
      id: "case-4",
      studentName: "عمر سامح (الصف الثاني الإعدادي)",
      studentNameEn: "Omar Sameh (Grade 8)",
      chargeAr: "اختراق شاشة الفصل الذكية وعرض ملخص أهداف دوري أبطال أوروبا أثناء حصة الدراسات",
      chargeEn: "Streaming Champions League highlights onto interactive smartboard during class",
      evidenceAr: "فلاش ميموري + كابل بث لاسلكي مخفي خلف الشاشة",
      evidenceEn: "USB drive + wireless casting dongle hidden behind the screen",
      confessionAr: "ريال مدريد كان يلعب والأستاذ نفسه من عشاق الكرة وطلب معرفة النتيجة!",
      confessionEn: "Real Madrid was playing and the teacher is a football fanatic!",
      witnessAr: "معلم الدراسات: الطالب بارع تقنياً جداً ولكن التوقيت كان خاطئاً تماماً.",
      witnessEn: "Social Studies Teacher: Extremely talented in tech but wrong timing."
    }
  ];

  // 3. Desk Phone Intercom State
  const [dialNumber, setDialNumber] = v.useState("");
  const [callActive, setCallActive] = v.useState(false);
  const [callDetails, setCallDetails] = v.useState(null);
  const phoneBook = [
    {code:"101", deptAr:"غرفة الكنترول المركزي", deptEn:"Exam Control Hub", icon:"📊", replyAr:"أهلاً سيادة الناظر! درجات الطلاب مرصودة بنسبة 98% وجاهزة للاعتماد الفوري.", replyEn:"Hello Principal! 98% of student exam grades are processed."},
    {code:"102", deptAr:"غرفة المعلمين والاستراحة", deptEn:"Staff Lounge", icon:"☕", replyAr:"مساء الخير يا فندم! جميع المعلمين ملتزمون بجدول الحصص والتحضير مكتمل.", replyEn:"Good day! All teachers are on schedule with full lesson plans."},
    {code:"103", deptAr:"العيادة والزائرة الصحية", deptEn:"Health Clinic", icon:"🩺", replyAr:"د. منى: جميع الطلاب بصحة ممتازة وتم تطعيم 45 طالباً اليوم بدون أي مضاعفات.", replyEn:"Dr. Mona: All students are healthy, 45 vaccinations completed today."},
    {code:"104", deptAr:"أمن البوابة الرئيسية", deptEn:"Main Gate Security", icon:"🚪", replyAr:"عم فرج: البوابة مغلقة بإحكام ولا يسمح بدخول أي غريب بدون بطاقة الرقم القومي.", replyEn:"Farag: Gate is fully secured, no visitors allowed without national ID."},
    {code:"105", deptAr:"مقصف وتغذية المدرسة", deptEn:"Canteen & Nutrition", icon:"🥪", replyAr:"الشيف حسن: الوجبات طازجة 100% والفطائر الساخنة جاهزة للتوزيع بالفسحة.", replyEn:"Chef Hassan: Fresh meals ready, hot pastries prepped for recess."},
    {code:"106", deptAr:"مكتب مدير الإدارة التعليمية", deptEn:"Ministry District Director", icon:"🏛️", replyAr:"سعادتك! مدرستكم نموذجية ونتابع إنجازاتكم بكل فخر ودعم كامل من الوزارة.", replyEn:"Director: Your school is exemplary, full support from the Ministry!"},
    {code:"000", deptAr:"بوفيه مكتب الناظر (عم إبراهيم)", deptEn:"Principal Office Tea Master", icon:"🍵", replyAr:"أحلى كباية شاي خمسينة في حب مصر مظبوطة بالنعناع في ثواني يا باشا!", replyEn:"The finest mint tea is on its way to your desk right now, Sir!"},
    {code:"999", deptAr:"طوارئ الانضباط والنجدة المدرسية", deptEn:"School Discipline SWAT", icon:"🚨", replyAr:"فرقة الانضباط في حالة تأهب قصوى وجاهزة للتدخل السريع لضبط أي مخالفة.", replyEn:"Discipline squad on high alert ready for instant intervention."},
    {code:"777", deptAr:"رقم الحظ والمكافأة الذهبية", deptEn:"Golden Fortune Hotline", icon:"🍀", replyAr:"مبروك! اتصالك بالرقم الذهبي يمنح مدرستك منحة 500 جنيه لدعم الأنشطة!", replyEn:"Jackpot! Dialing 777 grants your school a 500 EGP activity bonus!", bonus:500}
  ];

  // 4. Urgent Inbox Memos State
  const [memos, setMemos] = v.useState([
    {id:"memo-1", fromAr:"معلم أول الرياضيات (أ. ممدوح)", fromEn:"Lead Math Teacher", titleAr:"طلب سلفة عاجلة لشراء أقلام سبورة وأدوات هندسية للمتفوقين", titleEn:"Urgent stipend for whiteboard markers & geometry sets", cost:300, repGain:10, moraleGain:15, handled:false},
    {id:"memo-2", fromAr:"أمين عام اتحاد الطلاب", fromEn:"Student Council President", titleAr:"عريضة لتنظيم يوم رياضي ودوري خماسي بين الفصول بالملعب", titleEn:"Petition for campus 5-a-side football tournament", cost:450, repGain:20, moraleGain:25, handled:false},
    {id:"memo-3", fromAr:"مسؤول الصيانة والخدمات", fromEn:"Campus Facility Manager", titleAr:"مذكرة لصيانة فلاتر مياه الشرب وتجديد شمعات التنقية بالطوابق", titleEn:"Memo to replace 7-stage water purification filters", cost:500, repGain:15, moraleGain:20, handled:false},
    {id:"memo-4", fromAr:"مجلس أولياء الأمور", fromEn:"Parents Association Board", titleAr:"طلب دعم رحلة ثقافية إلى المتحف المصري الكبير والأهرامات", titleEn:"Subsidized excursion to the Grand Egyptian Museum", cost:600, repGain:25, moraleGain:30, handled:false}
  ]);

  // 5. Classroom Walkthrough Minigame
  const [currentClassroom, setCurrentClassroom] = v.useState(1);
  const [classroomFeedback, setClassroomFeedback] = v.useState(null);
  const classrooms = [
    {id:1, nameAr:"فصل 1/1 - لغة عربية وتربية إسلامية", nameEn:"Class 1/1 - Arabic & Islamic Studies", teacherAr:"أ. عبد الحميد (خبير النحو)", teacherEn:"Mr. Abdelhamid (Grammar)", subjectAr:"إعراب قصيدة نهج البردة", attendance:"96%", discipline:"ممتاز", mood:"نشط ومتفاعل"},
    {id:2, nameAr:"فصل 2/3 - علوم وأحياء وتجارب", nameEn:"Class 2/3 - Biology & Experiments", teacherAr:"د. نهال (أستاذة الأحياء)", teacherEn:"Dr. Nehal (Biology)", subjectAr:"تشريح الزهرة والخلية النباتية", attendance:"94%", discipline:"جيد جداً", mood:"تركيز عالي"},
    {id:3, nameAr:"فصل 3/2 - رياضيات وجبر متقدم", nameEn:"Class 3/2 - Advanced Calculus", teacherAr:"أ. عصام (صانع الأوائل)", teacherEn:"Mr. Essam (Maths)", subjectAr:"حل المعادلات من الدرجة الثالثة", attendance:"98%", discipline:"هادئ ومثالي", mood:"حماس شديد"}
  ];

  if(!t) return null;

  // Handlers
  const handleResolveAlert = (alert) => {
    I.playBell();
    I.playAchievementFanfare();
    setCctvAlerts(prev => prev.map(a => a.id === alert.id ? {...a, resolved:true} : a));
    setCctvLog(prev => [`[${new Date().toLocaleTimeString()}] تم حسم (${alert.titleAr}) بنجاح (+${alert.reward} ج.م)`, ...prev]);
    a(prev => ({
      ...prev,
      budget: prev.budget + alert.reward,
      reputation: Math.min(100, (prev.reputation || 70) + 5)
    }));
  };

  const handleTakeSnapshot = () => {
    I.playCardFlip();
    setSnapshotCount(prev => prev + 1);
    setCctvLog(prev => [`[${new Date().toLocaleTimeString()}] 📸 تم التقاط لقطة شاشة أمنية رسمية وحفظها في أرشيف الحرم.`, ...prev]);
  };

  const handleToggleAlarm = () => {
    if(!alarmActive) {
      I.playAlarm();
      setAlarmActive(true);
      setCctvLog(prev => [`[${new Date().toLocaleTimeString()}] 🚨 تم إطلاق صفارة الطوارئ وتفريق التجمعات بالممرات.`, ...prev]);
    } else {
      setAlarmActive(false);
    }
  };

  const handleIssueVerdict = (courtCase, verdictType) => {
    I.playStampAccept();
    I.playAchievementFanfare();
    const verdictNames = {
      service: "خدمة عامة وتنظيم المكتبة 10 أيام",
      suspension: "فصل تأديبي 3 أيام واستدعاء ولي الأمر",
      pledge: "تعهد خطي مشدد وغرامة صيانة",
      amnesty: "عفو تربوي وإحالة للإرشاد النفسي"
    };
    setVerdictHistory(prev => [{
      caseId: courtCase.id,
      studentName: courtCase.studentName,
      verdict: verdictNames[verdictType],
      time: new Date().toLocaleTimeString()
    }, ...prev]);
    a(prev => ({
      ...prev,
      reputation: Math.min(100, (prev.reputation || 70) + 8),
      teachers: (prev.teachers || []).map(t => ({...t, morale: Math.min(100, (t.morale || 70) + 6)}))
    }));
  };

  const handleDialNumber = (digit) => {
    I.playCalculatorBeep();
    if(dialNumber.length < 3) {
      setDialNumber(prev => prev + digit);
    }
  };

  const handleMakeCall = (codeToCall) => {
    const target = codeToCall || dialNumber;
    const found = phoneBook.find(p => p.code === target);
    I.playDeskPhoneRing();
    setCallActive(true);
    if(found) {
      setCallDetails(found);
      if(found.bonus) {
        a(prev => ({...prev, budget: prev.budget + found.bonus}));
      }
    } else {
      setCallDetails({
        code: target,
        deptAr: "رقم غير مدرج بالدليل الداخلي",
        deptEn: "Unlisted Extension",
        icon: "📵",
        replyAr: "عفواً الرقم الذي طلبته غير موجود بدليل مكتب الناظر، يرجى مراجعة الدليل السريع.",
        replyEn: "Number not in directory, please check speed dial list."
      });
    }
  };

  const handleMemoDecision = (memo, decision) => {
    if(decision === "approve") {
      if(r.budget < memo.cost) {
        I.playStampReject();
        alert(n ? "الميزانية غير كافية لتمويل المذكرة!" : "Insufficient budget!");
        return;
      }
      I.playStampAccept();
      I.playCashRegister();
      a(prev => ({
        ...prev,
        budget: Math.max(0, prev.budget - memo.cost),
        reputation: Math.min(100, (prev.reputation || 70) + memo.repGain),
        teachers: (prev.teachers || []).map(t => ({...t, morale: Math.min(100, (t.morale || 70) + memo.moraleGain)}))
      }));
    } else {
      I.playStampReject();
    }
    setMemos(prev => prev.map(m => m.id === memo.id ? {...m, handled:true, decision} : m));
  };

  const handleClassroomAction = (actionType) => {
    if(actionType === "cheer") {
      I.playClapSnippet();
      setClassroomFeedback(n ? "👏 ألقيت كلمة تشجيعية رفعت معنويات الطلاب والمدرسين بشكل باهر (+10 معنويات)" : "Encouraged class! (+10 Morale)");
      a(prev => ({...prev, teachers: (prev.teachers || []).map(t => ({...t, morale: Math.min(100, (t.morale || 70) + 10)}))}));
    } else if(actionType === "award") {
      I.playAchievementFanfare();
      setClassroomFeedback(n ? "🌟 كافأت الطالب المتفوق بكارت التميز الذهبي (+8 سمعة المدرسة)" : "Awarded top student! (+8 Rep)");
      a(prev => ({...prev, reputation: Math.min(100, (prev.reputation || 70) + 8)}));
    } else {
      I.playCardFlip();
      setClassroomFeedback(n ? "📝 سجلت ملاحظات تربوية ممتازة في دفتر تحضير المعلم (+5 كفاءة)" : "Logged supervisory notes in lesson plan.");
    }
    setTimeout(() => setClassroomFeedback(null), 4000);
  };

  return s.jsx("div", {
    className: "fixed inset-0 z-[100] bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 animate-in fade-in duration-200",
    children: s.jsxs("div", {
      className: "max-w-6xl w-full max-h-[94vh] rounded-3xl bg-slate-900 border-2 border-amber-500/80 text-white shadow-2xl flex flex-col overflow-hidden relative",
      children: [
        // Header
        s.jsxs("div", {
          className: "p-4 sm:p-5 border-b border-amber-500/30 bg-gradient-to-r from-amber-950/80 via-slate-900 to-indigo-950/80 flex items-center justify-between shrink-0",
          children: [
            s.jsxs("div", {
              className: "flex items-center gap-3",
              children: [
                s.jsx("div", {
                  className: "w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400 flex items-center justify-center text-2xl shadow-lg",
                  children: "🏛️"
                }),
                s.jsxs("div", {
                  children: [
                    s.jsxs("div", {
                      className: "flex items-center gap-2",
                      children: [
                        s.jsx("h2", {
                          className: "text-lg sm:text-xl font-black text-amber-300",
                          children: n ? "مركز أنظمة ومحاكاة مكتب المدير الشاملة 🎮" : "Principal Grand HQ & Simulation Systems"
                        }),
                        s.jsx("span", {
                          className: "px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-600 text-white font-mono animate-pulse",
                          children: "LIVE 🔴"
                        })
                      ]
                    }),
                    s.jsx("p", {
                      className: "text-xs text-slate-300 mt-0.5",
                      children: n ? "منظومة تحكم متكاملة: كاميرات المراقبة الحية، محكمة التأديب، هاتف المكتب، المذكرات السريعة، وتفتيش الفصول." : "Comprehensive control suite: Live CCTV, Court Tribunal, Retro Intercom, Urgent Stamps & Walkthroughs."
                    })
                  ]
                })
              ]
            }),
            s.jsx("button", {
              onClick: e,
              className: "w-9 h-9 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition-all cursor-pointer",
              children: s.jsx(ps, { className: "w-5 h-5" })
            })
          ]
        }),

        // Navigation Bar
        s.jsx("div", {
          className: "p-2 bg-slate-950/90 border-b border-slate-800 flex items-center gap-1.5 overflow-x-auto shrink-0 scrollbar-none",
          children: [
            {id:"cctv", icon:"📹", titleAr:"غرفة المراقبة والكاميرات 🔴", titleEn:"Live CCTV Room"},
            {id:"court", icon:"⚖️", titleAr:"محكمة التأديب والانضباط 📜", titleEn:"Disciplinary Court"},
            {id:"phone", icon:"📞", titleAr:"هاتف المكتب والاتصال الداخلي ☎️", titleEn:"Desk Intercom Hotline"},
            {id:"memos", icon:"📋", titleAr:"صندوق المذكرات والأختام ⚡", titleEn:"Urgent Memos & Stamps"},
            {id:"inspection", icon:"🏫", titleAr:"تفتيش الفصول الميداني 🔍", titleEn:"Classroom Walkthrough"}
          ].map(tab => s.jsxs("button", {
            key: tab.id,
            onClick: () => { I.playCardFlip(); setActiveTab(tab.id); },
            className: `px-3.5 py-2 rounded-xl text-xs font-black flex items-center gap-2 whitespace-nowrap transition-all cursor-pointer ${activeTab === tab.id ? "bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20 scale-102" : "bg-slate-850 hover:bg-slate-800 text-slate-300 border border-slate-700"}`,
            children: [
              s.jsx("span", { children: tab.icon }),
              s.jsx("span", { children: n ? tab.titleAr : tab.titleEn })
            ]
          }))
        }),

        // Body Content
        s.jsxs("div", {
          className: "flex-1 overflow-y-auto p-4 sm:p-5 space-y-4",
          children: [
            // TAB 1: CCTV MONITORING ROOM
            activeTab === "cctv" && s.jsxs("div", {
              className: "space-y-4 animate-in fade-in duration-150",
              children: [
                // Top control bar
                s.jsxs("div", {
                  className: "p-3 bg-slate-950/70 rounded-2xl border border-slate-800 flex flex-wrap items-center justify-between gap-2.5",
                  children: [
                    s.jsxs("div", {
                      className: "flex items-center gap-2 text-xs font-mono font-bold text-emerald-400",
                      children: [
                        s.jsx("span", { className: "w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" }),
                        s.jsx("span", { children: "SYSTEM OPERATIONAL: 6 CHANNELS ACTIVE | FPS: 60" })
                      ]
                    }),
                    s.jsxs("div", {
                      className: "flex items-center gap-2",
                      children: [
                        s.jsxs("button", {
                          onClick: handleTakeSnapshot,
                          className: "px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-xs font-bold text-amber-300 border border-amber-500/40 flex items-center gap-1.5 cursor-pointer active:scale-95 transition-all",
                          children: [
                            s.jsx("span", { children: "📸" }),
                            s.jsx("span", { children: n ? `التقاط صورة دليل (${snapshotCount})` : `Snapshot (${snapshotCount})` })
                          ]
                        }),
                        s.jsxs("button", {
                          onClick: handleToggleAlarm,
                          className: `px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer active:scale-95 transition-all ${alarmActive ? "bg-rose-600 text-white animate-bounce shadow-lg shadow-rose-600/50" : "bg-slate-800 text-rose-300 border border-rose-500/40 hover:bg-rose-950/50"}`,
                          children: [
                            s.jsx("span", { children: "🚨" }),
                            s.jsx("span", { children: alarmActive ? (n ? "إيقاف صفارة الإنذار 🔕" : "Silence Siren") : (n ? "تشغيل صفارة الطوارئ 🚨" : "Trigger Siren") })
                          ]
                        })
                      ]
                    })
                  ]
                }),

                // 6 CCTV Camera Grid
                s.jsx("div", {
                  className: "grid grid-cols-1 md:grid-cols-3 gap-3",
                  children: [
                    {id:1, nameAr:"كاميرا 1: فناء الطابور والمقصف", nameEn:"Cam 1: Main Yard & Canteen", location:"Ground Floor", color:"from-slate-900 to-emerald-950/40", icon:"🏫", liveEvent:"طابور منتظم وأصوات النشيد الوطني بالخلفية"},
                    {id:2, nameAr:"كاميرا 2: ممر الفصول الدور الثاني", nameEn:"Cam 2: 2nd Floor Corridor", location:"2nd Floor", color:"from-slate-900 to-blue-950/40", icon:"🏢", liveEvent:"حركة معلمين منتظمة ودخول الفصول بهدوء"},
                    {id:3, nameAr:"كاميرا 3: البوابة الرئيسية وموقف السيارات", nameEn:"Cam 3: Main Gate & Parking", location:"Gate 1", color:"from-slate-900 to-amber-950/40", icon:"🚪", liveEvent:"حارس البوابة يتحقق من هويات الزائرين"},
                    {id:4, nameAr:"كاميرا 4: معمل العلوم والكمبيوتر", nameEn:"Cam 4: Science & IT Labs", location:"East Wing", color:"from-slate-900 to-purple-950/40", icon:"🧪", liveEvent:"الطلاب يرتدون بالطو المعمل لإجراء التجارب"},
                    {id:5, nameAr:"كاميرا 5: ملعب كرة القدم والمدرجات", nameEn:"Cam 5: Pro Turf Arena", location:"Sports Complex", color:"from-slate-900 to-teal-950/40", icon:"⚽", liveEvent:"تدريبات منتخب المدرسة وتمريرات كابتن الفريق"},
                    {id:6, nameAr:"كاميرا 6: السور الخلفي وحديقة المدرسة", nameEn:"Cam 6: Back Fence & Garden", location:"Perimeter", color:"from-slate-900 to-stone-950/40", icon:"🌳", liveEvent:"أشجار الزيتون ونظام الري الذكي يعمل بكفاءة"}
                  ].map(cam => {
                    const alert = cctvAlerts.find(a => a.cam === cam.id && !a.resolved);
                    const isSelected = selectedCam === cam.id;
                    return s.jsxs("div", {
                      key: cam.id,
                      onClick: () => setSelectedCam(cam.id),
                      className: `p-3 rounded-2xl bg-gradient-to-b ${cam.color} border-2 ${isSelected ? "border-amber-400 shadow-xl shadow-amber-500/10" : "border-slate-800 hover:border-slate-700"} flex flex-col justify-between min-h-[190px] relative overflow-hidden cursor-pointer transition-all`,
                      children: [
                        // Scanlines overlay
                        s.jsx("div", { className: "absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%)] bg-[length:100%_4px] pointer-events-none opacity-40" }),
                        
                        // Header info
                        s.jsxs("div", {
                          className: "flex items-center justify-between text-[11px] font-mono text-slate-400 z-10",
                          children: [
                            s.jsxs("div", {
                              className: "flex items-center gap-1.5 font-bold text-white",
                              children: [
                                s.jsx("span", { children: cam.icon }),
                                s.jsx("span", { children: n ? cam.nameAr : cam.nameEn })
                              ]
                            }),
                            s.jsxs("div", {
                              className: "flex items-center gap-1 text-emerald-400 font-black",
                              children: [
                                s.jsx("span", { className: "w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" }),
                                s.jsx("span", { children: "REC" })
                              ]
                            })
                          ]
                        }),

                        // Middle Viewport simulation
                        s.jsxs("div", {
                          className: "my-2 p-2.5 rounded-xl bg-black/40 border border-white/5 flex flex-col justify-center items-center text-center z-10 min-h-[70px]",
                          children: [
                            alert ? s.jsxs("div", {
                              className: "space-y-1 animate-pulse",
                              children: [
                                s.jsx("div", { className: "text-base font-black text-rose-400", children: alert.titleAr }),
                                s.jsx("div", { className: "text-[10px] text-amber-300 font-bold", children: `⚠️ مستوى الخطورة: ${alert.severity.toUpperCase()}` })
                              ]
                            }) : s.jsxs("div", {
                              className: "space-y-1",
                              children: [
                                s.jsx("div", { className: "text-xs font-bold text-slate-300", children: cam.liveEvent }),
                                s.jsx("div", { className: "text-[10px] text-emerald-400 font-mono", children: "✓ لا توجد مخالفات مرصودة" })
                              ]
                            })
                          ]
                        }),

                        // Bottom Actions
                        s.jsxs("div", {
                          className: "flex items-center justify-between text-[10px] z-10 pt-1 border-t border-white/10",
                          children: [
                            s.jsx("span", { className: "text-slate-400 font-mono", children: `${cam.location} • 1080p HD` }),
                            alert ? s.jsxs("button", {
                              onClick: (e) => { e.stopPropagation(); handleResolveAlert(alert); },
                              className: "px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-black flex items-center gap-1 shadow-md shadow-rose-600/30 cursor-pointer active:scale-95 transition-all",
                              children: [
                                s.jsx("span", { children: "⚡" }),
                                s.jsx("span", { children: n ? alert.actionAr : alert.actionEn })
                              ]
                            }) : s.jsx("span", { className: "text-slate-500", children: "تغطية آمنة 🟢" })
                          ]
                        })
                      ]
                    });
                  })
                }),

                // Live log feed
                s.jsxs("div", {
                  className: "p-3 bg-slate-950/80 rounded-2xl border border-slate-800 space-y-1.5",
                  children: [
                    s.jsx("div", { className: "text-xs font-black text-amber-400 flex items-center gap-1.5", children: [s.jsx("span", {children:"📜"}), s.jsx("span", {children: n ? "سجل الأحداث الأمنية المباشر لمكتب المدير:" : "Live Security Operations Log:"})] }),
                    cctvLog.length === 0 ? s.jsx("div", { className: "text-xs text-slate-500 font-mono", children: n ? "لا توجد أحداث طارئة مسجلة حتى الآن. كافة القطاعات آمنة ومنضبطة." : "No urgent incidents recorded yet." }) : s.jsx("div", {
                      className: "space-y-1 max-h-24 overflow-y-auto font-mono text-[11px] text-slate-300",
                      children: cctvLog.map((log, idx) => s.jsx("div", { key: idx, className: "text-emerald-300", children: log }))
                    })
                  ]
                })
              ]
            }),

            // TAB 2: DISCIPLINARY COURT TRIBUNAL
            activeTab === "court" && s.jsxs("div", {
              className: "space-y-4 animate-in fade-in duration-150",
              children: [
                s.jsxs("div", {
                  className: "p-4 bg-gradient-to-r from-amber-950/60 to-slate-950 rounded-2xl border border-amber-500/30 flex items-center justify-between",
                  children: [
                    s.jsxs("div", {
                      children: [
                        s.jsx("h3", { className: "text-base font-black text-amber-300 flex items-center gap-2", children: [s.jsx("span", {children:"⚖️"}), s.jsx("span", {children: n ? "جلسة مجلس التأديب والانضباط المدرسي الحالية" : "Active Disciplinary Tribunal Hearing"})] }),
                        s.jsx("p", { className: "text-xs text-slate-300 mt-0.5", children: n ? "بصفتك رئيس المجلس، استمع إلى دفاع الطالب والشهود وافحص الأحراز ثم أصدر الحكم الإداري الملزم." : "As Chairman, review testimonies and confiscated evidence, then pronounce the official verdict." })
                      ]
                    }),
                    s.jsxs("div", {
                      className: "text-xs font-bold text-amber-400 bg-amber-500/10 px-3 py-1.5 rounded-xl border border-amber-500/30 font-mono",
                      children: ["قضية ", activeCaseIdx + 1, " من ", courtCases.length]
                    })
                  ]
                }),

                // Active Case Card
                (() => {
                  const currentCase = courtCases[activeCaseIdx];
                  return s.jsxs("div", {
                    className: "p-5 rounded-3xl bg-slate-850 border border-slate-700 space-y-4 shadow-xl",
                    children: [
                      // Student name & charge
                      s.jsxs("div", {
                        className: "flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-700",
                        children: [
                          s.jsxs("div", {
                            className: "flex items-center gap-2.5",
                            children: [
                              s.jsx("div", { className: "w-10 h-10 rounded-xl bg-purple-500/20 border border-purple-400 flex items-center justify-center text-xl", children: "👨‍🎓" }),
                              s.jsxs("div", {
                                children: [
                                  s.jsx("h4", { className: "text-sm font-black text-white", children: currentCase.studentName }),
                                  s.jsx("span", { className: "text-[11px] text-rose-400 font-bold", children: n ? "المخالفة: " + currentCase.chargeAr : "Charge: " + currentCase.chargeEn })
                                ]
                              })
                            ]
                          }),
                          s.jsxs("div", {
                            className: "flex items-center gap-1.5",
                            children: courtCases.map((c, i) => s.jsx("button", {
                              key: c.id,
                              onClick: () => { I.playCardFlip(); setActiveCaseIdx(i); },
                              className: `w-7 h-7 rounded-lg text-xs font-black cursor-pointer ${i === activeCaseIdx ? "bg-amber-500 text-slate-950" : "bg-slate-800 text-slate-400 hover:bg-slate-700"}`,
                              children: i + 1
                            }))
                          })
                        ]
                      }),

                      // Evidence & Confession Grid
                      s.jsxs("div", {
                        className: "grid grid-cols-1 md:grid-cols-3 gap-3 text-xs",
                        children: [
                          s.jsxs("div", {
                            className: "p-3 rounded-2xl bg-slate-900 border border-rose-500/30 space-y-1",
                            children: [
                              s.jsx("div", { className: "font-black text-rose-300 flex items-center gap-1", children: [s.jsx("span", {children:"📦"}), s.jsx("span", {children: n ? "الأحراز والمضبوطات:" : "Seized Evidence:"})] }),
                              s.jsx("p", { className: "text-slate-300 text-[11px] leading-relaxed", children: n ? currentCase.evidenceAr : currentCase.evidenceEn })
                            ]
                          }),
                          s.jsxs("div", {
                            className: "p-3 rounded-2xl bg-slate-900 border border-amber-500/30 space-y-1",
                            children: [
                              s.jsx("div", { className: "font-black text-amber-300 flex items-center gap-1", children: [s.jsx("span", {children:"🗣️"}), s.jsx("span", {children: n ? "أقوال واعتراف الطالب:" : "Student Statement:"})] }),
                              s.jsx("p", { className: "text-slate-300 text-[11px] italic leading-relaxed", children: `"${n ? currentCase.confessionAr : currentCase.confessionEn}"` })
                            ]
                          }),
                          s.jsxs("div", {
                            className: "p-3 rounded-2xl bg-slate-900 border border-blue-500/30 space-y-1",
                            children: [
                              s.jsx("div", { className: "font-black text-blue-300 flex items-center gap-1", children: [s.jsx("span", {children:"👨‍🏫"}), s.jsx("span", {children: n ? "رأي الأخصائي والمجلس:" : "Counselor Opinion:"})] }),
                              s.jsx("p", { className: "text-slate-300 text-[11px] leading-relaxed", children: n ? currentCase.witnessAr : currentCase.witnessEn })
                            ]
                          })
                        ]
                      }),

                      // Judicial Verdict Actions
                      s.jsxs("div", {
                        className: "space-y-2 pt-2",
                        children: [
                          s.jsx("div", { className: "text-xs font-black text-amber-300", children: n ? "اختر الحكم التأديبي النهائي المناسب:" : "Choose the Final Tribunal Verdict:" }),
                          s.jsxs("div", {
                            className: "grid grid-cols-2 sm:grid-cols-4 gap-2",
                            children: [
                              s.jsxs("button", {
                                onClick: () => handleIssueVerdict(currentCase, "service"),
                                className: "p-2.5 rounded-xl bg-emerald-600/20 border border-emerald-500/50 hover:bg-emerald-600/40 text-emerald-300 text-xs font-bold text-center cursor-pointer transition-all active:scale-95",
                                children: [s.jsx("div", {className:"text-base mb-0.5", children:"🧹"}), s.jsx("span", {children: n ? "خدمة مجتمعية بالمكتبة" : "Community Service"})]
                              }),
                              s.jsxs("button", {
                                onClick: () => handleIssueVerdict(currentCase, "suspension"),
                                className: "p-2.5 rounded-xl bg-rose-600/20 border border-rose-500/50 hover:bg-rose-600/40 text-rose-300 text-xs font-bold text-center cursor-pointer transition-all active:scale-95",
                                children: [s.jsx("div", {className:"text-base mb-0.5", children:"🚫"}), s.jsx("span", {children: n ? "فصل تأديبي 3 أيام" : "3-Day Suspension"})]
                              }),
                              s.jsxs("button", {
                                onClick: () => handleIssueVerdict(currentCase, "pledge"),
                                className: "p-2.5 rounded-xl bg-amber-600/20 border border-amber-500/50 hover:bg-amber-600/40 text-amber-300 text-xs font-bold text-center cursor-pointer transition-all active:scale-95",
                                children: [s.jsx("div", {className:"text-base mb-0.5", children:"📝"}), s.jsx("span", {children: n ? "تعهد خطي واستدعاء ولي الأمر" : "Parent Pledge & Fine"})]
                              }),
                              s.jsxs("button", {
                                onClick: () => handleIssueVerdict(currentCase, "amnesty"),
                                className: "p-2.5 rounded-xl bg-blue-600/20 border border-blue-500/50 hover:bg-blue-600/40 text-blue-300 text-xs font-bold text-center cursor-pointer transition-all active:scale-95",
                                children: [s.jsx("div", {className:"text-base mb-0.5", children:"🕊️"}), s.jsx("span", {children: n ? "عفو تربوي وإرشاد نفسي" : "Amnesty & Counseling"})]
                              })
                            ]
                          })
                        ]
                      })
                    ]
                  });
                })(),

                // Verdict History
                verdictHistory.length > 0 && s.jsxs("div", {
                  className: "p-3 bg-slate-950/80 rounded-2xl border border-slate-800 space-y-1.5",
                  children: [
                    s.jsx("div", { className: "text-xs font-black text-amber-400", children: n ? "📜 القرارات التأديبية الصادرة مؤخراً:" : "Recently Issued Disciplinary Decrees:" }),
                    s.jsx("div", {
                      className: "space-y-1 text-xs text-slate-300 font-mono",
                      children: verdictHistory.map((vh, i) => s.jsxs("div", {
                        key: i,
                        className: "p-2 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between",
                        children: [
                          s.jsxs("span", { children: ["⚖️ قرار للطالب: ", s.jsx("strong", {className:"text-amber-300", children: vh.studentName}), " - الحكم: ", s.jsx("span", {className:"text-emerald-400 font-bold", children: vh.verdict})] }),
                          s.jsx("span", { className: "text-[10px] text-slate-500", children: vh.time })
                        ]
                      }))
                    })
                  ]
                })
              ]
            }),

            // TAB 3: DESK ROTARY PHONE & INTERCOM HOTLINE
            activeTab === "phone" && s.jsxs("div", {
              className: "space-y-4 animate-in fade-in duration-150",
              children: [
                s.jsxs("div", {
                  className: "grid grid-cols-1 md:grid-cols-2 gap-4",
                  children: [
                    // Vintage Rotary & Keypad Simulator
                    s.jsxs("div", {
                      className: "p-5 rounded-3xl bg-slate-850 border border-amber-500/40 space-y-4 shadow-xl flex flex-col justify-between",
                      children: [
                        s.jsxs("div", {
                          className: "space-y-2",
                          children: [
                            s.jsx("div", { className: "text-xs font-black text-amber-300 flex items-center gap-2", children: [s.jsx("span", {children:"☎️"}), s.jsx("span", {children: n ? "لوحة هاتف مكتب المدير الدوار التفاعلي:" : "Vintage Desk Intercom Dialpad:"})] }),
                            // Dial display screen
                            s.jsxs("div", {
                              className: "p-3 rounded-2xl bg-black/60 border border-amber-500/40 flex items-center justify-between font-mono",
                              children: [
                                s.jsx("span", { className: "text-2xl font-black text-amber-400 tracking-widest", children: dialNumber || (n ? "طلب رقم..." : "Dial...") }),
                                s.jsx("button", {
                                  onClick: () => setDialNumber(""),
                                  className: "text-xs text-rose-400 hover:text-rose-300 font-bold cursor-pointer",
                                  children: n ? "مسح ✖" : "Clear"
                                })
                              ]
                            })
                          ]
                        }),

                        // Keypad 3x4
                        s.jsxs("div", {
                          className: "grid grid-cols-3 gap-2.5 py-2",
                          children: [
                            ["1","2","3"],
                            ["4","5","6"],
                            ["7","8","9"],
                            ["*","0","#"]
                          ].flat().map(num => s.jsx("button", {
                            key: num,
                            onClick: () => handleDialNumber(num),
                            className: "h-12 rounded-2xl bg-slate-800 hover:bg-amber-500 hover:text-slate-950 text-white font-black text-lg border border-slate-700 shadow-md active:scale-95 transition-all cursor-pointer flex items-center justify-center font-mono",
                            children: num
                          }))
                        }),

                        // Call Action Button
                        s.jsxs("button", {
                          onClick: () => handleMakeCall(dialNumber),
                          disabled: !dialNumber,
                          className: "w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-40 text-white font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/30 cursor-pointer active:scale-98 transition-all",
                          children: [
                            s.jsx("span", { children: "📞" }),
                            s.jsx("span", { children: n ? "اتصال بالخط الداخلي المباشر" : "Call Department Hotline" })
                          ]
                        })
                      ]
                    }),

                    // Speed Dial Directory & Active Call Receiver
                    s.jsxs("div", {
                      className: "space-y-3",
                      children: [
                        // Active Call Monitor
                        callActive && callDetails && s.jsxs("div", {
                          className: "p-4 rounded-3xl bg-emerald-950/50 border-2 border-emerald-500 text-white space-y-2 animate-in zoom-in-95 duration-150 shadow-xl",
                          children: [
                            s.jsxs("div", {
                              className: "flex items-center justify-between pb-2 border-b border-emerald-500/30",
                              children: [
                                s.jsxs("div", {
                                  className: "flex items-center gap-2 font-black text-sm text-emerald-300",
                                  children: [
                                    s.jsx("span", { className: "text-2xl", children: callDetails.icon }),
                                    s.jsx("span", { children: n ? callDetails.deptAr : callDetails.deptEn })
                                  ]
                                }),
                                s.jsx("span", { className: "text-xs font-mono font-bold text-emerald-400 animate-pulse", children: "● CONNECTED" })
                              ]
                            }),
                            s.jsx("p", {
                              className: "text-xs text-slate-100 leading-relaxed font-bold",
                              children: `"${n ? callDetails.replyAr : callDetails.replyEn}"`
                            }),
                            s.jsx("button", {
                              onClick: () => { I.playCardFlip(); setCallActive(false); },
                              className: "w-full py-1.5 rounded-xl bg-rose-600/80 hover:bg-rose-600 text-xs font-bold text-white cursor-pointer transition-all",
                              children: n ? "إنهاء المكالمة 📵" : "Hang Up"
                            })
                          ]
                        }),

                        // Speed dial list
                        s.jsxs("div", {
                          className: "p-4 rounded-3xl bg-slate-850 border border-slate-700 space-y-2.5",
                          children: [
                            s.jsx("div", { className: "text-xs font-black text-amber-300", children: n ? "📖 دليل الاتصال السريع المباشر لمكتب المدير:" : "Direct Extension Speed Dial:" }),
                            s.jsx("div", {
                              className: "space-y-1.5 max-h-[300px] overflow-y-auto pr-1",
                              children: phoneBook.map(contact => s.jsxs("button", {
                                key: contact.code,
                                onClick: () => { setDialNumber(contact.code); handleMakeCall(contact.code); },
                                className: "w-full p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-amber-500/40 text-right flex items-center justify-between transition-all cursor-pointer group",
                                children: [
                                  s.jsxs("div", {
                                    className: "flex items-center gap-2 text-xs",
                                    children: [
                                      s.jsx("span", { className: "text-lg", children: contact.icon }),
                                      s.jsx("span", { className: "font-bold text-slate-200 group-hover:text-amber-300", children: n ? contact.deptAr : contact.deptEn })
                                    ]
                                  }),
                                  s.jsxs("span", {
                                    className: "text-xs font-mono font-black text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-lg border border-amber-500/20",
                                    children: ["Ext ", contact.code]
                                  })
                                ]
                              }))
                            })
                          ]
                        })
                      ]
                    })
                  ]
                })
              ]
            }),

            // TAB 4: URGENT INBOX MEMOS & STAMPS
            activeTab === "memos" && s.jsxs("div", {
              className: "space-y-4 animate-in fade-in duration-150",
              children: [
                s.jsxs("div", {
                  className: "p-4 bg-gradient-to-r from-indigo-950/60 to-slate-950 rounded-2xl border border-indigo-500/30 flex items-center justify-between",
                  children: [
                    s.jsxs("div", {
                      children: [
                        s.jsx("h3", { className: "text-base font-black text-indigo-300 flex items-center gap-2", children: [s.jsx("span", {children:"📥"}), s.jsx("span", {children: n ? "صندوق المذكرات والطلبات الإدارية العاجلة" : "Principal's Urgent Inbox & Decisions"})] }),
                        s.jsx("p", { className: "text-xs text-slate-300 mt-0.5", children: n ? "مذكرات واردة من المدرسين والطلاب وأولياء الأمور تتطلب توقيع وختم الناظر الفوري." : "Incoming urgent memos requiring immediate principal stamp or referral." })
                      ]
                    }),
                    s.jsxs("div", {
                      className: "text-xs font-bold text-emerald-400 bg-emerald-500/10 px-3 py-1.5 rounded-xl border border-emerald-500/30 font-mono",
                      children: ["ميزانية المدرسة: ", r.budget, " ج.م 💵"]
                    })
                  ]
                }),

                // Memos list
                s.jsx("div", {
                  className: "grid grid-cols-1 md:grid-cols-2 gap-3",
                  children: memos.map(memo => s.jsxs("div", {
                    key: memo.id,
                    className: `p-4 rounded-3xl bg-slate-850 border-2 ${memo.handled ? "opacity-60 border-slate-800" : "border-indigo-500/40 hover:border-indigo-400"} space-y-3 shadow-xl transition-all relative overflow-hidden`,
                    children: [
                      s.jsxs("div", {
                        className: "flex items-center justify-between pb-2 border-b border-slate-700",
                        children: [
                          s.jsxs("span", { className: "text-xs font-bold text-amber-300 flex items-center gap-1.5", children: [s.jsx("span", {children:"✍️"}), s.jsx("span", {children: n ? memo.fromAr : memo.fromEn})] }),
                          s.jsxs("span", { className: "text-[11px] font-mono text-emerald-400 font-bold", children: ["التكلفة: ", memo.cost, " ج.م"] })
                        ]
                      }),
                      s.jsx("p", { className: "text-xs text-slate-200 font-bold leading-relaxed", children: n ? memo.titleAr : memo.titleEn }),
                      s.jsxs("div", {
                        className: "flex items-center gap-2 text-[10px] text-slate-400 font-mono",
                        children: [
                          s.jsxs("span", { className: "text-emerald-400", children: ["+ ", memo.repGain, " سمعة"] }),
                          s.jsx("span", { children: "•" }),
                          s.jsxs("span", { className: "text-purple-400", children: ["+ ", memo.moraleGain, "% معنويات"] })
                        ]
                      }),
                      memo.handled ? s.jsx("div", {
                        className: `p-2 rounded-xl text-center text-xs font-black ${memo.decision === "approve" ? "bg-emerald-600/30 text-emerald-300 border border-emerald-500" : "bg-rose-600/30 text-rose-300 border border-rose-500"}`,
                        children: memo.decision === "approve" ? (n ? "✅ تم اعتماد وصرف المذكرة بختم الناظر" : "Approved & Funded") : (n ? "❌ تم رفض المذكرة وحفظها" : "Rejected & Archived")
                      }) : s.jsxs("div", {
                        className: "flex items-center gap-2 pt-1",
                        children: [
                          s.jsxs("button", {
                            onClick: () => handleMemoDecision(memo, "approve"),
                            className: "flex-1 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/20 cursor-pointer active:scale-95 transition-all",
                            children: [s.jsx("span", {children:"✔️"}), s.jsx("span", {children: n ? "موافقة واعتماد" : "Approve"})]
                          }),
                          s.jsxs("button", {
                            onClick: () => handleMemoDecision(memo, "reject"),
                            className: "flex-1 py-2 rounded-xl bg-slate-800 hover:bg-rose-900/50 text-rose-300 font-black text-xs border border-rose-500/30 flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 transition-all",
                            children: [s.jsx("span", {children:"✖️"}), s.jsx("span", {children: n ? "رفض وحفظ" : "Reject"})]
                          })
                        ]
                      })
                    ]
                  }))
                })
              ]
            }),

            // TAB 5: CLASSROOM INSPECTION WALKTHROUGH
            activeTab === "inspection" && s.jsxs("div", {
              className: "space-y-4 animate-in fade-in duration-150",
              children: [
                s.jsxs("div", {
                  className: "p-4 bg-gradient-to-r from-teal-950/60 to-slate-950 rounded-2xl border border-teal-500/30 flex items-center justify-between",
                  children: [
                    s.jsxs("div", {
                      children: [
                        s.jsx("h3", { className: "text-base font-black text-teal-300 flex items-center gap-2", children: [s.jsx("span", {children:"🔍"}), s.jsx("span", {children: n ? "جولة تفتيش الفصول الميدانية المفاجئة لمكتب المدير" : "Surprise Classroom Walkthrough Minigame"})] }),
                        s.jsx("p", { className: "text-xs text-slate-300 mt-0.5", children: n ? "ادخل الفصول أثناء الحصص وتفقد دفتر التحضير وتفاعل المعلم مع الطلاب ووجه المكافآت." : "Step into active classrooms to evaluate teacher delivery, notebook prep, and student engagement." })
                      ]
                    }),
                    s.jsxs("div", {
                      className: "flex items-center gap-1.5",
                      children: classrooms.map(c => s.jsx("button", {
                        key: c.id,
                        onClick: () => { I.playCardFlip(); setCurrentClassroom(c.id); },
                        className: `px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer transition-all ${c.id === currentClassroom ? "bg-teal-500 text-slate-950 font-black shadow-md" : "bg-slate-800 text-slate-400 hover:bg-slate-700"}`,
                        children: n ? `فصل ${c.id}` : `Class ${c.id}`
                      }))
                    })
                  ]
                }),

                // Selected Classroom Inspection Card
                (() => {
                  const activeClass = classrooms.find(c => c.id === currentClassroom) || classrooms[0];
                  return s.jsxs("div", {
                    className: "p-5 rounded-3xl bg-slate-850 border-2 border-teal-500/40 space-y-4 shadow-2xl",
                    children: [
                      // Header info
                      s.jsxs("div", {
                        className: "flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-700",
                        children: [
                          s.jsxs("div", {
                            className: "flex items-center gap-3",
                            children: [
                              s.jsx("div", { className: "w-12 h-12 rounded-2xl bg-teal-500/20 border border-teal-400 flex items-center justify-center text-2xl", children: "👨‍🏫" }),
                              s.jsxs("div", {
                                children: [
                                  s.jsx("h4", { className: "text-base font-black text-white", children: n ? activeClass.nameAr : activeClass.nameEn }),
                                  s.jsx("span", { className: "text-xs text-teal-300 font-bold", children: n ? `المعلم: ${activeClass.teacherAr} • موضوع الحصة: ${activeClass.subjectAr}` : `Teacher: ${activeClass.teacherEn}` })
                                ]
                              })
                            ]
                          }),
                          s.jsxs("div", {
                            className: "flex items-center gap-2 text-xs font-mono font-bold",
                            children: [
                              s.jsxs("span", { className: "px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/30", children: ["حضور: ", activeClass.attendance] }),
                              s.jsxs("span", { className: "px-2.5 py-1 rounded-lg bg-purple-500/20 text-purple-300 border border-purple-500/30", children: ["الانضباط: ", activeClass.discipline] })
                            ]
                          })
                        ]
                      }),

                      // Simulated Blackboard & Classroom Atmosphere
                      s.jsxs("div", {
                        className: "p-4 rounded-2xl bg-[#1b382b] border-4 border-[#8B5A2B] shadow-inner text-emerald-100 font-serif space-y-2 relative overflow-hidden",
                        children: [
                          s.jsx("div", { className: "text-center font-bold text-sm text-yellow-200 border-b border-white/20 pb-1", children: "بسم الله الرحمن الرحيم - سبورة الفصل التفاعلية" }),
                          s.jsxs("div", {
                            className: "flex justify-between text-xs text-slate-200 pt-1",
                            children: [
                              s.jsx("span", { children: `الدرس: ${activeClass.subjectAr}` }),
                              s.jsx("span", { children: `الحالة: ${activeClass.mood}` })
                            ]
                          })
                        ]
                      }),

                      // Principal Interaction Actions
                      s.jsxs("div", {
                        className: "space-y-2 pt-2",
                        children: [
                          s.jsx("div", { className: "text-xs font-black text-teal-300", children: n ? "اختر توجيه الناظر وقراره الفوري داخل الحصة:" : "Principal On-Site Interaction:" }),
                          s.jsxs("div", {
                            className: "grid grid-cols-1 sm:grid-cols-3 gap-2.5",
                            children: [
                              s.jsxs("button", {
                                onClick: () => handleClassroomAction("cheer"),
                                className: "p-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs flex items-center justify-center gap-2 cursor-pointer shadow-lg active:scale-95 transition-all",
                                children: [s.jsx("span", {children:"👏"}), s.jsx("span", {children: n ? "إلقاء كلمة تشجيعية للفصل" : "Encourage Class"})]
                              }),
                              s.jsxs("button", {
                                onClick: () => handleClassroomAction("award"),
                                className: "p-3 rounded-2xl bg-gradient-to-r from-amber-600 to-yellow-600 hover:from-amber-500 hover:to-yellow-500 text-slate-950 font-black text-xs flex items-center justify-center gap-2 cursor-pointer shadow-lg active:scale-95 transition-all",
                                children: [s.jsx("span", {children:"🌟"}), s.jsx("span", {children: n ? "منح وسام الطالب المثالي" : "Award Star Student"})]
                              }),
                              s.jsxs("button", {
                                onClick: () => handleClassroomAction("notes"),
                                className: "p-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-teal-300 border border-teal-500/40 font-black text-xs flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition-all",
                                children: [s.jsx("span", {children:"📝"}), s.jsx("span", {children: n ? "تسجيل توجيه بدفتر التحضير" : "Log Supervisory Notes"})]
                              })
                            ]
                          })
                        ]
                      }),

                      // Feedback alert
                      classroomFeedback && s.jsx("div", {
                        className: "p-3 rounded-xl bg-emerald-950 border border-emerald-500 text-emerald-200 text-xs font-black text-center animate-in zoom-in-95 duration-150",
                        children: classroomFeedback
                      })
                    ]
                  });
                })()
              ]
            })
          ]
        })
      ]
    })
  });
};'''

code = code[:pos_start] + new_wse_code + code[pos_end:]

with open("assets/app-bundle.js", "w") as f:
    f.write(code)

with open("assets/index-BeRTxH1o.js", "w") as f:
    f.write(code)

for dist_js in glob.glob("dist/assets/*.js"):
    if any(k in dist_js for k in ["index", "app", "BeRTxH1o", "BoWY_e0a", "CwhFnn8I", "C9sCu8NM", "QB4pRpBj", "CM2YjkZp", "DOZePYex"]):
        with open(dist_js, "w") as f:
            f.write(code)
        print("Updated:", dist_js)

ts = int(time.time())
with open("index.html", "r") as f:
    html = f.read()

html = re.sub(r'app-bundle\.js\?v=\d+', f'app-bundle.js?v={ts}', html)
html = re.sub(r'app-bundle\.css\?v=\d+', f'app-bundle.css?v={ts}', html)

with open("index.html", "w") as f:
    f.write(html)
with open("dist/index.html", "w") as f:
    f.write(html)

print("SUCCESS: REBUILT GRAND INTERACTIVE PRINCIPAL SYSTEMS HUB WITH 5 NEW SIMULATION SUITES!")
