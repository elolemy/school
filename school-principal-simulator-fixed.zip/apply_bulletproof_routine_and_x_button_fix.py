import re

print("Applying bulletproof routine flow and enhanced X exit button logic...")

with open("assets/app-bundle.js", "r") as f:
    code = f.read()

# 1. Update CJe header top "X" button to explicitly cancel morning routine step and close CJe
old_cje_top_btn = 's.jsx("button",{onClick:()=>{I.playStampAccept(),e()},className:"p-1.5 rounded-lg text-amber-300/70 hover:text-white hover:bg-white/10 transition-colors",children:s.jsx(ps,{className:"w-5 h-5"})})'
new_cje_top_btn = 's.jsx("button",{onClick:()=>{I.playStampAccept();window.__morningRoutineStep=null;e()},className:"px-2.5 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/40 text-rose-200 hover:text-white border border-rose-500/30 transition-all flex items-center justify-center font-bold text-xs gap-1 cursor-pointer",title:c?"خروج إلى المكتب دون متابعة":"Exit to Desk",children:[s.jsx(ps,{className:"w-4 h-4"}),s.jsx("span",{className:"text-xs font-black"},c?"خروج ✖":"Exit ✖")]})'

if old_cje_top_btn in code:
    code = code.replace(old_cje_top_btn, new_cje_top_btn)
    print("✓ Successfully updated CJe top X exit button")
else:
    print("! Using regex to update CJe top close button...")
    code = re.sub(
        r's\.jsx\("button",\{onClick:\(\)=>\{I\.playStampAccept\(\),e\(\)\},className:"p-1\.5 rounded-lg text-amber-300/70[^\"]+",children:s\.jsx\(ps,\{className:"w-5 h-5"\}\)\}\)',
        new_cje_top_btn,
        code
    )

# 2. Update wXe onClose
code = re.sub(
    r's\.jsx\(wXe,\{isOpen:fr,onClose:\(\)=>\{[^\}]+\},language:i\.settings\.language\}\)',
    's.jsx(wXe,{isOpen:fr,onClose:()=>{Js(!1);try{localStorage.setItem("school_tutorial_completed","true")}catch{}if(window.__morningRoutineStep==="tutorial"){window.__morningRoutineStep="story";is(!0)}else{window.__morningRoutineStep=null}},language:i.settings.language})',
    code
)

# 3. Update aZe onClose
code = re.sub(
    r's\.jsx\(aZe,\{isOpen:ms,onClose:\(\)=>\{[^\}]+\},currentDay:i\.currentDay',
    's.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1),l(pe=>({...pe,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));if(window.__morningRoutineStep==="story"){window.__morningRoutineStep="regulations";we(!0)}else{window.__morningRoutineStep=null}},currentDay:i.currentDay',
    code
)

# 4. Update CJe onClose
code = re.sub(
    r's\.jsx\(CJe,\{isOpen:de,onClose:\(\)=>\{[^\}]+\},language:i\.settings\.language,isDark:vi\}\)',
    's.jsx(CJe,{isOpen:de,onClose:()=>{we(!1);if(window.__morningRoutineStep==="regulations"){window.__morningRoutineStep=null;p(!0)}else{window.__morningRoutineStep=null}},language:i.settings.language,isDark:vi})',
    code
)

# 5. Manual triggers for regulations
manual_reg_trigger = "()=>{p(!1);is(!1);Js(!1);window.__morningRoutineStep=null;we(!0)}"

code = code.replace('onOpenDailyRegulations:()=>{window.__morningRoutineStep=null;we(!0)}', f'onOpenDailyRegulations:{manual_reg_trigger}')
code = code.replace('onOpenDailyRegulations:()=>we(!0)', f'onOpenDailyRegulations:{manual_reg_trigger}')
code = code.replace('onOpenRulebook:()=>{window.__morningRoutineStep=null;we(!0)}', f'onOpenRulebook:{manual_reg_trigger}')
code = code.replace('onOpenRulebook:()=>we(!0)', f'onOpenRulebook:{manual_reg_trigger}')
code = code.replace('window.addEventListener("open-rulebook",()=>{window.__morningRoutineStep=null;we(!0)})', f'window.addEventListener("open-rulebook",{manual_reg_trigger})')
code = code.replace('window.addEventListener("open-rulebook",()=>we(!0))', f'window.addEventListener("open-rulebook",{manual_reg_trigger})')

# 6. Morning routine start buttons
code = re.sub(
    r'onStartGame:\(\)=>\{[^\}]+\}',
    'onStartGame:()=>{I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!1);is(!1);we(!1);window.__morningRoutineStep="tutorial";Js(!0);c("desk")}',
    code
)

code = re.sub(
    r'onStartMorningRoutine:\(\)=>\{[^\}]+\}',
    'onStartMorningRoutine:()=>{I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!1);is(!1);we(!1);window.__morningRoutineStep="tutorial";Js(!0);c("desk")}',
    code
)

with open("assets/app-bundle.js", "w") as f:
    f.write(code)

print("Update completed successfully!")
