import re

print("Applying exact requested flow...")

with open("assets/app-bundle.js", "r") as f:
    code = f.read()

# 1. CJe render: closing CJe MUST ONLY close CJe (we(!1))
old_cje = """s.jsx(CJe,{isOpen:de,onClose:()=>{we(!1);if(window.__morningRoutineStep==="regulations"){window.__morningRoutineStep=null;p(!0)}else{window.__morningRoutineStep=null}},language:i.settings.language,isDark:vi})"""
new_cje = """s.jsx(CJe,{isOpen:de,onClose:()=>we(!1),language:i.settings.language,isDark:vi})"""
if old_cje in code:
    code = code.replace(old_cje, new_cje)
else:
    code = re.sub(r's\.jsx\(CJe,\{isOpen:de,onClose:\(\)=>\{[^\}]+\},language:i\.settings\.language,isDark:vi\}\)', new_cje, code)

# 2. aZe render: closing aZe closes story and only opens briefing if day has not started yet
old_aze_pattern = r's\.jsx\(aZe,\{isOpen:ms,onClose:\(\)=>\{[^\}]+\},currentDay:i\.currentDay'
new_aze = 's.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1),l(pe=>({...pe,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));!i.isDayStarted&&p(!0)},currentDay:i.currentDay'
code = re.sub(old_aze_pattern, new_aze, code)

# 3. wXe render: closing wXe only closes wXe (Js(!1))
old_wxe_pattern = r's\.jsx\(wXe,\{isOpen:fr,onClose:\(\)=>\{[^\}]+\},language:i\.settings\.language\}\)'
new_wxe = 's.jsx(wXe,{isOpen:fr,onClose:()=>Js(!1),language:i.settings.language})'
code = re.sub(old_wxe_pattern, new_wxe, code)

# 4. SJe onStartGame and onStartMorningRoutine: starts morning routine by opening the story (is(!0))
code = re.sub(
    r'onStartGame:\(\)=>\{[^\}]+c\("desk"\)\}',
    'onStartGame:()=>{I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!1,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!1);we(!1);is(!0);c("desk")}',
    code
)

code = re.sub(
    r'onStartMorningRoutine:\(\)=>\{[^\}]+c\("desk"\)\}',
    'onStartMorningRoutine:()=>{I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!1,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!1);we(!1);is(!0);c("desk")}',
    code
)

# 5. Make sure onOpenDailyRegulations and onOpenRulebook only open CJe (we(!0))
code = code.replace('onOpenDailyRegulations:()=>{window.__morningRoutineStep=null;we(!0)}', 'onOpenDailyRegulations:()=>we(!0)')
code = code.replace('onOpenRulebook:()=>{window.__morningRoutineStep=null;we(!0)}', 'onOpenRulebook:()=>we(!0)')
code = code.replace('window.addEventListener("open-rulebook",()=>{window.__morningRoutineStep=null;we(!0)})', 'window.addEventListener("open-rulebook",()=>we(!0))')

with open("assets/app-bundle.js", "w") as f:
    f.write(code)

print("Flow successfully applied!")
