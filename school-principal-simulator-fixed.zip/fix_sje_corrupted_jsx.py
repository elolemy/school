import re

print("Replacing corrupted SJe JSX block in both bundle files...")

clean_sje_block = 'd&&s.jsx(SJe,{gameState:i,onStartGame:()=>{I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!1);is(!1);we(!1);window.__morningRoutineStep="tutorial";Js(!0);c("desk")},onStartMorningRoutine:()=>{I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!1);is(!1);we(!1);window.__morningRoutineStep="tutorial";Js(!0);c("desk")},onRestartStory:e,onUpdateGameState:ae=>{l(ae),ri(ae)},onOpenSettings:()=>Ae(!0),onOpenRulebook:()=>{p(!1);is(!1);Js(!1);window.__morningRoutineStep=null;we(!0)},onOpenTutorial:()=>Js(!0),onOpenAchievements:()=>ye(!0),onOpenSupportChat:()=>Tt(!0),onLogout:r}),'

for target_file in ["assets/app-bundle.js", "public/assets/app-bundle.js"]:
    print(f"Fixing {target_file}...")
    with open(target_file, "r") as f:
        code = f.read()

    # Find start and end of corrupted SJe block
    start_str = 'd&&s.jsx(SJe,{'
    end_str = 'm&&!d&&s.jsx(JDe,{'

    start_idx = code.find(start_str)
    end_idx = code.find(end_str)

    if start_idx != -1 and end_idx != -1:
        print(f"Found corrupted block from {start_idx} to {end_idx} in {target_file}")
        code = code[:start_idx] + clean_sje_block + code[end_idx:]
        with open(target_file, "w") as f:
            f.write(code)
    else:
        print(f"WARNING: Could not find markers in {target_file}: start_idx={start_idx}, end_idx={end_idx}")

print("Replacement complete.")
