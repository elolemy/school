import re

print("Applying ultimate routine sequence and isolated regulations fix...")

with open("assets/app-bundle.js", "r") as f:
    code = f.read()

# Helper replacement function for manual regulations trigger
manual_open_reg = "()=>{p(!1);is(!1);Js(!1);window.__morningRoutineStep=null;we(!0)}"

# 1. Update wXe (Tutorial) onClose
code = re.sub(
    r's\.jsx\(wXe,\{isOpen:fr,onClose:\(\)=>\{[^\}]+\},language:i\.settings\.language\}\)',
    's.jsx(wXe,{isOpen:fr,onClose:()=>{Js(!1);try{localStorage.setItem("school_tutorial_completed","true")}catch{}if(window.__morningRoutineStep==="tutorial"){window.__morningRoutineStep="story";is(!0)}else{window.__morningRoutineStep=null}},language:i.settings.language})',
    code
)

# 2. Update aZe (Story) onClose
code = re.sub(
    r's\.jsx\(aZe,\{isOpen:ms,onClose:\(\)=>\{[^\}]+\},currentDay:i\.currentDay',
    's.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1),l(pe=>({...pe,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));if(window.__morningRoutineStep==="story"){window.__morningRoutineStep="regulations";we(!0)}else{window.__morningRoutineStep=null}},currentDay:i.currentDay',
    code
)

# 3. Update CJe (Regulations) onClose
code = re.sub(
    r's\.jsx\(CJe,\{isOpen:de,onClose:\(\)=>\{[^\}]+\},language:i\.settings\.language,isDark:vi\}\)',
    's.jsx(CJe,{isOpen:de,onClose:()=>{we(!1);if(window.__morningRoutineStep==="regulations"){window.__morningRoutineStep=null;p(!0)}else{window.__morningRoutineStep=null}},language:i.settings.language,isDark:vi})',
    code
)

# 4. Update onStartGame and onStartMorningRoutine in SJe / Kat
code = re.sub(
    r'onStartGame:\(\)=>\{[^\}]+\}',
    'onStartGame:()=>{I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!1);is(!1);we(!1);window.__morningRoutineStep="tutorial";Js(!0);c("desk")}',
    code
)

code = re.sub(
    r'onStartMorningRoutine:\(\)=>\{[^\}]+\}',
    'onStartMorningRoutine:()=>{I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!1);is(!1);we(!1);window.__morningRoutineStep="tutorial";Js(!0);c("desk")}',
    code
)

# 5. Update all manual regulations open triggers to use manual_open_reg
code = code.replace('onOpenDailyRegulations:()=>{window.__morningRoutineStep=null;we(!0)}', f'onOpenDailyRegulations:{manual_open_reg}')
code = code.replace('onOpenDailyRegulations:()=>we(!0)', f'onOpenDailyRegulations:{manual_open_reg}')
code = code.replace('onOpenRulebook:()=>{window.__morningRoutineStep=null;we(!0)}', f'onOpenRulebook:{manual_open_reg}')
code = code.replace('onOpenRulebook:()=>we(!0)', f'onOpenRulebook:{manual_open_reg}')
code = code.replace('window.addEventListener("open-rulebook",()=>{window.__morningRoutineStep=null;we(!0)})', f'window.addEventListener("open-rulebook",{manual_open_reg})')
code = code.replace('window.addEventListener("open-rulebook",()=>we(!0))', f'window.addEventListener("open-rulebook",{manual_open_reg})')

# Desk quick bar buttons
code = code.replace('onClick:()=>we(!0)', f'onClick:{manual_open_reg}')

with open("assets/app-bundle.js", "w") as f:
    f.write(code)

print("Ultimate routine and isolated regulations fix applied successfully!")
