import re

print("Applying requested flow: Regulations before Story in morning routine, isolated quick bar regulations button, and deferred attendance/subject cutoffs to advanced days...")

with open("assets/app-bundle.js", "r") as f:
    code = f.read()

# 1. Update wXe (Tutorial) onClose: after tutorial comes REGULATIONS ("regulations")
code = re.sub(
    r's\.jsx\(wXe,\{isOpen:fr,onClose:\(\)=>\{[^\}]+\},language:i\.settings\.language\}\)',
    's.jsx(wXe,{isOpen:fr,onClose:()=>{Js(!1);try{localStorage.setItem("school_tutorial_completed","true")}catch{}if(window.__morningRoutineStep==="tutorial"){window.__morningRoutineStep="regulations";we(!0)}else{window.__morningRoutineStep=null}},language:i.settings.language})',
    code
)

# 2. Update CJe (Regulations) onClose: after regulations comes STORY ("story") if in morning routine
code = re.sub(
    r's\.jsx\(CJe,\{isOpen:de,onClose:\(\)=>\{[^\}]+\},language:i\.settings\.language,isDark:vi\}\)',
    's.jsx(CJe,{isOpen:de,onClose:()=>{we(!1);if(window.__morningRoutineStep==="regulations"){window.__morningRoutineStep="story";is(!0)}else{window.__morningRoutineStep=null}},language:i.settings.language,isDark:vi})',
    code
)

# 3. Update aZe (Story) onClose: after story comes DECISIONS (p(!0)) if in morning routine
code = re.sub(
    r's\.jsx\(aZe,\{isOpen:ms,onClose:\(\)=>\{[^\}]+\},currentDay:i\.currentDay',
    's.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1),l(pe=>({...pe,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));if(window.__morningRoutineStep==="story"){window.__morningRoutineStep=null;p(!0)}else{window.__morningRoutineStep=null}},currentDay:i.currentDay',
    code
)

# 4. Make sure top X button on CJe header ALWAYS cancels routine step and closes CJe
code = code.replace(
    's.jsx("button",{onClick:()=>{I.playStampAccept(),e()}',
    's.jsx("button",{onClick:()=>{I.playStampAccept();window.__morningRoutineStep=null;e()}'
)

# 5. Manual triggers for regulations (quick bar / desk buttons): MUST set window.__morningRoutineStep = null
manual_reg_handler = "()=>{p(!1);is(!1);Js(!1);window.__morningRoutineStep=null;we(!0)}"

code = code.replace('onOpenDailyRegulations:()=>{p(!1);is(!1);Js(!1);window.__morningRoutineStep=null;we(!0)}', f'onOpenDailyRegulations:{manual_reg_handler}')
code = code.replace('onOpenDailyRegulations:()=>we(!0)', f'onOpenDailyRegulations:{manual_reg_handler}')
code = code.replace('onOpenRulebook:()=>{p(!1);is(!1);Js(!1);window.__morningRoutineStep=null;we(!0)}', f'onOpenRulebook:{manual_reg_handler}')
code = code.replace('onOpenRulebook:()=>we(!0)', f'onOpenRulebook:{manual_reg_handler}')
code = code.replace('window.addEventListener("open-rulebook",()=>we(!0))', f'window.addEventListener("open-rulebook",{manual_reg_handler})')

# 6. Morning routine start button handler: start at tutorial ("tutorial")
code = re.sub(
    r'onStartGame:\(\)=>\{[^\}]+\}',
    'onStartGame:()=>{I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!1);is(!1);we(!1);window.__morningRoutineStep="tutorial";Js(!0);c("desk")}',
    code
)

code = re.sub(
    r'onStartMorningRoutine:\(\)=>\{[^\}]+\}',
    'onStartMorningRoutine:()=>{I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!1);is(!1);we(!1);window.__morningRoutineStep="tutorial";Js(!0);c("desk")}',
    code
)

# 7. Remove maxAllowedAbsencePct and requiredSubjectCutoffs from early days (Days 1-5) in Sxe dictionary
# Remove maxAllowedAbsencePct from Day 2 and Day 3
code = code.replace('maxAllowedAbsencePct:20,', '')
code = code.replace('maxAllowedAbsencePct:18,', '')

# Move requiredSubjectCutoffs in Day 4 to Day 8+
code = code.replace(
    'requiredSubjectCutoffs:[{subjectKey:"math",nameAr:"الرياضيات",nameEn:"Mathematics",minScore:80},{subjectKey:"science",nameAr:"العلوم والفيزياء",nameEn:"Science & Physics",minScore:80}],',
    ''
)

with open("assets/app-bundle.js", "w") as f:
    f.write(code)

print("Applied exact requested flow successfully!")
