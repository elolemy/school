import re
import subprocess

print("Implementing state-based guarded transition controller for morning routine...")

guard_initializer = '''window.__morningRoutineGuard = window.__morningRoutineGuard || {
  currentStep: null,
  completedSteps: new Set(),
  start: function() {
    this.currentStep = "tutorial";
    this.completedSteps.clear();
  },
  advanceFrom: function(fromStep) {
    if (this.currentStep !== fromStep) return null;
    this.completedSteps.add(fromStep);
    if (fromStep === "tutorial") {
      this.currentStep = "story";
      return "story";
    } else if (fromStep === "story") {
      this.currentStep = "regulations";
      return "regulations";
    } else if (fromStep === "regulations") {
      this.currentStep = "decisions";
      return "decisions";
    } else if (fromStep === "decisions") {
      this.currentStep = null;
      return "done";
    }
    return null;
  },
  reset: function() {
    this.currentStep = null;
    this.completedSteps.clear();
  }
};'''

start_handler = '()=>{window.__morningRoutineGuard.start();I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!1);is(!1);we(!1);Js(!0);c("desk")}'

for target_file in ["assets/app-bundle.js", "public/assets/app-bundle.js"]:
    print(f"Applying state-based guard in {target_file}...")
    with open(target_file, "r") as f:
        code = f.read()

    # Prepend guard initializer at file start if not present
    if "window.__morningRoutineGuard" not in code:
        code = guard_initializer + "\n" + code

    # 1. Update onStartGame & onStartMorningRoutine
    code = re.sub(
        r'onStartGame:\(\)=>\{[^\}]+\}',
        f'onStartGame:{start_handler}',
        code
    )

    code = re.sub(
        r'onStartMorningRoutine:\(\)=>\{[^\}]+\}',
        f'onStartMorningRoutine:{start_handler}',
        code
    )

    # 2. Update wXe (Instructions / Tutorial) onClose:
    code = re.sub(
        r's\.jsx\(wXe,\{isOpen:fr,onClose:\(\)=>\{[^\}]+\},language:i\.settings\.language\}\)',
        's.jsx(wXe,{isOpen:fr,onClose:()=>{Js(!1);try{localStorage.setItem("school_tutorial_completed","true")}catch{}const nextStep=window.__morningRoutineGuard.advanceFrom("tutorial");if(nextStep==="story"){p(!1);we(!1);is(!0)}},language:i.settings.language})',
        code
    )

    # 3. Update aZe (Today Story) onClose:
    code = re.sub(
        r's\.jsx\(aZe,\{isOpen:ms,onClose:\(\)=>\{[^\}]+\},currentDay:i\.currentDay',
        's.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1);l(pe=>({...pe,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));const nextStep=window.__morningRoutineGuard.advanceFrom("story");if(nextStep==="regulations"){p(!1);Js(!1);we(!0)}},currentDay:i.currentDay',
        code
    )

    # 4. Update CJe (Rulebook / Regulations) onClose:
    code = re.sub(
        r's\.jsx\(CJe,\{isOpen:de,onClose:\(\)=>\{[^\}]+\},language:i\.settings\.language,isDark:vi\}\)',
        's.jsx(CJe,{isOpen:de,onClose:()=>{we(!1);const nextStep=window.__morningRoutineGuard.advanceFrom("regulations");if(nextStep==="decisions"){Js(!1);is(!1);p(!0)}},language:i.settings.language,isDark:vi})',
        code
    )

    # 5. Update JDe onStartDay / onClose
    # When starting day from briefing, advance decisions step
    code = code.replace(
        'onStartDay:()=>{p(!1),I.playSchoolBell(),l(ae=>({...ae,isDayStarted:!0})),is(!0)}',
        'onStartDay:()=>{p(!1);window.__morningRoutineGuard.advanceFrom("decisions");I.playSchoolBell();l(ae=>({...ae,isDayStarted:!0}))}'
    )

    # 6. Quickbar Rulebook opener: reset guard so standalone rulebook open doesn\'t trigger routine chain
    manual_rulebook = '()=>{window.__morningRoutineGuard.reset();p(!1);is(!1);Js(!1);we(!0)}'
    code = code.replace('onOpenRulebook:()=>we(!0)', f'onOpenRulebook:{manual_rulebook}')
    code = code.replace('onOpenRulebook:()=>{window.__morningRoutineStep=null;we(!0)}', f'onOpenRulebook:{manual_rulebook}')

    with open(target_file, "w") as f:
        f.write(code)

    # Validate with node
    res = subprocess.run(["node", "--input-type=module", "-c"], input=code, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"SUCCESS: {target_file} passed syntax validation!")
    else:
        print(f"ERROR in {target_file}:\n{res.stderr}")
        exit(1)

print("State-based guarded morning routine successfully applied and validated!")
