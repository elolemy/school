import subprocess, os

print("Injecting Online Multiplayer Mode into app bundle...")

script_content = '''
var OnlineMultiplayerModal = function({ isOpen, onClose, gameState, onUpdateGameState, isArabic }) {
  if (!isOpen) return null;

  const [activeTab, setActiveTab] = v.useState("lobby"); // lobby, duel, chat, exchange, derby
  const [role, setRole] = v.useState(null); // "host", "guest"
  const [roomCode, setRoomCode] = v.useState("");
  const [inputCode, setInputCode] = v.useState("");
  const [connectionStatus, setConnectionStatus] = v.useState("idle"); // idle, waiting, connecting, connected
  const [copiedCode, setCopiedCode] = v.useState(false);
  const [copiedLink, setCopiedLink] = v.useState(false);

  // Opponent School Data
  const [opponent, setOpponent] = v.useState(null);

  // Crisis Duel State
  const [currentCrisis, setCurrentCrisis] = v.useState(null);
  const [myChoice, setMyChoice] = v.useState(null);
  const [opponentChoice, setOpponentChoice] = v.useState(null);
  const [score, setScore] = v.useState({ me: 0, opponent: 0 });
  const [duelRound, setDuelRound] = v.useState(1);

  // Chat State
  const [messages, setMessages] = v.useState([]);
  const [inputMessage, setInputMessage] = v.useState("");

  // Exchange State
  const [exchangeOffer, setExchangeOffer] = v.useState(null);
  const [exchangeStatus, setExchangeStatus] = v.useState(null);

  // Derby State
  const [derbyScore, setDerbyScore] = v.useState({ me: 0, opponent: 0 });
  const [derbyEvents, setDerbyEvents] = v.useState([]);
  const [derbyRunning, setDerbyRunning] = v.useState(false);

  // Channels ref
  const channelRef = v.useRef(null);
  const peerRef = v.useRef(null);
  const connRef = v.useRef(null);

  const mySchoolInfo = v.useMemo(() => ({
    schoolName: gameState?.settings?.schoolName || "مدرسة التميز النموذجية",
    principalName: gameState?.settings?.principalName || "حضرة الناظر",
    reputation: Math.round(gameState?.reputation || 70),
    budget: Math.round(gameState?.budget || 15000),
    studentExcellence: Math.round(gameState?.studentExcellence || 75),
    schoolLevel: gameState?.schoolLevel || "ابتدائي",
    currentDay: gameState?.currentDay || 1,
    teacherCount: gameState?.teachers?.length || 12,
    studentCount: (gameState?.distinguishedStudents?.length || 0) + 180,
    timestamp: Date.now()
  }), [gameState]);

  // Load PeerJS CDN if not already loaded
  v.useEffect(() => {
    if (typeof window !== "undefined" && !window.Peer && !window.__loadingPeerScript) {
      window.__loadingPeerScript = true;
      const script = document.createElement("script");
      script.src = "https://unpkg.com/peerjs@1.5.4/dist/peerjs.min.js";
      script.async = true;
      document.head.appendChild(script);
    }
  }, []);

  // Check URL params for room code
  v.useEffect(() => {
    if (typeof window !== "undefined") {
      const params = new URLSearchParams(window.location.search);
      const room = params.get("room") || params.get("code");
      if (room && !roomCode) {
        setInputCode(room.toUpperCase().trim());
      }
    }
  }, []);

  // Broadcast Message to all available channels
  const broadcast = v.useCallback((msg) => {
    const payload = { ...msg, sender: role, fromSchool: mySchoolInfo.schoolName, timestamp: Date.now() };

    // 1. BroadcastChannel
    if (channelRef.current) {
      try { channelRef.current.postMessage(payload); } catch(e) {}
    }

    // 2. LocalStorage Event (for instant multi-tab fallback)
    if (roomCode) {
      try {
        localStorage.setItem("school_multi_msg_" + roomCode, JSON.stringify(payload));
      } catch(e) {}
    }

    // 3. WebRTC DataChannel via PeerJS
    if (connRef.current && connRef.current.open) {
      try { connRef.current.send(payload); } catch(e) {}
    }
  }, [role, mySchoolInfo, roomCode]);

  // Handle incoming messages
  const handleIncoming = v.useCallback((data) => {
    if (!data || data.sender === role) return;

    if (data.type === "HANDSHAKE") {
      setOpponent(data.schoolInfo);
      setConnectionStatus("connected");
      setActiveTab("duel");
      try { I.playPaperRustle(); } catch(e) {}
      // Reply with our handshake if we are host or haven't confirmed
      if (data.needReply) {
        broadcast({ type: "HANDSHAKE", schoolInfo: mySchoolInfo, needReply: false });
      }
    } else if (data.type === "CHAT") {
      setMessages(prev => [...prev, { sender: data.fromSchool, text: data.text, time: new Date().toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" }), isMe: false }]);
      try { I.playClick(); } catch(e) {}
    } else if (data.type === "CRISIS_START") {
      setCurrentCrisis(data.crisis);
      setMyChoice(null);
      setOpponentChoice(null);
      setDuelRound(data.round);
      try { I.playPaperRustle(); } catch(e) {}
    } else if (data.type === "CRISIS_CHOICE") {
      setOpponentChoice(data.choiceIndex);
      try { I.playClick(); } catch(e) {}
    } else if (data.type === "EXCHANGE_PROPOSAL") {
      setExchangeOffer(data.offer);
      setExchangeStatus("pending");
      try { I.playPaperRustle(); } catch(e) {}
    } else if (data.type === "EXCHANGE_DECISION") {
      setExchangeStatus(data.approved ? "approved" : "rejected");
      if (data.approved) {
        try { I.playStampAccept(); } catch(e) {}
      } else {
        try { I.playStampReject(); } catch(e) {}
      }
    } else if (data.type === "DERBY_UPDATE") {
      setDerbyScore(data.score);
      setDerbyEvents(data.events);
      setDerbyRunning(data.running);
    }
  }, [role, mySchoolInfo, broadcast]);

  // Setup BroadcastChannel & Storage Listener when roomCode is active
  v.useEffect(() => {
    if (!roomCode) return;

    // BroadcastChannel
    let bc = null;
    try {
      bc = new BroadcastChannel("school_sim_room_" + roomCode);
      bc.onmessage = (e) => handleIncoming(e.data);
      channelRef.current = bc;
    } catch(e) {}

    // Storage Event Listener
    const onStorage = (e) => {
      if (e.key === "school_multi_msg_" + roomCode && e.newValue) {
        try {
          const parsed = JSON.parse(e.newValue);
          handleIncoming(parsed);
        } catch(err) {}
      }
    };
    window.addEventListener("storage", onStorage);

    // Setup WebRTC PeerJS
    if (typeof window !== "undefined" && window.Peer) {
      try {
        const peerId = (role === "host" ? "school-host-" : "school-guest-") + roomCode;
        const peer = new window.Peer(peerId, { debug: 1 });
        peerRef.current = peer;

        peer.on("open", () => {
          if (role === "guest") {
            const hostId = "school-host-" + roomCode;
            const conn = peer.connect(hostId);
            connRef.current = conn;
            conn.on("open", () => {
              conn.send({ type: "HANDSHAKE", schoolInfo: mySchoolInfo, needReply: true });
            });
            conn.on("data", handleIncoming);
          }
        });

        peer.on("connection", (conn) => {
          connRef.current = conn;
          conn.on("data", handleIncoming);
          conn.on("open", () => {
            conn.send({ type: "HANDSHAKE", schoolInfo: mySchoolInfo, needReply: false });
          });
        });
      } catch(e) {
        console.warn("PeerJS initialization warning:", e);
      }
    }

    return () => {
      if (bc) bc.close();
      window.removeEventListener("storage", onStorage);
      if (connRef.current) try { connRef.current.close(); } catch(e) {}
      if (peerRef.current) try { peerRef.current.destroy(); } catch(e) {}
    };
  }, [roomCode, role, handleIncoming, mySchoolInfo]);

  // Host creates room
  const handleCreateRoom = () => {
    const code = "SCH-" + Math.floor(1000 + Math.random() * 9000);
    setRoomCode(code);
    setRole("host");
    setConnectionStatus("waiting");
    try { I.playPaperRustle(); } catch(e) {}

    // Check if another tab exists after a short delay
    setTimeout(() => {
      if (channelRef.current) {
        channelRef.current.postMessage({ type: "HANDSHAKE", schoolInfo: mySchoolInfo, needReply: true });
      }
    }, 500);
  };

  // Guest joins room
  const handleJoinRoom = () => {
    const code = inputCode.trim().toUpperCase();
    if (!code) return;
    setRoomCode(code);
    setRole("guest");
    setConnectionStatus("connecting");
    try { I.playClick(); } catch(e) {}

    setTimeout(() => {
      broadcast({ type: "HANDSHAKE", schoolInfo: mySchoolInfo, needReply: true });
    }, 400);

    // Timeout fallback: if no opponent responds within 4 seconds in demo, simulate a distinguished rival school from Tanta
    setTimeout(() => {
      setOpponent(prev => {
        if (!prev) {
          const demoOpponent = {
            schoolName: "مدرسة طنطا الثانوية العسكرية بنين",
            principalName: "اللواء أ.ح / كمال الشناوي",
            reputation: 88,
            budget: 28500,
            studentExcellence: 82,
            schoolLevel: "ثانوي",
            currentDay: 24,
            teacherCount: 18,
            studentCount: 320,
            timestamp: Date.now(),
            isSimulated: true
          };
          setConnectionStatus("connected");
          setActiveTab("duel");
          return demoOpponent;
        }
        return prev;
      });
    }, 4500);
  };

  // Copy Code to Clipboard
  const handleCopyCode = () => {
    if (!roomCode) return;
    navigator.clipboard.writeText(roomCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
    try { I.playClick(); } catch(e) {}
  };

  // Copy Link to Clipboard
  const handleCopyLink = () => {
    if (!roomCode) return;
    const link = window.location.origin + window.location.pathname + "?room=" + roomCode;
    navigator.clipboard.writeText(link);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
    try { I.playClick(); } catch(e) {}
  };

  // Send Chat Message
  const handleSendMessage = () => {
    const text = inputMessage.trim();
    if (!text) return;
    const newMsg = {
      sender: mySchoolInfo.schoolName,
      text,
      time: new Date().toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" }),
      isMe: true
    };
    setMessages(prev => [...prev, newMsg]);
    setInputMessage("");
    broadcast({ type: "CHAT", text });
    try { I.playClick(); } catch(e) {}
  };

  // Pre-defined Telegrams
  const handleSendTelegram = (presetText) => {
    const newMsg = {
      sender: mySchoolInfo.schoolName,
      text: presetText,
      time: new Date().toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" }),
      isMe: true
    };
    setMessages(prev => [...prev, newMsg]);
    broadcast({ type: "CHAT", text: presetText });
    try { I.playPaperRustle(); } catch(e) {}
  };

  // Ministerial Crises Database for Duels
  const CRISES = [
    {
      id: "c1",
      title: "تفتيش وزاري مفاجئ على كثافة الفصول",
      desc: "لجنة وزارية مفاجئة دخلت بوابة المدرسة واكتشفت وصول كثافة بعض الفصول إلى 62 طالباً. المفتش يطالب بتقرير فوري!",
      options: [
        { text: "تطبيق نظام الفترتين الممتدة وتوزيع الحصص فوراً", score: 25, feedback: "قرار إداري حاسم أرضى الوزارة وخفف العبء!" },
        { text: "تحويل غرف الأنشطة وقاعة الموسيقى لفصول مؤقتة", score: 15, feedback: "حل سريع لكنه أثار حفيظة معلمي الأنشطة." },
        { text: "التمسك بالكثافة الحالية وطلب دعم مالي لبناء جناح جديد", score: 30, feedback: "شجاعة استثنائية أسفرت عن وعود بميزانية إضافية!" },
        { text: "تأجيل التقرير للأسبوع المقبل حتى انتهاء الشهر", score: -10, feedback: "تعنت أدى لتوجيه إنذار رسمي للمدرسة!" }
      ]
    },
    {
      id: "c2",
      title: "أزمة تسريب أسئلة اختبار الشهر",
      desc: "انتشرت صورة لنموذج امتحان اللغة العربية على مجموعات الواتساب قبل موعد اللجنة بساعة واحدة!",
      options: [
        { text: "سحب النموذج واستخدام النموذج البديل (ب) في خزانة الإدارة", score: 35, feedback: "تصرف مهني أنقذ هيبة المدرسة ونزاهة الاختبار!" },
        { text: "إلغاء الامتحان فوراً وإحالته لنهاية الفصل الدراسي", score: 10, feedback: "أربك جداول أولياء الأمور والطلاب." },
        { text: "تشكيل لجنة تحقيق سرية مع واضعي الامتحان وحظر الهواتف", score: 25, feedback: "إجراء انضباطي عادل كشف مصدر التسريب." },
        { text: "استكمال الامتحان بشكل طبيعي وتجاهل المنشورات", score: -20, feedback: "فضيحة تربوية تسببت في هجوم إعلامي حاد!" }
      ]
    },
    {
      id: "c3",
      title: "رعاية من شركة كبرى لتطوير الملاعب والمعامل",
      desc: "شركة استثمارية عرضت تبرعاً بقيمة 100,000 جنيه مقابل وضع لافتاتها الإعلانية داخل فناء المدرسة وأسوارها.",
      options: [
        { text: "قبول الرعاية وتوجيه 70% منها لمعامل الحاسب والعلوم", score: 30, feedback: "قفزة تكنولوجية هائلة للمدرسة دون إهدار للمال!" },
        { text: "الموافقة بشرط اقتصار الإعلانات على بوابة الأنشطة الرياضية", score: 25, feedback: "توازن ذكي بين المظهر التربوي والاستثمار المالي." },
        { text: "رفض العرض تجنباً لتحويل الصرح التعليمي لسوق تجاري", score: 15, feedback: "موقف مبدئي حظي باحترام مجلس الأمناء." },
        { text: "المطالبة بضعف المبلغ وتخصيصه لمكافآت الإدارة فقط", score: -15, feedback: "رفضت الشركة وفقدت المدرسة سمعتها الاستثمارية!" }
      ]
    }
  ];

  // Start new Crisis Round
  const handleStartCrisis = () => {
    const nextCrisis = CRISES[(duelRound - 1) % CRISES.length];
    setCurrentCrisis(nextCrisis);
    setMyChoice(null);
    setOpponentChoice(null);
    broadcast({ type: "CRISIS_START", crisis: nextCrisis, round: duelRound + 1 });
    try { I.playPaperRustle(); } catch(e) {}
  };

  // Choose Option in Crisis
  const handleSelectCrisisOption = (index) => {
    if (myChoice !== null) return;
    setMyChoice(index);
    try { I.playClick(); } catch(e) {}
    broadcast({ type: "CRISIS_CHOICE", choiceIndex: index });

    // If opponent is simulated, choose after 1.2s
    if (opponent?.isSimulated && opponentChoice === null) {
      setTimeout(() => {
        const oppPick = Math.floor(Math.random() * currentCrisis.options.length);
        setOpponentChoice(oppPick);
        try { I.playClick(); } catch(e) {}
      }, 1200);
    }
  };

  // Calculate scores when both choose
  v.useEffect(() => {
    if (myChoice !== null && opponentChoice !== null && currentCrisis) {
      const myPts = currentCrisis.options[myChoice]?.score || 0;
      const oppPts = currentCrisis.options[opponentChoice]?.score || 0;
      setScore(prev => ({ me: prev.me + myPts, opponent: prev.opponent + oppPts }));
    }
  }, [myChoice, opponentChoice, currentCrisis]);

  // Start Derby Match
  const handleStartDerby = () => {
    setDerbyRunning(true);
    setDerbyScore({ me: 0, opponent: 0 });
    setDerbyEvents([{ min: 1, text: "صافرة الحكم! انطلاق ديربي المدارس بين " + mySchoolInfo.schoolName + " و" + (opponent?.schoolName || "المنافس") }]);

    let mScore = 0;
    let oScore = 0;
    const events = [];

    const interval = setInterval(() => {
      const minute = Math.floor(10 + Math.random() * 80);
      const isMyGoal = Math.random() > 0.45;
      if (isMyGoal) {
        mScore++;
        events.push({ min: minute, text: "⚽ هدف رائع لصالح فريق " + mySchoolInfo.schoolName + " بعد جملة تكتيكية من طلاب القسم الثانوي!" });
        try { I.playPaperRustle(); } catch(e) {}
      } else {
        oScore++;
        events.push({ min: minute, text: "⚽ هدف مباغت لفريق " + (opponent?.schoolName || "المنافس") + " من ركلة حرة مباشرة!" });
        try { I.playClick(); } catch(e) {}
      }

      setDerbyScore({ me: mScore, opponent: oScore });
      setDerbyEvents([...events]);
      broadcast({ type: "DERBY_UPDATE", score: { me: mScore, opponent: oScore }, events, running: true });

      if (events.length >= 4) {
        clearInterval(interval);
        setDerbyRunning(false);
        events.push({ min: 90, text: "صافرة النهاية! نتيجة المباراة: " + mScore + " - " + oScore });
        setDerbyEvents([...events]);
        broadcast({ type: "DERBY_UPDATE", score: { me: mScore, opponent: oScore }, events, running: false });
      }
    }, 2000);
  };

  return s.jsx("div", {
    className: "fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md animate-fade-in",
    children: s.jsxs("div", {
      className: "relative w-full max-w-5xl bg-slate-900 border border-cyan-500/40 rounded-3xl shadow-2xl shadow-cyan-950/50 flex flex-col max-h-[92vh] overflow-hidden text-slate-100",
      children: [
        // Modal Header
        s.jsxs("div", {
          className: "p-4 sm:p-5 border-b border-slate-800 bg-slate-950/60 flex items-center justify-between shrink-0",
          children: [
            s.jsxs("div", {
              className: "flex items-center gap-3",
              children: [
                s.jsx("div", {
                  className: "w-11 h-11 rounded-2xl bg-gradient-to-br from-cyan-500 via-sky-600 to-blue-700 p-0.5 shadow-lg shadow-cyan-500/20 flex items-center justify-center text-xl",
                  children: "🌐"
                }),
                s.jsxs("div", {
                  children: [
                    s.jsxs("h3", {
                      className: "text-base sm:text-lg font-black text-white flex items-center gap-2",
                      children: [
                        s.jsx("span", { children: "طور الأونلاين وغرف التحدي المباشر" }),
                        connectionStatus === "connected" && s.jsx("span", { className: "text-xs font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1", children: [s.jsx("span", { className: "w-2 h-2 rounded-full bg-emerald-400 animate-pulse" }), "متصل P2P"] })
                      ]
                    }),
                    s.jsx("p", {
                      className: "text-xs text-slate-400",
                      children: roomCode ? "كود الغرفة: " + roomCode + (role === "host" ? " (المضيف)" : " (الضيف)") : "أنشئ غرفة أو أدخل كود الغرفة لتحدي مدير مدرسة أخرى"
                    })
                  ]
                })
              ]
            }),
            s.jsxs("div", {
              className: "flex items-center gap-2",
              children: [
                roomCode && s.jsx("button", {
                  onClick: handleCopyLink,
                  className: "px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-xs font-bold text-cyan-300 flex items-center gap-1 transition-all",
                  title: "نسخ رابط دعوة الغرفة",
                  children: copiedLink ? "تم نسخ الرابط! ✅" : "🔗 رابط الغرفة"
                }),
                s.jsx("button", {
                  onClick: onClose,
                  className: "w-9 h-9 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center text-lg font-bold transition-colors",
                  title: "إغلاق",
                  children: "✕"
                })
              ]
            })
          ]
        }),

        // Main Content Area
        connectionStatus !== "connected" ? (
          // Lobby View (Create or Join)
          s.jsxs("div", {
            className: "flex-1 overflow-y-auto p-4 sm:p-8 space-y-6",
            children: [
              s.jsxs("div", {
                className: "text-center max-w-xl mx-auto space-y-2",
                children: [
                  s.jsx("div", { className: "inline-block px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/20 text-xs font-bold mb-1", children: "⚡ تقنية الغرف المباشرة والمزامنة الفورية P2P" }),
                  s.jsx("h2", { className: "text-xl sm:text-2xl font-black text-white", children: "تحدَّ زميلك مدير المدرسة في منافسة مباشرة!" }),
                  s.jsx("p", { className: "text-xs sm:text-sm text-slate-400", children: "أنشئ غرفة وشارك كود الغرفة مع صديقك، أو الصق الكود المرسل إليك لتبدأ المناظرة الوزارية وسوق إعارة المعلمين فوراً." })
                ]
              }),

              s.jsxs("div", {
                className: "grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto pt-2",
                children: [
                  // Card 1: Create Room
                  s.jsxs("div", {
                    className: "p-6 rounded-3xl bg-slate-850/80 border border-cyan-500/30 shadow-xl flex flex-col justify-between space-y-4 hover:border-cyan-500/60 transition-all",
                    children: [
                      s.jsxs("div", {
                        className: "space-y-3",
                        children: [
                          s.jsxs("div", {
                            className: "flex items-center gap-3",
                            children: [
                              s.jsx("div", { className: "w-12 h-12 rounded-2xl bg-cyan-500/20 text-cyan-300 flex items-center justify-center text-2xl font-bold border border-cyan-500/30", children: "🏰" }),
                              s.jsxs("div", {
                                children: [
                                  s.jsx("h3", { className: "font-black text-lg text-white", children: "إنشاء غرفة جديدة (Host)" }),
                                  s.jsx("p", { className: "text-xs text-slate-400", children: "توليد كود رسمي لغرفة عمليات مدرستك ومشاركته" })
                                ]
                              })
                            ]
                          }),
                          !roomCode ? (
                            s.jsx("p", { className: "text-xs text-slate-300 leading-relaxed", children: "ستصبح أنت المضيف (Host)، وتتحكم في بدء جولات التحدي ومناظرات الأزمات الوزارية بين المدرستين." })
                          ) : (
                            s.jsxs("div", {
                              className: "p-4 bg-slate-900 rounded-2xl border border-cyan-500/40 text-center space-y-3",
                              children: [
                                s.jsx("div", { className: "text-xs text-slate-400 font-bold", children: "كود الغرفة الخاص بك:" }),
                                s.jsx("div", { className: "text-2xl sm:text-3xl font-black font-mono tracking-widest text-cyan-300 bg-cyan-950/40 py-2.5 rounded-xl border border-cyan-500/40 select-all", children: roomCode }),
                                s.jsxs("div", {
                                  className: "flex items-center justify-center gap-2",
                                  children: [
                                    s.jsx("button", {
                                      onClick: handleCopyCode,
                                      className: "px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-cyan-600/30 transition-all",
                                      children: copiedCode ? "تم النسخ! ✅" : "📋 نسخ الكود"
                                    }),
                                    s.jsx("button", {
                                      onClick: handleCopyLink,
                                      className: "px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center gap-1.5 border border-slate-700 transition-all",
                                      children: copiedLink ? "تم نسخ الرابط! ✅" : "🔗 نسخ الرابط"
                                    })
                                  ]
                                }),
                                s.jsxs("div", {
                                  className: "flex items-center justify-center gap-2 text-xs text-amber-400 font-bold animate-pulse pt-1",
                                  children: [
                                    s.jsx("span", { className: "w-2 h-2 rounded-full bg-amber-400" }),
                                    s.jsx("span", { children: "في انتظار انضمام مدرسة أخرى عبر هذا الكود... ⏳" })
                                  ]
                                })
                              ]
                            })
                          )
                        ]
                      }),
                      !roomCode && s.jsx("button", {
                        onClick: handleCreateRoom,
                        className: "w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-black text-sm shadow-lg shadow-cyan-600/30 transition-all active:scale-98 flex items-center justify-center gap-2",
                        children: [s.jsx("span", { children: "✨ إنشاء الغرفة وتوليد الكود" })]
                      })
                    ]
                  }),

                  // Card 2: Join Room
                  s.jsxs("div", {
                    className: "p-6 rounded-3xl bg-slate-850/80 border border-amber-500/30 shadow-xl flex flex-col justify-between space-y-4 hover:border-amber-500/60 transition-all",
                    children: [
                      s.jsxs("div", {
                        className: "space-y-3",
                        children: [
                          s.jsxs("div", {
                            className: "flex items-center gap-3",
                            children: [
                              s.jsx("div", { className: "w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-300 flex items-center justify-center text-2xl font-bold border border-amber-500/30", children: "🚀" }),
                              s.jsxs("div", {
                                children: [
                                  s.jsx("h3", { className: "font-black text-lg text-white", children: "الانضمام لغرفة (Join)" }),
                                  s.jsx("p", { className: "text-xs text-slate-400", children: "أدخل الكود المرسل من مدير المدرسة الأخرى" })
                                ]
                              })
                            ]
                          }),
                          s.jsx("p", { className: "text-xs text-slate-300 leading-relaxed", children: "الصق كود الغرفة المكون من أرقام وحروف لتتصل مباشرة بمدرسة زميلك وتبدأ المواجهة." }),
                          s.jsxs("div", {
                            className: "space-y-2 pt-1",
                            children: [
                              s.jsx("input", {
                                type: "text",
                                value: inputCode,
                                onChange: (e) => setInputCode(e.target.value.toUpperCase()),
                                placeholder: "مثال: SCH-4921",
                                className: "w-full p-3.5 rounded-xl bg-slate-900 border border-slate-700 text-center font-mono font-black text-lg text-amber-300 uppercase tracking-widest focus:border-amber-500 focus:outline-none focus:ring-2 focus:ring-amber-500/20 transition-all"
                              }),
                              connectionStatus === "connecting" && s.jsxs("div", {
                                className: "text-center text-xs text-amber-400 font-bold flex items-center justify-center gap-1.5 pt-1",
                                children: [
                                  s.jsx("span", { className: "w-2 h-2 rounded-full bg-amber-400 animate-ping" }),
                                  s.jsx("span", { children: "جارٍ الاتصال بالغرفة وتبادل بيانات المدرستين..." })
                                ]
                              })
                            ]
                          })
                        ]
                      }),
                      s.jsx("button", {
                        onClick: handleJoinRoom,
                        disabled: !inputCode.trim() || connectionStatus === "connecting",
                        className: "w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 disabled:opacity-50 text-slate-950 font-black text-sm shadow-lg shadow-amber-500/30 transition-all active:scale-98 flex items-center justify-center gap-2",
                        children: [s.jsx("span", { children: "⚡ اتصال ودخول الغرفة" })]
                      })
                    ]
                  })
                ]
              })
            ]
          })
        ) : (
          // Connected Arena View
          s.jsxs("div", {
            className: "flex-1 flex flex-col overflow-hidden",
            children: [
              // Top Matchup Bar
              s.jsxs("div", {
                className: "p-3 sm:p-4 bg-slate-950/70 border-b border-slate-800 grid grid-cols-1 md:grid-cols-3 gap-3 items-center shrink-0",
                children: [
                  // My School Card
                  s.jsxs("div", {
                    className: "flex items-center gap-2.5 p-2 rounded-xl bg-cyan-950/30 border border-cyan-500/30",
                    children: [
                      s.jsx("div", { className: "w-9 h-9 rounded-xl bg-cyan-600/30 text-cyan-300 border border-cyan-500/40 flex items-center justify-center text-lg shrink-0", children: "🏫" }),
                      s.jsxs("div", {
                        className: "min-w-0 flex-1",
                        children: [
                          s.jsx("div", { className: "text-xs font-black text-cyan-300 truncate", children: mySchoolInfo.schoolName }),
                          s.jsxs("div", { className: "text-[11px] text-slate-400 flex items-center gap-2", children: [s.jsxs("span", { children: ["السمعة: ", mySchoolInfo.reputation, "%"] }), s.jsxs("span", { children: ["الميزانية: ", mySchoolInfo.budget, " ج"] })] })
                        ]
                      })
                    ]
                  }),

                  // VS Badge & Room Info
                  s.jsxs("div", {
                    className: "text-center flex flex-col items-center justify-center",
                    children: [
                      s.jsx("div", { className: "px-3 py-0.5 rounded-full bg-gradient-to-r from-cyan-500 via-amber-500 to-rose-500 text-slate-950 font-black text-xs tracking-wider shadow-sm", children: "⚡ مواجهة المدارس VS ⚡" }),
                      s.jsxs("div", { className: "text-[10px] text-slate-400 mt-1 flex items-center gap-2 font-mono", children: [s.jsxs("span", { children: ["الغرفة: ", roomCode] }), s.jsx("span", { children: "•" }), s.jsxs("span", { className: "text-emerald-400 font-bold", children: ["النقاط: ", score.me, " - ", score.opponent] })] })
                    ]
                  }),

                  // Opponent School Card
                  s.jsxs("div", {
                    className: "flex items-center gap-2.5 p-2 rounded-xl bg-amber-950/30 border border-amber-500/30",
                    children: [
                      s.jsx("div", { className: "w-9 h-9 rounded-xl bg-amber-600/30 text-amber-300 border border-amber-500/40 flex items-center justify-center text-lg shrink-0", children: "🏛️" }),
                      s.jsxs("div", {
                        className: "min-w-0 flex-1",
                        children: [
                          s.jsx("div", { className: "text-xs font-black text-amber-300 truncate", children: opponent?.schoolName || "مدرسة المنافس" }),
                          s.jsxs("div", { className: "text-[11px] text-slate-400 flex items-center gap-2", children: [s.jsxs("span", { children: ["السمعة: ", opponent?.reputation || 70, "%"] }), s.jsxs("span", { children: ["الميزانية: ", opponent?.budget || 10000, " ج"] })] })
                        ]
                      })
                    ]
                  })
                ]
              }),

              // Navigation Tabs inside Arena
              s.jsxs("div", {
                className: "flex items-center gap-1 p-2 bg-slate-900 border-b border-slate-800 text-xs font-bold overflow-x-auto shrink-0",
                children: [
                  s.jsx("button", {
                    onClick: () => setActiveTab("duel"),
                    className: `px-3.5 py-2 rounded-xl transition-all flex items-center gap-1.5 whitespace-nowrap ${activeTab === "duel" ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40" : "text-slate-400 hover:text-white hover:bg-slate-800"}`,
                    children: [s.jsx("span", { children: "⚔️" }), s.jsx("span", { children: "مناظرة الأزمات الوزارية" })]
                  }),
                  s.jsx("button", {
                    onClick: () => setActiveTab("chat"),
                    className: `px-3.5 py-2 rounded-xl transition-all flex items-center gap-1.5 whitespace-nowrap ${activeTab === "chat" ? "bg-amber-500/20 text-amber-300 border border-amber-500/40" : "text-slate-400 hover:text-white hover:bg-slate-800"}`,
                    children: [s.jsx("span", { children: "💬" }), s.jsx("span", { children: "الخط الساخن والبرقيات" })]
                  }),
                  s.jsx("button", {
                    onClick: () => setActiveTab("derby"),
                    className: `px-3.5 py-2 rounded-xl transition-all flex items-center gap-1.5 whitespace-nowrap ${activeTab === "derby" ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40" : "text-slate-400 hover:text-white hover:bg-slate-800"}`,
                    children: [s.jsx("span", { children: "⚽" }), s.jsx("span", { children: "ديربي كرة القدم الودي" })]
                  }),
                  s.jsx("button", {
                    onClick: () => { setConnectionStatus("idle"); setRoomCode(""); setOpponent(null); },
                    className: "mr-auto px-3 py-1.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 text-xs font-bold transition-all",
                    children: "مغادرة الغرفة ✕"
                  })
                ]
              }),

              // Tab Contents
              s.jsx("div", {
                className: "flex-1 overflow-y-auto p-4 sm:p-6",
                children: activeTab === "duel" ? (
                  // Duel Tab
                  s.jsxs("div", {
                    className: "max-w-3xl mx-auto space-y-4",
                    children: [
                      !currentCrisis ? (
                        s.jsxs("div", {
                          className: "text-center py-10 space-y-4 bg-slate-850/60 rounded-3xl border border-slate-800 p-6",
                          children: [
                            s.jsx("div", { className: "text-4xl", children: "🎲" }),
                            s.jsx("h3", { className: "text-lg font-black text-white", children: "جاهزون لمناظرة الأزمات الوزارية؟" }),
                            s.jsx("p", { className: "text-xs text-slate-400 max-w-md mx-auto", children: "ستُعرض أزمة وزارية مشتركة لكلا المديرين في نفس اللحظة. كل مدير يختار قراره وتُحسب نقاط الحكمة الإدارية فوراً!" }),
                            s.jsx("button", {
                              onClick: handleStartCrisis,
                              className: "py-3 px-6 rounded-2xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-black text-sm shadow-lg shadow-cyan-600/30 transition-all",
                              children: "بدء جولة الأزمة الحالية ⚡"
                            })
                          ]
                        })
                      ) : (
                        s.jsxs("div", {
                          className: "space-y-4",
                          children: [
                            // Crisis Banner
                            s.jsxs("div", {
                              className: "p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-slate-850 to-slate-900 border border-cyan-500/30 shadow-lg space-y-2",
                              children: [
                                s.jsxs("div", {
                                  className: "flex items-center justify-between text-xs",
                                  children: [
                                    s.jsxs("span", { className: "font-black text-cyan-400 flex items-center gap-1.5", children: [s.jsx("span", { children: "📜" }), "أزمة وزارية رقم (", duelRound, ")"] }),
                                    s.jsx("span", { className: "px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold", children: "مطلوب قرار عاجل" })
                                  ]
                                }),
                                s.jsx("h4", { className: "text-base sm:text-lg font-black text-white", children: currentCrisis.title }),
                                s.jsx("p", { className: "text-xs text-slate-300 leading-relaxed", children: currentCrisis.desc })
                              ]
                            }),

                            // Choices
                            s.jsx("div", {
                              className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
                              children: currentCrisis.options.map((opt, idx) => {
                                const isPicked = myChoice === idx;
                                return s.jsxs("button", {
                                  key: idx,
                                  onClick: () => handleSelectCrisisOption(idx),
                                  disabled: myChoice !== null,
                                  className: `p-3.5 rounded-2xl border text-right transition-all flex flex-col justify-between gap-2 ${isPicked ? "bg-cyan-600/20 border-cyan-400 text-white shadow-md shadow-cyan-500/20 ring-1 ring-cyan-400" : myChoice !== null ? "opacity-50 bg-slate-900 border-slate-800 text-slate-400" : "bg-slate-850 hover:bg-slate-800 border-slate-750 text-slate-200 hover:border-cyan-500/50"}`,
                                  children: [
                                    s.jsxs("div", {
                                      className: "flex items-center gap-2",
                                      children: [
                                        s.jsx("span", { className: `w-6 h-6 rounded-lg flex items-center justify-center text-xs font-black shrink-0 ${isPicked ? "bg-cyan-500 text-slate-950" : "bg-slate-800 text-slate-400"}`, children: idx + 1 }),
                                        s.jsx("span", { className: "text-xs font-bold leading-snug", children: opt.text })
                                      ]
                                    }),
                                    isPicked && s.jsx("span", { className: "text-[10px] text-cyan-300 font-black", children: "تم اعتماد هذا القرار من جانبك ✅" })
                                  ]
                                });
                              })
                            }),

                            // Status & Reveal
                            s.jsxs("div", {
                              className: "p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-between text-xs",
                              children: [
                                s.jsxs("div", {
                                  className: "flex items-center gap-2",
                                  children: [
                                    s.jsx("span", { children: "حالة المنافس:" }),
                                    opponentChoice !== null ? (
                                      s.jsx("span", { className: "text-emerald-400 font-bold", children: "اعتمد قراره أيضاً! ✅" })
                                    ) : (
                                      s.jsx("span", { className: "text-amber-400 font-bold animate-pulse", children: "يفكر في قراره الإداري... ⏳" })
                                    )
                                  ]
                                }),
                                myChoice !== null && opponentChoice !== null && s.jsx("button", {
                                  onClick: handleStartCrisis,
                                  className: "px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-black text-xs shadow-md transition-all",
                                  children: "الجولة التالية ➡️"
                                })
                              ]
                            }),

                            // Feedback Reveal
                            myChoice !== null && opponentChoice !== null && s.jsxs("div", {
                              className: "p-4 rounded-2xl bg-emerald-950/20 border border-emerald-500/30 text-xs space-y-2 animate-fade-in",
                              children: [
                                s.jsxs("div", { className: "font-black text-emerald-400 flex items-center gap-1", children: [s.jsx("span", { children: "📊" }), "تقييم الوزارة للقرارات:"] }),
                                s.jsxs("div", { className: "text-slate-300", children: [s.jsx("span", { className: "font-bold text-cyan-300", children: "مدرستك: " }), currentCrisis.options[myChoice]?.feedback, " (+", currentCrisis.options[myChoice]?.score, " نقطة)"] }),
                                s.jsxs("div", { className: "text-slate-300", children: [s.jsx("span", { className: "font-bold text-amber-300", children: "المنافس: " }), currentCrisis.options[opponentChoice]?.feedback, " (+", currentCrisis.options[opponentChoice]?.score, " نقطة)"] })
                              ]
                            })
                          ]
                        })
                      )
                    ]
                  })
                ) : activeTab === "chat" ? (
                  // Chat Tab
                  s.jsxs("div", {
                    className: "max-w-2xl mx-auto flex flex-col h-[52vh] space-y-3",
                    children: [
                      // Quick Telegrams
                      s.jsxs("div", {
                        className: "flex items-center gap-1.5 overflow-x-auto pb-1 text-xs shrink-0",
                        children: [
                          s.jsx("button", { onClick: () => handleSendTelegram("📜 نرسل لسيادتكم برقية تهنئة رسمية بالتميز الأكاديمي والريادة!"), className: "px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 whitespace-nowrap", children: "برقية تهنئة 📜" }),
                          s.jsx("button", { onClick: () => handleSendTelegram("⚠️ تنبيه عاجل: وصلت أنباء عن تفتيش مفاجئ من مديرية التعليم للمدارس اليوم!"), className: "px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 whitespace-nowrap", children: "تنبيه تفتيش ⚠️" }),
                          s.jsx("button", { onClick: () => handleSendTelegram("🤝 نتشرف بدعوتكم لتوأمة تعليمية وتبادل خبرات بين معلمي المدرستين."), className: "px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 whitespace-nowrap", children: "عرض توأمة 🤝" }),
                          s.jsx("button", { onClick: () => handleSendTelegram("⚽ فريق مدرستنا جاهز تماماً لديربي كرة القدم، أين الملعب؟"), className: "px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 whitespace-nowrap", children: "تحدي كروي ⚽" })
                        ]
                      }),

                      // Messages List
                      s.jsx("div", {
                        className: "flex-1 overflow-y-auto p-3 bg-slate-950/60 rounded-2xl border border-slate-800 space-y-2.5",
                        children: messages.length === 0 ? (
                          s.jsx("div", { className: "text-center text-xs text-slate-500 py-12", children: "لا توجد برقيات بعد. ابدأ المراسلة مع المدير الآخر عبر الخط الساخن!" })
                        ) : (
                          messages.map((m, idx) => s.jsxs("div", {
                            key: idx,
                            className: `flex flex-col ${m.isMe ? "items-start" : "items-end"}`,
                            children: [
                              s.jsxs("div", {
                                className: `max-w-[80%] p-3 rounded-2xl text-xs leading-relaxed ${m.isMe ? "bg-cyan-600/20 border border-cyan-500/30 text-cyan-100 rounded-tr-none" : "bg-slate-800 border border-slate-700 text-slate-200 rounded-tl-none"}`,
                                children: [
                                  s.jsx("div", { className: `text-[10px] font-black mb-1 ${m.isMe ? "text-cyan-400" : "text-amber-400"}`, children: m.sender }),
                                  s.jsx("div", { children: m.text })
                                ]
                              }),
                              s.jsx("span", { className: "text-[9px] text-slate-500 mt-0.5 px-1", children: m.time })
                            ]
                          }))
                        )
                      }),

                      // Input Bar
                      s.jsxs("div", {
                        className: "flex items-center gap-2 shrink-0",
                        children: [
                          s.jsx("input", {
                            type: "text",
                            value: inputMessage,
                            onChange: (e) => setInputMessage(e.target.value),
                            onKeyDown: (e) => e.key === "Enter" && handleSendMessage(),
                            placeholder: "اكتب برقية رسمية أو رسالة للمدير الآخر...",
                            className: "flex-1 p-3 rounded-xl bg-slate-900 border border-slate-700 text-xs text-slate-100 focus:outline-none focus:border-cyan-500"
                          }),
                          s.jsx("button", {
                            onClick: handleSendMessage,
                            disabled: !inputMessage.trim(),
                            className: "px-4 py-3 rounded-xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white font-black text-xs shadow-md transition-all shrink-0",
                            children: "إرسال ✉️"
                          })
                        ]
                      })
                    ]
                  })
                ) : (
                  // Football Derby Tab
                  s.jsxs("div", {
                    className: "max-w-xl mx-auto text-center space-y-5",
                    children: [
                      s.jsxs("div", {
                        className: "p-6 rounded-3xl bg-slate-850/80 border border-emerald-500/30 shadow-xl space-y-4",
                        children: [
                          s.jsx("div", { className: "text-3xl", children: "⚽🏆" }),
                          s.jsx("h3", { className: "text-lg font-black text-white", children: "ديربي المدارس الودي لكرة القدم" }),
                          s.jsxs("div", {
                            className: "flex items-center justify-around py-3 bg-slate-900/90 rounded-2xl border border-slate-700",
                            children: [
                              s.jsxs("div", { className: "text-center", children: [s.jsx("div", { className: "text-xs font-black text-cyan-300 truncate max-w-[120px]", children: mySchoolInfo.schoolName }), s.jsx("div", { className: "text-3xl font-black text-white font-mono mt-1", children: derbyScore.me })] }),
                              s.jsx("div", { className: "text-xl font-black text-amber-400 font-mono", children: ":" }),
                              s.jsxs("div", { className: "text-center", children: [s.jsx("div", { className: "text-xs font-black text-amber-300 truncate max-w-[120px]", children: opponent?.schoolName || "المنافس" }), s.jsx("div", { className: "text-3xl font-black text-white font-mono mt-1", children: derbyScore.opponent })] })
                            ]
                          }),
                          !derbyRunning ? (
                            s.jsx("button", {
                              onClick: handleStartDerby,
                              className: "py-3 px-6 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs shadow-lg shadow-emerald-600/30 transition-all",
                              children: derbyEvents.length > 0 ? "إعادة المباراة ⚽" : "انطلاق صافرة المباراة ⚡"
                            })
                          ) : (
                            s.jsx("div", { className: "text-xs text-emerald-400 font-bold animate-pulse", children: "المباراة جارية حالياً على ملعب المدرسة... ⏳" })
                          )
                        ]
                      }),

                      // Derby Commentary Log
                      derbyEvents.length > 0 && s.jsx("div", {
                        className: "p-4 rounded-2xl bg-slate-950/70 border border-slate-800 text-right space-y-2 text-xs",
                        children: derbyEvents.map((ev, idx) => s.jsxs("div", {
                          key: idx,
                          className: "text-slate-300 flex items-start gap-2",
                          children: [
                            s.jsxs("span", { className: "font-mono font-bold text-emerald-400 shrink-0", children: ["'", ev.min] }),
                            s.jsx("span", { children: ev.text })
                          ]
                        }))
                      })
                    ]
                  })
                )
              })
            ]
          })
        )
      ]
    })
  });
};
'''

for path in ["public/assets/app-bundle.js", "assets/app-bundle.js"]:
    print(f"Injecting into {path}...")
    with open(path, "r") as f:
        c = f.read()

    # 1. Define OnlineMultiplayerModal
    if "var OnlineMultiplayerModal" not in c:
        # Prepend the component definition before Kat
        c = script_content + "\n" + c
        print("  Added OnlineMultiplayerModal component definition")

    # 2. Add state variable in Kat for modal
    old_state = 'useState(()=>localStorage.getItem("school_sim_active_user")),[me,Ae]=v.useState(!1),'
    new_state = 'useState(()=>localStorage.getItem("school_sim_active_user")),[me,Ae]=v.useState(!1),[isMultiplayerOpen,setIsMultiplayerOpen]=v.useState(()=>{if(typeof window!=="undefined"){const _p=new URLSearchParams(window.location.search);return _p.has("room")||_p.has("code")||_p.has("multiplayer");}return false;}),'
    if old_state in c:
        c = c.replace(old_state, new_state)
        print("  Added isMultiplayerOpen state to Kat")

    # 3. Add window event listener for open-online-multiplayer in Kat
    old_listener = 'window.addEventListener("open-eagle-stamp",rr)'
    new_listener = 'window.addEventListener("open-eagle-stamp",rr);const _hMulti=()=>setIsMultiplayerOpen(!0);window.addEventListener("open-online-multiplayer",_hMulti)'
    if old_listener in c:
        c = c.replace(old_listener, new_listener)
        print("  Added open-online-multiplayer window event listener")

    # 4. Render OnlineMultiplayerModal in Kat's JSX
    old_render = 's.jsx(pO,{state:i,isOpen:!0,onClose:()=>c("desk")'
    new_render = 's.jsx(OnlineMultiplayerModal,{isOpen:isMultiplayerOpen,onClose:()=>setIsMultiplayerOpen(!1),gameState:i,onUpdateGameState:l,isArabic:i.settings.language==="ar"}),s.jsx(pO,{state:i,isOpen:!0,onClose:()=>c("desk")'
    if old_render in c:
        c = c.replace(old_render, new_render)
        print("  Rendered OnlineMultiplayerModal in Kat")

    # 5. Add Online button to Top Navbar right before quick actions
    old_nav = 'children:[s.jsxs("button",{id:"btn-navbar-quick-actions"'
    new_nav = 'children:[s.jsxs("button",{id:"btn-navbar-online-multiplayer",onClick:()=>{try{window.dispatchEvent(new CustomEvent("open-online-multiplayer"))}catch(e){}},className:"px-3 py-1.5 rounded-xl bg-gradient-to-r from-cyan-600 via-sky-500 to-blue-600 text-white font-black text-xs hover:from-cyan-500 hover:to-blue-500 transition-all duration-300 shadow-md shadow-cyan-500/25 ring-1 ring-cyan-400/50 flex items-center gap-1.5 hover:scale-105 active:scale-95 shrink-0",title:de==="ar"?"طور الأونلاين وتحدي المدارس المباشر":"Online Multiplayer Mode",children:[s.jsx("span",{className:"text-sm",children:"🌐"}),s.jsx("span",{children:de==="ar"?"أونلاين":"Online"}),s.jsx("span",{className:"w-2 h-2 rounded-full bg-emerald-400 animate-ping"})]}),s.jsxs("button",{id:"btn-navbar-quick-actions"'
    if old_nav in c:
        c = c.replace(old_nav, new_nav)
        print("  Added Online button to top navbar")

    # 6. Add Online button to Start Menu (SJe) header buttons
    old_sje_header = 'title:E?"الإعدادات والمظهر":"Settings",children:s.jsx(w4,{className:"w-4 h-4"})})'
    new_sje_header = 'title:E?"الإعدادات والمظهر":"Settings",children:s.jsx(w4,{className:"w-4 h-4"})}),s.jsxs("button",{onClick:()=>{try{window.dispatchEvent(new CustomEvent("open-online-multiplayer"))}catch(e){}},className:"p-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 text-white border border-cyan-400/40 text-xs font-black transition-all shadow-md flex items-center gap-1.5 hover:scale-105 active:scale-95",title:E?"طور الأونلاين وغرف التحدي":"Online Multiplayer",children:[s.jsx("span",{children:"🌐"}),s.jsx("span",{className:"hidden sm:inline",children:E?"أونلاين":"Online"})]})'
    if old_sje_header in c:
        c = c.replace(old_sje_header, new_sje_header)
        print("  Added Online button to Start Menu header")

    with open(path, "w") as f:
        f.write(c)

    res = subprocess.run(["node", "-c", path], capture_output=True, text=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check!")
    else:
        print(f"  ERROR: {path} syntax error:\n{res.stderr[:400]}")
        exit(1)

print("Online Multiplayer Mode successfully injected and verified!")
