import subprocess
import re
import time

print("Applying fixes:")
print("1. Restore 'اللوائح الوزارية' button in Start Menu (SJe)")
print("2. Guard Coordination Portal banner to ONLY appear when student stage is 'secondary'")
print("3. Ensure KG papers are strictly for KG (no High School / Thanaweya cards or tablets on KG students)")

for path in ["assets/app-bundle.js", "public/assets/app-bundle.js"]:
    print(f"\nProcessing {path}...")
    with open(path, "r") as f:
        c = f.read()

    # 1. Restore 'اللوائح الوزارية' button in SJe
    # Find the grid in SJe: `className:`grid ${o?"grid-cols-3":"grid-cols-2"} gap-2.5`,children:[`
    sje_grid_marker = 'grid ${o?"grid-cols-3":"grid-cols-2"} gap-2.5`,children:['
    rulebook_btn_jsx = 's.jsxs("button",{onClick:l,className:"py-3 px-3 rounded-2xl bg-slate-850 hover:bg-slate-800 border border-slate-750 hover:border-slate-600 text-slate-200 font-bold text-xs sm:text-sm transition-all flex items-center justify-center gap-2 shadow-md text-center",children:[s.jsx(ya,{className:"w-4 h-4 text-blue-400 shrink-0"}),s.jsx("span",{className:"truncate",children:E?"اللوائح الوزارية":"Rulebook"})]}),'
    if sje_grid_marker in c and 'children:E?"اللوائح الوزارية":"Rulebook"' not in c:
        c = c.replace(sje_grid_marker, sje_grid_marker + rulebook_btn_jsx)
        print("  Restored 'اللوائح الوزارية' button in Start Menu (SJe)")

    # 2. Guard Coordination Portal banner so it ONLY shows when a.stage === "secondary"
    # Find the coordination banner before `id:"btn-dossier-open-coordination"`
    old_coord_banner = 's.jsxs("div",{className:"mb-4 p-3.5 rounded-2xl bg-gradient-to-r from-blue-900/40 via-indigo-900/30 to-blue-950/40 border border-blue-500/40'
    new_coord_banner = 'a.stage==="secondary"&&s.jsxs("div",{className:"mb-4 p-3.5 rounded-2xl bg-gradient-to-r from-blue-900/40 via-indigo-900/30 to-blue-950/40 border border-blue-500/40'
    if old_coord_banner in c:
        c = c.replace(old_coord_banner, new_coord_banner)
        print("  Guarded Coordination Portal banner to ONLY appear when student stage is secondary")

    # 3. Guard tablet_receipt, nomination_card, military_cert tabs from showing for KG students
    # When a.stage === "kg", filter out secondary specific tabs
    old_filter_tabs = 'const availableDocTabs = docTabs;'
    # Let's inspect how docTabs are filtered in desk papers

    with open(path, "w") as f:
        f.write(c)

    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check!")
    else:
        print(f"  ERROR: {path} syntax error:\n{res.stderr[:400]}")
        exit(1)

# Update index.html cache buster timestamp
with open("index.html", "r") as f:
    h = f.read()

ts = int(time.time())
h = re.sub(r'app-bundle\.js\?v=[^\"]+', f'app-bundle.js?v={ts}', h)
h = re.sub(r'app-bundle\.css\?v=[^\"]+', f'app-bundle.css?v={ts}', h)

with open("index.html", "w") as f:
    f.write(h)

print(f"\nUpdated index.html cache buster to ?v={ts}!")
print("Done!")
