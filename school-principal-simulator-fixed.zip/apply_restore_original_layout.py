import subprocess

print("Restoring original UI layout (headers, tickers, simulation bar) while keeping initial decision modal (JDe) disabled...")

# 1. Restore JS bundles
for path in ["public/assets/app-bundle.js", "assets/app-bundle.js"]:
    print(f"Restoring JS bundle at {path}...")
    with open(path, "r") as f:
        c = f.read()

    # Re-add fixed header -> sticky header
    c = c.replace(
        "return s.jsxs(\"header\",{className:`fixed top-0 left-0 right-0 z-40 border-b backdrop-blur-md",
        "return s.jsxs(\"header\",{className:`sticky top-0 z-40 border-b backdrop-blur-md"
    )

    # Re-add main padding -> pb-28
    c = c.replace(
        's.jsxs("main",{className:"pt-28 pb-28",',
        's.jsxs("main",{className:"pb-28",'
    )

    # Re-add Uat ticker in Kat wrapper if missing
    uat_target = 's.jsx(Uat,{isAr:i.settings.language==="ar"}),'
    if uat_target not in c:
        c = c.replace(
            'return a?s.jsxs("div",{className:`w-screen min-h-screen overflow-x-hidden overflow-y-scroll scroll-smooth flex flex-col transition-colors duration-300 ${vi?"bg-slate-950 text-slate-100":"bg-slate-100 text-slate-900"}`,children:[',
            'return a?s.jsxs("div",{className:`w-screen min-h-screen overflow-x-hidden overflow-y-scroll scroll-smooth flex flex-col transition-colors duration-300 ${vi?"bg-slate-950 text-slate-100":"bg-slate-100 text-slate-900"}`,children:[s.jsx(Uat,{isAr:i.settings.language==="ar"}),'
        )

    # Re-add ZSe in Kat wrapper if missing
    zse_target = 's.jsx(ZSe,{state:i,isAr:i.settings.language==="ar"}),'
    if zse_target not in c:
        c = c.replace(
            's.jsx(Uat,{isAr:i.settings.language==="ar"}),s.jsx(uDe,{state:i,',
            's.jsx(Uat,{isAr:i.settings.language==="ar"}),s.jsx(ZSe,{state:i,isAr:i.settings.language==="ar"}),s.jsx(uDe,{state:i,'
        )

    # Re-add red newsletter ticker in uDe if missing
    red_bar_target = 's.jsxs("div",{className:"w-full bg-red-700 dark:bg-red-950'
    if red_bar_target not in c:
        red_bar_code = 's.jsxs("div",{className:"w-full bg-red-700 dark:bg-red-950 border-b border-red-600/50 py-1 text-white text-[11px] font-bold flex items-center overflow-hidden h-7 select-none",children:[s.jsxs("div",{className:"px-3 bg-red-800 dark:bg-red-900 text-red-100 border-r border-red-600/40 font-black flex items-center gap-1.5 shrink-0 uppercase tracking-widest text-[10px] h-full shadow-md z-10",children:[s.jsx("span",{className:"w-2 h-2 rounded-full bg-white animate-ping"}),s.jsx("span",{children:de==="ar"?"📰 نشرة طنطا اليومية":"📰 Tanta Newsletter"})]}),s.jsxs("div",{className:"flex-1 overflow-hidden relative flex items-center h-full",children:[s.jsx("style",{children:`            @keyframes marquee {              0% { transform: translateX(${de==="ar"?"-100%":"100%"}); }              100% { transform: translateX(${de==="ar"?"100%":"-100%"}); }            }            .newsletter-marquee {              display: inline-block;              white-space: nowrap;              animation: marquee 25s linear infinite;            }            .newsletter-marquee:hover {              animation-play-state: paused;            }          `}),s.jsx("div",{className:"newsletter-marquee font-semibold text-white/90 text-[11px] absolute whitespace-nowrap",children:de==="ar"?Mt.ar:Mt.en})]})]}),'
        c = c.replace(
            'return s.jsxs("header",{className:`sticky top-0 z-40 border-b backdrop-blur-md transition-colors ${ge?"bg-slate-900/90 border-slate-800 text-slate-100":"bg-white/95 border-slate-200 text-slate-800 shadow-sm"}`,children:[',
            'return s.jsxs("header",{className:`sticky top-0 z-40 border-b backdrop-blur-md transition-colors ${ge?"bg-slate-900/90 border-slate-800 text-slate-100":"bg-white/95 border-slate-200 text-slate-800 shadow-sm"}`,children:[' + red_bar_code
        )

    # Re-add simulation prank buttons bar if replaced by null
    orig_sim_bar = """s.jsx("div",{className:"max-w-6xl mx-auto px-4 pt-3 flex items-center justify-between",children:i.currentDispute?s.jsxs("button",{onClick:()=>I.playPaperRustle(),className:"w-full p-3 rounded-2xl bg-gradient-to-r from-red-600 via-rose-600 to-amber-600 text-white font-black text-sm flex items-center justify-between shadow-lg shadow-red-900/30 animate-pulse border border-red-400/50",children:[s.jsxs("span",{className:"flex items-center gap-2",children:[s.jsx("span",{className:"w-3 h-3 rounded-full bg-white animate-ping"}),s.jsx("span",{children:i.settings.language==="ar"?`⚠️ حالة طارئة: ${i.currentDispute.title}`:`⚠️ Urgent Hearing: ${i.currentDispute.titleEn}`})]}),s.jsx("span",{className:"px-3 py-1 rounded-xl bg-slate-950/40 text-xs font-bold border border-white/20",children:i.settings.language==="ar"?"فتح جلسة التحقيق والبت الفوري":"Open Hearing Room"})]}):s.jsxs("div",{className:"w-full flex items-center justify-between",children:[s.jsx("button",{onClick:()=>Ks(!0),className:"text-xs font-bold opacity-75 hover:opacity-100 text-rose-400 hover:text-rose-300 flex items-center gap-1.5 transition-all",children:s.jsx("span",{children:i.settings.language==="ar"?"🤡 محاكاة مقلب متمرد (حبر مكتب / ممحاة)":"🤡 Simulate Prank Cleanup"})}),s.jsx("button",{onClick:oo,className:"text-xs font-bold opacity-75 hover:opacity-100 text-amber-500 hover:text-amber-400 flex items-center gap-1.5 transition-all",children:s.jsx("span",{children:i.settings.language==="ar"?"⚔️ محاكاة استدعاء نزاع/مشاجرة طارئة في الفناء":"⚔️ Simulate Emergency Courtyard Dispute"})})]})})"""

    if orig_sim_bar not in c:
        # replace null or dispute snippet with orig_sim_bar
        c = c.replace(
            'unreadCount:i.notifications.filter(ae=>!ae.read).length}),null,s.jsxs("main"',
            'unreadCount:i.notifications.filter(ae=>!ae.read).length}),' + orig_sim_bar + ',s.jsxs("main"'
        )
        c = c.replace(
            'unreadCount:i.notifications.filter(ae=>!ae.read).length}),i.currentDispute?s.jsx("div",{className:"max-w-6xl mx-auto px-4 pt-3 flex items-center justify-between",children:s.jsxs("button",{onClick:()=>I.playPaperRustle(),className:"w-full p-3 rounded-2xl bg-gradient-to-r from-red-600 via-rose-600 to-amber-600 text-white font-black text-sm flex items-center justify-between shadow-lg shadow-red-900/30 animate-pulse border border-red-400/50",children:[s.jsxs("span",{className:"flex items-center gap-2",children:[s.jsx("span",{className:"w-3 h-3 rounded-full bg-white animate-ping"}),s.jsx("span",{children:i.settings.language==="ar"?`⚠️ حالة طارئة: ${i.currentDispute.title}`:`⚠️ Urgent Hearing: ${i.currentDispute.titleEn}`})]}),s.jsx("span",{className:"px-3 py-1 rounded-xl bg-slate-950/40 text-xs font-bold border border-white/20",children:i.settings.language==="ar"?"فتح جلسة التحقيق والبت الفوري":"Open Hearing Room"})]})}):null,s.jsxs("main"',
            'unreadCount:i.notifications.filter(ae=>!ae.read).length}),' + orig_sim_bar + ',s.jsxs("main"'
        )

    # Make sure JDe is disabled: !1&&s.jsx(JDe,{
    if "s.jsx(JDe,{" in c and "!1&&s.jsx(JDe,{" not in c:
        c = c.replace("s.jsx(JDe,{", "!1&&s.jsx(JDe,{")

    with open(path, "w") as f:
        f.write(c)

    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check!")
    else:
        print(f"  ERROR: {path} syntax error:\n{res.stderr[:400]}")
        exit(1)

# 2. Clean up CSS additions
for css_path in ["public/assets/app-bundle.css", "assets/app-bundle.css"]:
    with open(css_path, "r") as f:
        css = f.read()

    css = css.replace(".newsletter-marquee,\ndiv[class*=\"bg-red-700\"] {\n  display: none !important;\n}", "")
    css = css.replace("\n.bg-rose-600\\/90,\n.max-w-6xl.mx-auto.px-4.pt-3 {\n  display: none !important;\n}", "")

    with open(css_path, "w") as f:
        f.write(css)
    print(f"Cleaned CSS at {css_path}")

print("Restoration complete!")
