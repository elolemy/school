import subprocess

print("Updating onOpenDailyRegulations and enhancing JDe with Day's Story and Instructions cards...")

for path in ["public/assets/app-bundle.js", "assets/app-bundle.js"]:
    print(f"Updating {path}...")
    with open(path, "r") as f:
        c = f.read()

    # 1. Replace onOpenDailyRegulations:()=>we(!0) with onOpenDailyRegulations:()=>p(!0)
    c = c.replace("onOpenDailyRegulations:()=>we(!0)", "onOpenDailyRegulations:()=>p(!0)")

    # 2. Add '✕' close button to JDe header
    header_orig = 's.jsxs("div",{className:"hidden sm:flex flex-col items-end text-right text-xs",children:[s.jsx("span",{className:"text-slate-400 font-bold",children:t.settings.schoolName}),s.jsxs("span",{className:"text-[10px] font-mono text-emerald-400 font-bold flex items-center gap-1",children:[s.jsx(ar,{className:"w-3 h-3"}),s.jsx("span",{children:i?"لائحة سارية وملزمة":"Active Directives"})]})]})]})'
    header_new = 's.jsxs("div",{className:"flex items-center gap-3",children:[s.jsxs("div",{className:"hidden sm:flex flex-col items-end text-right text-xs",children:[s.jsx("span",{className:"text-slate-400 font-bold",children:t.settings.schoolName}),s.jsxs("span",{className:"text-[10px] font-mono text-emerald-400 font-bold flex items-center gap-1",children:[s.jsx(ar,{className:"w-3 h-3"}),s.jsx("span",{children:i?"لائحة سارية وملزمة":"Active Directives"})]})]}),s.jsx("button",{type:"button",onClick:()=>r(!1),className:"p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors text-sm font-bold flex items-center justify-center w-8 h-8",title:i?"إغلاق":"Close",children:"✕"})]})]})'

    if header_orig in c:
        c = c.replace(header_orig, header_new)
        print("  Added '✕' close button to JDe header")
    else:
        print("  WARNING: header_orig not found in JDe")

    # 3. Enhance JDe with prominent Story and Instructions cards
    old_buttons = 's.jsxs("div",{className:"flex flex-wrap items-center justify-between gap-3 p-3 rounded-2xl bg-slate-950/80 border border-slate-800 mb-4 text-xs",children:[n&&s.jsxs("button",{type:"button",onClick:()=>{I.playRulebookOpen(),n()},className:"px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-600/30 to-amber-700/40 hover:from-amber-600/50 hover:to-amber-700/60 text-amber-200 border border-amber-500/40 font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all",children:[s.jsx(ya,{className:"w-4 h-4 text-amber-400"}),s.jsx("span",{children:i?`📖 قراءة وقائع ورواية اليوم (${t.currentDay})`:`📖 Read Today\'s Story (Day ${t.currentDay})`})]}),a&&s.jsxs("button",{type:"button",onClick:()=>{I.playPaperSlide(),a()},className:"px-2.5 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 font-bold text-[11px] flex items-center gap-1 transition-colors",children:[s.jsx(L$,{className:"w-3.5 h-3.5 text-amber-400"}),s.jsx("span",{children:i?"عرض التعليمات":"Instructions"})]})]})'

    new_cards = 's.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4 text-xs",children:[s.jsxs("div",{className:"p-3.5 rounded-2xl bg-gradient-to-br from-amber-950/40 to-slate-950 border-2 border-amber-500/40 flex flex-col justify-between gap-2.5 shadow-md",children:[s.jsxs("div",{children:[s.jsxs("div",{className:"text-xs font-black text-amber-400 flex items-center gap-1.5 mb-1",children:[s.jsx("span",{className:"text-base",children:"📖"}),s.jsx("span",{children:i?`قصة ووقائع اليوم (${t.currentDay}):`:`Today\'s Story & Events (Day ${t.currentDay}):`})]}),s.jsx("p",{className:"text-[11px] text-slate-300 leading-relaxed line-clamp-2",children:i?((t.currentEvent&&t.currentEvent.description)||`وقائع اليوم ${t.currentDay} من أصل 1000 يوم ومفاجآت الفناء المدرسي...`):((t.currentEvent&&t.currentEvent.descriptionEn)||`Events of Day ${t.currentDay} of 1000...`)})]}),n&&s.jsxs("button",{type:"button",onClick:()=>{I.playRulebookOpen(),n()},className:"w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs flex items-center justify-center gap-2 shadow-md active:scale-95 transition-all",children:[s.jsx("span",{children:"✨"}),s.jsx("span",{children:i?"فتح قصة ورواية اليوم بالكامل":"Read Full Day\'s Story"})]})]}),s.jsxs("div",{className:"p-3.5 rounded-2xl bg-gradient-to-br from-indigo-950/40 to-slate-950 border-2 border-indigo-500/40 flex flex-col justify-between gap-2.5 shadow-md",children:[s.jsxs("div",{children:[s.jsxs("div",{className:"text-xs font-black text-indigo-300 flex items-center gap-1.5 mb-1",children:[s.jsx("span",{className:"text-base",children:"📘"}),s.jsx("span",{children:i?"دليل وتعليمات إدارة المدرسة:":"Administrative Instructions Guide:"})]}),s.jsx("p",{className:"text-[11px] text-slate-300 leading-relaxed line-clamp-2",children:i?"شروط القبول، التدقيق الأكاديمي، كشف التزوير، وضوابط الزي والمظهر.":"Admission standards, academic auditing, forgery detection, and dress code."})]}),a&&s.jsxs("button",{type:"button",onClick:()=>{I.playPaperSlide(),a()},className:"w-full py-2.5 px-3 rounded-xl bg-indigo-600/50 hover:bg-indigo-600/70 border border-indigo-400/50 text-indigo-100 font-black text-xs flex items-center justify-center gap-2 shadow-md active:scale-95 transition-all",children:[s.jsx("span",{children:"📋"}),s.jsx("span",{children:i?"عرض دليل التعليمات الكامل":"View Instructions Guide"})]})]})]})'

    if old_buttons in c:
        c = c.replace(old_buttons, new_cards)
        print("  Replaced small buttons with prominent Story & Instructions cards in JDe")
    else:
        print("  WARNING: old_buttons not found in JDe")

    # 4. Update start button label to reflect day state
    old_btn_text = 's.jsx("span",{children:i?"📋 اعتماد اللائحة وبدء رواية وأحداث اليوم (5 طلاب)":"Approve Directives & Start Day\'s Story (5 Students)"})'
    new_btn_text = 's.jsx("span",{children:t.isDayStarted?(i?"✓ إغلاق والعودة لمهام المكتب":"✓ Close & Continue Desk Tasks"):(i?"📋 اعتماد اللائحة وبدء رواية وأحداث اليوم (5 طلاب)":"Approve Directives & Start Day\'s Story (5 Students)")})'

    if old_btn_text in c:
        c = c.replace(old_btn_text, new_btn_text)
        print("  Updated JDe start button label for isDayStarted")

    with open(path, "w") as f:
        f.write(c)

    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check!")
    else:
        print(f"  ERROR: {path} syntax error:\n{res.stderr[:400]}")
        exit(1)

print("Updates successfully completed!")
