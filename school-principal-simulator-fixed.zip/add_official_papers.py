import re
import time

with open("assets/app-bundle.js", "r") as f:
    code = f.read()

# 1. Update Eo definition to include all new official school papers
eo_start_idx = code.find('Eo=[{id:"all"')
eo_end_idx = code.find('tc=()=>{', eo_start_idx)
assert eo_start_idx != -1 and eo_end_idx != -1, "Could not locate Eo definition"

new_eo_items = '''Eo=[
  {id:"all",labelAr:(a==null?void 0:a.stage)==="university"||a!=null&&a.universityDossier?"📑 فرد جميع الأوراق والملف الجامعي":"📑 فرد جميع الأوراق",labelEn:"📑 Spread All Sheets",icon:"📑"},
  {id:"student_profile_card",labelAr:"🧑‍🎓 بطاقة الطالب الشخصية",labelEn:"🧑‍🎓 Student Profile",icon:"🧑‍🎓"},
  {id:"main",labelAr:"📄 استمارة التقديم",labelEn:"📄 Application Form",icon:"📄"},
  {id:"birth_cert",labelAr:"📜 شهادة الميلاد المميكنة",labelEn:"📜 Birth Certificate",icon:"📜"},
  {id:"receipt",labelAr:"🧾 إيصال المصروفات البنكي",labelEn:"🧾 Tuition Receipt",icon:"🧾"},
  {id:"vaccine",labelAr:"💉 كارت التطعيمات والصحة",labelEn:"💉 Health Card",icon:"💉"},
  {id:"transfer",labelAr:"🏫 إخلاء طرف المدرسة السابقة",labelEn:"🏫 School Transfer",icon:"🏫"},
  {id:"national_id",labelAr:"🪪 بطاقة ولي الأمر",labelEn:"🪪 Guardian ID",icon:"🪪"},
  {id:"student_national_id",labelAr:"🪪 بطاقة الطالب القومية",labelEn:"🪪 Student National ID",icon:"🪪"},
  {id:"highschool_transcript",labelAr:"📜 بيان درجات الإعدادية",labelEn:"📜 Prep Transcript",icon:"📜"},
  {id:"residence_proof",labelAr:"🏠 إثبات السكن والمرافق",labelEn:"🏠 Residence Proof",icon:"🏠"},
  {id:"parent_work_cert",labelAr:"🏢 جهة عمل ولي الأمر",labelEn:"🏢 Guardian Work Cert",icon:"🏢"},
  {id:"conduct_cert",labelAr:"🎖️ حسن السير والسلوك",labelEn:"🎖️ Conduct Cert",icon:"🎖️"},
  {id:"talents_cert",labelAr:"🏆 كشف المواهب والبطولات",labelEn:"🏆 Talents & Awards",icon:"🏆"},
  {id:"health_dossier",labelAr:"🩺 الفحص الإكلينيكي",labelEn:"🩺 Clinical Health",icon:"🩺"},
  {id:"medical_fitness",labelAr:"🏥 فحص النظر والسمع",labelEn:"🏥 Vision & Hearing",icon:"🏥"},
  {id:"tablet_receipt",labelAr:"📱 إقرار استلام التابلت",labelEn:"📱 Tablet Bond",icon:"📱"},
  {id:"social_worker_report",labelAr:"📋 تقرير الأخصائي الاجتماعي",labelEn:"📋 Social Worker Report",icon:"📋"},
  {id:"bus_subscription",labelAr:"🚌 تصريح الحافلة المدرسية",labelEn:"🚌 Bus Pass",icon:"🚌"},
  {id:"food_allergy_cert",labelAr:"🥗 بطاقة التغذية المدرسية",labelEn:"🥗 Nutrition Card",icon:"🥗"},
  {id:"language_proficiency",labelAr:"🌐 إفادة المستوى الرفيع للغات",labelEn:"🌐 Languages Cert",icon:"🌐"},
  {id:"iq_olympiad_cert",labelAr:"🧠 شهادة اختبار الذكاء IQ",labelEn:"🧠 Gifted IQ Cert",icon:"🧠"},
  {id:"scout_camp_permit",labelAr:"⛺ تصريح المعسكرات الكشفية",labelEn:"⛺ Scout Camp Permit",icon:"⛺"},
  {id:"arabic_calligraphy_diploma",labelAr:"✍️ إجازة الخط العربي",labelEn:"✍️ Calligraphy Diploma",icon:"✍️"},
  {id:"anti_bullying_pledge",labelAr:"🛡️ وثيقة مكافحة التنمر",labelEn:"🛡️ Anti-Bullying Charter",icon:"🛡️"},
  {id:"library_membership",labelAr:"📚 بطاقة عضوية المكتبة",labelEn:"📚 Library Card",icon:"📚"},
  {id:"robotics_badge",labelAr:"🤖 شهادة دوري الروبوتات والـAI",labelEn:"🤖 Robotics & AI",icon:"🤖"},
  {id:"chess_accreditation",labelAr:"♟️ بطاقة اتحاد الشطرنج",labelEn:"♟️ Chess Federation",icon:"♟️"},
  {id:"innovation_patent",labelAr:"💡 براءة الاختراع للناشئين",labelEn:"💡 Junior Patent",icon:"💡"},
  {id:"club_membership",labelAr:"⚽ كارنيه النادي الرياضي",labelEn:"⚽ Sports Club Card",icon:"⚽"},
  {id:"pledge",labelAr:"✍️ وثيقة تعهد ولي الأمر",labelEn:"✍️ Parent Pledge",icon:"✍️"},
  {id:"donation",labelAr:"🤝 استمارة تبرع الأنشطة",labelEn:"🤝 School Donation",icon:"🤝"},
  {id:"mother_id",labelAr:"👩 بطاقة الرقم القومي للأم",labelEn:"👩 Mother ID",icon:"👩"},
  {id:"sibling_cert",labelAr:"👶 شهادة قيد الأخوة",labelEn:"👶 Sibling Cert",icon:"👶"},
  {id:"pregnancy_cert",labelAr:"🩺 الحالة الصحية للأسرة",labelEn:"🩺 Family Health",icon:"🩺"},
  {id:"marriage_cert",labelAr:"💍 قيد الأسرة المميكن",labelEn:"💍 Family Registry",icon:"💍"},
  {id:"disciplinary_record",labelAr:"📝 تقويم السلوك والانضباط",labelEn:"📝 Behavior Log",icon:"📝"},
  {id:"visa_card",labelAr:"💳 فيزا ميزة للطالب",labelEn:"💳 Student Meeza Card",icon:"💳"},
  ...(a==null?void 0:a.gender)==="male"?[{id:"military_cert",labelAr:"🛡️ نموذج 2 جند (التجنيد)",labelEn:"🛡️ Military Service",icon:"🛡️"}]:[],
  ...bi?[{id:"nomination_card",labelAr:"🏛️ بطاقة الترشيح (3 ثانوي)",labelEn:"🏛️ Nomination Card",icon:"🏛️"}]:[],
  ...(a==null?void 0:a.stage)==="university"||a!=null&&a.universityDossier?[{id:"university_dossier",labelAr:"🏛️ بطاقة الترشيح والملف الجامعي",labelEn:"🏛️ University Dossier",icon:"🏛️"}]:[]
],'''

code = code[:eo_start_idx] + new_eo_items + code[eo_end_idx:]
print("1. Successfully replaced Eo definition!")

# 2. Add desk spread buttons in Zt === "all"
spread_needle = 'مرفقات الملف الرسمية المفروشة على المكتب (انقر لمعاينة أي ورقة كاملة):'
spread_idx = code.find(spread_needle)
assert spread_idx != -1, "Spread needle not found"

grid_start_idx = code.find('s.jsxs("div",{className:"grid grid-cols-2 sm:grid-cols-5 gap-2.5 text-xs",children:[', spread_idx)
assert grid_start_idx != -1, "Grid start not found"

closing_pattern = "]})]})}),Zt===\"birth_cert\""
pos_close = code.find(closing_pattern, grid_start_idx)
assert pos_close != -1, "Closing pattern not found"

extra_spread_cards = ''',
s.jsxs("button",{type:"button",onClick:()=>{I.playPageFlip(),Wt("tablet_receipt")},className:"p-3 bg-white/95 rounded-xl border-2 border-indigo-300 hover:border-indigo-500 shadow-sm text-right transition-all hover:scale-102 flex flex-col justify-between",children:[
  s.jsxs("div",{className:"flex items-center gap-1.5 text-indigo-700 font-bold mb-1",children:[s.jsx("span",{className:"text-base",children:"📱"}),s.jsx("span",{className:"text-[11px]",children:M==="ar"?"إقرار التابلت":"Tablet Bond"})]}),
  s.jsxs("div",{className:"text-[10px] text-slate-600 font-mono",children:["TAB-2026-",a.id.slice(-4)]}),
  s.jsx("div",{className:"mt-2 text-[10px] text-indigo-600 font-bold underline",children:M==="ar"?"عرض الورقة 🔍":"Open Sheet 🔍"})
]}),
s.jsxs("button",{type:"button",onClick:()=>{I.playPageFlip(),Wt("social_worker_report")},className:"p-3 bg-white/95 rounded-xl border-2 border-teal-300 hover:border-teal-500 shadow-sm text-right transition-all hover:scale-102 flex flex-col justify-between",children:[
  s.jsxs("div",{className:"flex items-center gap-1.5 text-teal-700 font-bold mb-1",children:[s.jsx("span",{className:"text-base",children:"📋"}),s.jsx("span",{className:"text-[11px]",children:M==="ar"?"الأخصائي الاجتماعي":"Social Worker"})]}),
  s.jsx("div",{className:"text-[10px] text-emerald-600 font-bold",children:M==="ar"?"توصية إيجابية":"Approved"}),
  s.jsx("div",{className:"mt-2 text-[10px] text-teal-600 font-bold underline",children:M==="ar"?"عرض الورقة 🔍":"Open Sheet 🔍"})
]}),
s.jsxs("button",{type:"button",onClick:()=>{I.playPageFlip(),Wt("bus_subscription")},className:"p-3 bg-white/95 rounded-xl border-2 border-yellow-300 hover:border-yellow-500 shadow-sm text-right transition-all hover:scale-102 flex flex-col justify-between",children:[
  s.jsxs("div",{className:"flex items-center gap-1.5 text-yellow-700 font-bold mb-1",children:[s.jsx("span",{className:"text-base",children:"🚌"}),s.jsx("span",{className:"text-[11px]",children:M==="ar"?"الحافلة المدرسية":"School Bus"})]}),
  s.jsx("div",{className:"text-[10px] text-slate-600 font-mono",children:M==="ar"?"خط (أ) النطاق المعتمد":"Route A"}),
  s.jsx("div",{className:"mt-2 text-[10px] text-yellow-600 font-bold underline",children:M==="ar"?"عرض الورقة 🔍":"Open Sheet 🔍"})
]}),
s.jsxs("button",{type:"button",onClick:()=>{I.playPageFlip(),Wt("food_allergy_cert")},className:"p-3 bg-white/95 rounded-xl border-2 border-lime-300 hover:border-lime-500 shadow-sm text-right transition-all hover:scale-102 flex flex-col justify-between",children:[
  s.jsxs("div",{className:"flex items-center gap-1.5 text-lime-700 font-bold mb-1",children:[s.jsx("span",{className:"text-base",children:"🥗"}),s.jsx("span",{className:"text-[11px]",children:M==="ar"?"التغذية والحساسية":"Nutrition"})]}),
  s.jsx("div",{className:"text-[10px] text-emerald-600 font-bold",children:M==="ar"?"لائق غذائياً":"Fit"}),
  s.jsx("div",{className:"mt-2 text-[10px] text-lime-600 font-bold underline",children:M==="ar"?"عرض الورقة 🔍":"Open Sheet 🔍"})
]}),
s.jsxs("button",{type:"button",onClick:()=>{I.playPageFlip(),Wt("language_proficiency")},className:"p-3 bg-white/95 rounded-xl border-2 border-sky-300 hover:border-sky-500 shadow-sm text-right transition-all hover:scale-102 flex flex-col justify-between",children:[
  s.jsxs("div",{className:"flex items-center gap-1.5 text-sky-700 font-bold mb-1",children:[s.jsx("span",{className:"text-base",children:"🌐"}),s.jsx("span",{className:"text-[11px]",children:M==="ar"?"اللغات الأجنبية":"Languages"})]}),
  s.jsx("div",{className:"text-[10px] text-sky-700 font-mono font-bold",children:"C1 Advanced (98%)"}),
  s.jsx("div",{className:"mt-2 text-[10px] text-sky-600 font-bold underline",children:M==="ar"?"عرض الورقة 🔍":"Open Sheet 🔍"})
]}),
s.jsxs("button",{type:"button",onClick:()=>{I.playPageFlip(),Wt("iq_olympiad_cert")},className:"p-3 bg-white/95 rounded-xl border-2 border-violet-300 hover:border-violet-500 shadow-sm text-right transition-all hover:scale-102 flex flex-col justify-between",children:[
  s.jsxs("div",{className:"flex items-center gap-1.5 text-violet-700 font-bold mb-1",children:[s.jsx("span",{className:"text-base",children:"🧠"}),s.jsx("span",{className:"text-[11px]",children:M==="ar"?"اختبار الذكاء (IQ)":"Mensa IQ"})]}),
  s.jsx("div",{className:"text-[10px] text-violet-700 font-bold",children:"IQ 142 (موهوب)"}),
  s.jsx("div",{className:"mt-2 text-[10px] text-violet-600 font-bold underline",children:M==="ar"?"عرض الورقة 🔍":"Open Sheet 🔍"})
]}),
s.jsxs("button",{type:"button",onClick:()=>{I.playPageFlip(),Wt("scout_camp_permit")},className:"p-3 bg-white/95 rounded-xl border-2 border-emerald-300 hover:border-emerald-500 shadow-sm text-right transition-all hover:scale-102 flex flex-col justify-between",children:[
  s.jsxs("div",{className:"flex items-center gap-1.5 text-emerald-700 font-bold mb-1",children:[s.jsx("span",{className:"text-base",children:"⛺"}),s.jsx("span",{className:"text-[11px]",children:M==="ar"?"المعسكرات الكشفية":"Scout Camp"})]}),
  s.jsx("div",{className:"text-[10px] text-emerald-600 font-bold",children:M==="ar"?"موافقة ولي الأمر ✓":"Approved ✓"}),
  s.jsx("div",{className:"mt-2 text-[10px] text-emerald-600 font-bold underline",children:M==="ar"?"عرض الورقة 🔍":"Open Sheet 🔍"})
]}),
s.jsxs("button",{type:"button",onClick:()=>{I.playPageFlip(),Wt("arabic_calligraphy_diploma")},className:"p-3 bg-white/95 rounded-xl border-2 border-amber-300 hover:border-amber-500 shadow-sm text-right transition-all hover:scale-102 flex flex-col justify-between",children:[
  s.jsxs("div",{className:"flex items-center gap-1.5 text-amber-700 font-bold mb-1",children:[s.jsx("span",{className:"text-base",children:"✍️"}),s.jsx("span",{className:"text-[11px]",children:M==="ar"?"إجازة الخط العربي":"Calligraphy"})]}),
  s.jsx("div",{className:"text-[10px] text-amber-600 font-bold",children:M==="ar"?"امتياز مع الشرف":"Honors"}),
  s.jsx("div",{className:"mt-2 text-[10px] text-amber-600 font-bold underline",children:M==="ar"?"عرض الورقة 🔍":"Open Sheet 🔍"})
]}),
s.jsxs("button",{type:"button",onClick:()=>{I.playPageFlip(),Wt("anti_bullying_pledge")},className:"p-3 bg-white/95 rounded-xl border-2 border-rose-300 hover:border-rose-500 shadow-sm text-right transition-all hover:scale-102 flex flex-col justify-between",children:[
  s.jsxs("div",{className:"flex items-center gap-1.5 text-rose-700 font-bold mb-1",children:[s.jsx("span",{className:"text-base",children:"🛡️"}),s.jsx("span",{className:"text-[11px]",children:M==="ar"?"ميثاق الأمان والتنمر":"Safety Charter"})]}),
  s.jsx("div",{className:"text-[10px] text-rose-600 font-bold",children:M==="ar"?"ميثاق معتمد ✓":"Signed ✓"}),
  s.jsx("div",{className:"mt-2 text-[10px] text-rose-600 font-bold underline",children:M==="ar"?"عرض الورقة 🔍":"Open Sheet 🔍"})
]}),
s.jsxs("button",{type:"button",onClick:()=>{I.playPageFlip(),Wt("library_membership")},className:"p-3 bg-white/95 rounded-xl border-2 border-stone-300 hover:border-stone-500 shadow-sm text-right transition-all hover:scale-102 flex flex-col justify-between",children:[
  s.jsxs("div",{className:"flex items-center gap-1.5 text-stone-700 font-bold mb-1",children:[s.jsx("span",{className:"text-base",children:"📚"}),s.jsx("span",{className:"text-[11px]",children:M==="ar"?"عضوية المكتبة":"Library Card"})]}),
  s.jsx("div",{className:"text-[10px] text-stone-600 font-mono",children:"Dewey: 962.05"}),
  s.jsx("div",{className:"mt-2 text-[10px] text-stone-600 font-bold underline",children:M==="ar"?"عرض الورقة 🔍":"Open Sheet 🔍"})
]}),
s.jsxs("button",{type:"button",onClick:()=>{I.playPageFlip(),Wt("robotics_badge")},className:"p-3 bg-white/95 rounded-xl border-2 border-cyan-300 hover:border-cyan-500 shadow-sm text-right transition-all hover:scale-102 flex flex-col justify-between",children:[
  s.jsxs("div",{className:"flex items-center gap-1.5 text-cyan-700 font-bold mb-1",children:[s.jsx("span",{className:"text-base",children:"🤖"}),s.jsx("span",{className:"text-[11px]",children:M==="ar"?"الروبوتات والـAI":"Robotics & AI"})]}),
  s.jsx("div",{className:"text-[10px] text-cyan-600 font-bold",children:M==="ar"?"ميدالية الابتكار 🥇":"Gold Medal 🥇"}),
  s.jsx("div",{className:"mt-2 text-[10px] text-cyan-600 font-bold underline",children:M==="ar"?"عرض الورقة 🔍":"Open Sheet 🔍"})
]}),
s.jsxs("button",{type:"button",onClick:()=>{I.playPageFlip(),Wt("chess_accreditation")},className:"p-3 bg-white/95 rounded-xl border-2 border-purple-300 hover:border-purple-500 shadow-sm text-right transition-all hover:scale-102 flex flex-col justify-between",children:[
  s.jsxs("div",{className:"flex items-center gap-1.5 text-purple-700 font-bold mb-1",children:[s.jsx("span",{className:"text-base",children:"♟️"}),s.jsx("span",{className:"text-[11px]",children:M==="ar"?"اتحاد الشطرنج":"Chess Rating"})]}),
  s.jsx("div",{className:"text-[10px] text-purple-600 font-bold",children:"ELO 1650 Master"}),
  s.jsx("div",{className:"mt-2 text-[10px] text-purple-600 font-bold underline",children:M==="ar"?"عرض الورقة 🔍":"Open Sheet 🔍"})
]})'''

code = code[:pos_close] + extra_spread_cards + code[pos_close:]
print("2. Successfully added desk spread cards in Zt === 'all'!")

# 3. Add full paper sheet renderers right after innovation_patent
pat_needle = 'Zt==="innovation_patent"'
pat_pos = code.find(pat_needle)
assert pat_pos != -1, "innovation_patent not found"

# Find closing of innovation_patent block
pat_end_needle = 'children:M==="ar"?"الرجوع للاستمارة الرئيسية ◄":"Back to Dossier ◄"})})]}),'
pat_end_pos = code.find(pat_end_needle, pat_pos)
assert pat_end_pos != -1, "innovation_patent end not found"

ins_point = pat_end_pos + len(pat_end_needle)

new_renderers = '''Zt==="tablet_receipt"&&s.jsx("div",{className:"space-y-4 animate-in fade-in duration-150",children:s.jsxs("div",{className:"bg-white/95 p-6 rounded-2xl border-2 border-indigo-400 shadow-md text-slate-900",children:[
  s.jsxs("div",{className:"border-b-2 border-slate-800 pb-3 mb-4 flex items-center justify-between",children:[
    s.jsxs("div",{children:[
      s.jsx("div",{className:"text-xs font-black text-indigo-800 uppercase tracking-wide",children:M==="ar"?"وزارة التربية والتعليم • الإدارة العامة للتطوير التكنولوجي":"Ministry of Education • Technological Development"}),
      s.jsxs("h3",{className:"text-2xl font-black text-slate-900 mt-1 flex items-center gap-2",children:[s.jsx("span",{className:"text-2xl",children:"📱"}),s.jsx("span",{children:M==="ar"?"إقرار استلام الجهاز اللوحي التعليمي (التابلت المدرسي)":"School Tablet Handover & Digital Insurance Bond"})]})
    ]}),
    s.jsxs("div",{className:"text-left font-mono",children:[s.jsx("div",{className:"text-xs text-slate-500",children:M==="ar"?"الرقم التسلسلي":"Serial Code"}),s.jsxs("div",{className:"text-base font-black text-indigo-700",children:["TAB-2026-",a.id.slice(-6).toUpperCase()]})]})
  ]}),
  s.jsxs("div",{className:"space-y-3 text-xs bg-slate-50 p-4 rounded-xl border border-slate-300",children:[
    s.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-3",children:[
      s.jsxs("div",{children:[s.jsx("span",{className:"font-bold text-slate-500 block",children:M==="ar"?"اسم الطالب المستلم:":"Student Name:"}),s.jsx("span",{className:"font-black text-slate-900 text-sm",children:M==="ar"?a.name:a.nameEn})]}),
      s.jsxs("div",{children:[s.jsx("span",{className:"font-bold text-slate-500 block",children:M==="ar"?"الرقم القومي للطالب:":"National ID:"}),s.jsx("span",{className:"font-mono font-bold text-slate-900",children:a.nationalId||"30805120104821"})]}),
      s.jsxs("div",{children:[s.jsx("span",{className:"font-bold text-slate-500 block",children:M==="ar"?"مواصفات الجهاز المعتمد:":"Tablet Specifications:"}),s.jsx("span",{className:"font-bold text-indigo-900",children:M==="ar"?"سامسونج جالاكسي إيه 9 التعليمي (شريحة 4G + حماية Knox MDM)":"Samsung Galaxy Tab A9 Education (4G SIM + Knox MDM)"})]}),
      s.jsxs("div",{children:[s.jsx("span",{className:"font-bold text-slate-500 block",children:M==="ar"?"حالة بوليصة التأمين الشامل:":"Insurance Status:"}),s.jsx("span",{className:"font-bold text-emerald-700",children:M==="ar"?"✓ مسدد بالكامل بموجب إيصال البريد المصري":"✓ Paid via Egyptian Post Voucher"})]})
    ]}),
    s.jsxs("div",{className:"p-3 bg-indigo-50/70 rounded-xl border border-indigo-200 mt-2",children:[
      s.jsx("span",{className:"font-bold text-indigo-900 block mb-1",children:M==="ar"?"تعهد ولي الأمر بالاستخدام الآمن:":"Guardian Digital Bond:"}),
      s.jsx("p",{className:"text-slate-700 leading-relaxed text-[11px]",children:M==="ar"?"أتعهد أنا ولي أمر الطالب بالحفاظ على التابلت المدرسي واستخدامه في منصات الوزارة التعليمية وبنك المعرفة والامتحانات الإلكترونية دون التلاعب بنظام الحماية.":"I undertake to maintain the tablet for educational platforms, Egyptian Knowledge Bank, and exams without tampering."})
    ]})
  ]}),
  s.jsxs("div",{className:"mt-5 pt-4 border-t-2 border-slate-300 flex items-center justify-between",children:[
    s.jsxs("div",{className:"flex items-center gap-3",children:[
      s.jsxs("div",{className:"w-16 h-16 rounded-full border-4 border-indigo-700 flex flex-col items-center justify-center p-1 text-indigo-800 text-center font-serif text-[8px] rotate-2 shadow-sm",children:[s.jsx("span",{className:"font-bold",children:M==="ar"?"التطوير التكنولوجي":"TECH DEPT"}),s.jsx("span",{className:"font-black text-[9px]",children:"CERTIFIED"})]}),
      s.jsx("div",{className:"text-xs text-slate-500",children:M==="ar"?"معتمد ومسجل بسيرفرات وزارة التربية والتعليم المركزية.":"Verified on Ministry of Education Central Cloud Servers."})
    ]}),
    s.jsx("button",{type:"button",onClick:()=>Wt("main"),className:"px-4 py-2 rounded-xl bg-slate-800 text-slate-200 text-xs font-bold hover:bg-slate-700",children:M==="ar"?"الرجوع للاستمارة الرئيسية ◄":"Back to Dossier ◄"})
  ]})
]})}),
Zt==="social_worker_report"&&s.jsx("div",{className:"space-y-4 animate-in fade-in duration-150",children:s.jsxs("div",{className:"bg-white/95 p-6 rounded-2xl border-2 border-teal-400 shadow-md text-slate-900",children:[
  s.jsxs("div",{className:"border-b-2 border-slate-800 pb-3 mb-4 flex items-center justify-between",children:[
    s.jsxs("div",{children:[
      s.jsx("div",{className:"text-xs font-black text-teal-800 uppercase tracking-wide",children:M==="ar"?"مكتب الخدمة الاجتماعية والإرشاد النفسي المدرسي":"School Social Work & Psychological Counseling Office"}),
      s.jsxs("h3",{className:"text-2xl font-black text-slate-900 mt-1 flex items-center gap-2",children:[s.jsx("span",{className:"text-2xl",children:"📋"}),s.jsx("span",{children:M==="ar"?"تقرير وبحث الحالة الاجتماعية والنفسية للطالب":"Comprehensive Social & Psychological Assessment Report"})]})
    ]}),
    s.jsxs("div",{className:"text-left font-mono",children:[s.jsx("div",{className:"text-xs text-slate-500",children:M==="ar"?"المؤشر الاجتماعي":"Social Score"}),s.jsx("div",{className:"text-base font-black text-teal-700",children:"96% (سليم ومتعاون)"})]})
  ]}),
  s.jsxs("div",{className:"space-y-3 text-xs bg-slate-50 p-4 rounded-xl border border-slate-300",children:[
    s.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-3",children:[
      s.jsxs("div",{children:[s.jsx("span",{className:"font-bold text-slate-500 block",children:M==="ar"?"الاستقرار الأسري والدعم المنزلي:":"Family & Home Support:"}),s.jsx("span",{className:"font-bold text-emerald-800",children:M==="ar"?"بيئة أسرية مشجعة ومتابعة دورية من ولي الأمر":"Supportive household with continuous parent engagement"})]}),
      s.jsxs("div",{children:[s.jsx("span",{className:"font-bold text-slate-500 block",children:M==="ar"?"التفاعل الاجتماعي مع الزملاء:":"Peer Interaction & Teamwork:"}),s.jsx("span",{className:"font-bold text-teal-800",children:M==="ar"?"طالب قيادي، متطوع في الإذاعة والأنشطة":"Leadership traits, active in morning broadcast"})]}),
      s.jsxs("div",{className:"sm:col-span-2 p-3 bg-teal-50 rounded-xl border border-teal-200",children:[
        s.jsx("span",{className:"font-bold text-teal-900 block mb-1",children:M==="ar"?"توصية الأخصائي الاجتماعي المعتمدة:":"Counselor Certified Recommendation:"}),
        s.jsx("p",{className:"text-slate-800 text-[11px] leading-relaxed",children:M==="ar"?"يوصى بقبول وقيد الطالب بصفوف المدرسة وتكليفه بمهام ريادة الفصل ومجلس اتحاد الطلاب لتميزه السلوكي والأخلاقي.":"Highly recommended for admission and student council committee leadership."})
      ]})
    ]})
  ]}),
  s.jsxs("div",{className:"mt-5 pt-4 border-t-2 border-slate-300 flex items-center justify-between",children:[
    s.jsxs("div",{className:"flex items-center gap-3",children:[
      s.jsxs("div",{className:"w-16 h-16 rounded-full border-4 border-teal-700 flex flex-col items-center justify-center p-1 text-teal-800 text-center font-serif text-[8px] -rotate-3 shadow-sm",children:[s.jsx("span",{className:"font-bold",children:M==="ar"?"الخدمة الاجتماعية":"COUNSELOR"}),s.jsx("span",{className:"font-black text-[9px]",children:"APPROVED"})]}),
      s.jsx("div",{className:"text-xs text-slate-500",children:M==="ar"?"مختوم من الأخصائي الاجتماعي الأول ومدير التربية الاجتماعية.":"Endorsed by Lead Social Worker & Guidance Supervisor."})
    ]}),
    s.jsx("button",{type:"button",onClick:()=>Wt("main"),className:"px-4 py-2 rounded-xl bg-slate-800 text-slate-200 text-xs font-bold hover:bg-slate-700",children:M==="ar"?"الرجوع للاستمارة الرئيسية ◄":"Back to Dossier ◄"})
  ]})
]})}),
Zt==="bus_subscription"&&s.jsx("div",{className:"space-y-4 animate-in fade-in duration-150",children:s.jsxs("div",{className:"bg-white/95 p-6 rounded-2xl border-2 border-yellow-400 shadow-md text-slate-900",children:[
  s.jsxs("div",{className:"border-b-2 border-slate-800 pb-3 mb-4 flex items-center justify-between",children:[
    s.jsxs("div",{children:[
      s.jsx("div",{className:"text-xs font-black text-yellow-800 uppercase tracking-wide",children:M==="ar"?"إدارة الحركة وخدمات النقل المدرسي المعتمد":"School Bus Fleet & Student Transportation Authority"}),
      s.jsxs("h3",{className:"text-2xl font-black text-slate-900 mt-1 flex items-center gap-2",children:[s.jsx("span",{className:"text-2xl",children:"🚌"}),s.jsx("span",{children:M==="ar"?"استمارة اشتراك وتصريح خطوط الحافلات المدرسية":"School Bus Subscription & Route Safety Pass"})]})
    ]}),
    s.jsxs("div",{className:"text-left font-mono",children:[s.jsx("div",{className:"text-xs text-slate-500",children:M==="ar"?"رقم الخط والمقعد":"Bus Route & Seat"}),s.jsx("div",{className:"text-base font-black text-yellow-700",children:"خط (أ) - مقعد 14"})]})
  ]}),
  s.jsxs("div",{className:"space-y-3 text-xs bg-slate-50 p-4 rounded-xl border border-slate-300",children:[
    s.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-3",children:[
      s.jsxs("div",{children:[s.jsx("span",{className:"font-bold text-slate-500 block",children:M==="ar"?"نقطة التجمع والالتقاء:":"Bus Stop & Pick-up Point:"}),s.jsx("span",{className:"font-bold text-slate-900",children:a.address||(M==="ar"?"شارع الجمهورية - المربع السكني":"Main Republic Ave")})]}),
      s.jsxs("div",{children:[s.jsx("span",{className:"font-bold text-slate-500 block",children:M==="ar"?"اسم مشرف الحافلة:":"Bus Supervisor:"}),s.jsx("span",{className:"font-bold text-slate-900",children:M==="ar"?"أ. كمال عبد الشافي (01099238102)":"Mr. Kamal Abdel Shafi"})]}),
      s.jsxs("div",{children:[s.jsx("span",{className:"font-bold text-slate-500 block",children:M==="ar"?"تأمين سلامة الركاب:":"Safety & GPS Tracking:"}),s.jsx("span",{className:"font-bold text-emerald-700",children:M==="ar"?"✓ حافلة مكيفة ومزودة بنظام GPS وكاميرات":"✓ AC Bus with Live GPS & CCTV"})]}),
      s.jsxs("div",{children:[s.jsx("span",{className:"font-bold text-slate-500 block",children:M==="ar"?"سداد الرسوم بالخزينة:":"Payment Voucher:"}),s.jsx("span",{className:"font-bold text-yellow-800 font-mono",children:"BUS-2026-PAID"})]})
    ]})
  ]}),
  s.jsxs("div",{className:"mt-5 pt-4 border-t-2 border-slate-300 flex items-center justify-between",children:[
    s.jsxs("div",{className:"flex items-center gap-3",children:[
      s.jsxs("div",{className:"w-16 h-16 rounded-full border-4 border-yellow-700 flex flex-col items-center justify-center p-1 text-yellow-800 text-center font-serif text-[8px] rotate-1 shadow-sm",children:[s.jsx("span",{className:"font-bold",children:M==="ar"?"النقل المدرسي":"TRANSPORT"}),s.jsx("span",{className:"font-black text-[9px]",children:"VERIFIED"})]}),
      s.jsx("div",{className:"text-xs text-slate-500",children:M==="ar"?"مختوم من قسم الحركة والصيانة والسلامة المرورية.":"Approved by School Fleet Transport & Safety Officer."})
    ]}),
    s.jsx("button",{type:"button",onClick:()=>Wt("main"),className:"px-4 py-2 rounded-xl bg-slate-800 text-slate-200 text-xs font-bold hover:bg-slate-700",children:M==="ar"?"الرجوع للاستمارة الرئيسية ◄":"Back to Dossier ◄"})
  ]})
]})}),
Zt==="food_allergy_cert"&&s.jsx("div",{className:"space-y-4 animate-in fade-in duration-150",children:s.jsxs("div",{className:"bg-white/95 p-6 rounded-2xl border-2 border-lime-400 shadow-md text-slate-900",children:[
  s.jsxs("div",{className:"border-b-2 border-slate-800 pb-3 mb-4 flex items-center justify-between",children:[
    s.jsxs("div",{children:[
      s.jsx("div",{className:"text-xs font-black text-lime-800 uppercase tracking-wide",children:M==="ar"?"المعهد القومي للتغذية • الإدارة العامة للتغذية المدرسية":"National Nutrition Institute • School Dietary Health"}),
      s.jsxs("h3",{className:"text-2xl font-black text-slate-900 mt-1 flex items-center gap-2",children:[s.jsx("span",{className:"text-2xl",children:"🥗"}),s.jsx("span",{children:M==="ar"?"بطاقة التغذية المدرسية وتصريح الوجبات والحساسية":"School Meal & Clinical Dietary Clearance Card"})]})
    ]}),
    s.jsxs("div",{className:"text-left font-mono",children:[s.jsx("div",{className:"text-xs text-slate-500",children:M==="ar"?"الحالة الغذائية":"Dietary Status"}),s.jsx("div",{className:"text-base font-black text-lime-700",children:M==="ar"?"لائق غذائياً":"Certified Fit"})]})
  ]}),
  s.jsxs("div",{className:"space-y-3 text-xs bg-slate-50 p-4 rounded-xl border border-slate-300",children:[
    s.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-3",children:[
      s.jsxs("div",{children:[s.jsx("span",{className:"font-bold text-slate-500 block",children:M==="ar"?"فحص حساسية الطعام والأطعمة المحظورة:":"Food Allergy Assessment:"}),s.jsx("span",{className:"font-bold text-emerald-800",children:M==="ar"?"خالٍ من حساسية اللاكتوز والجلوتين والمكسرات":"No documented gluten or nut allergies"})]}),
      s.jsxs("div",{children:[s.jsx("span",{className:"font-bold text-slate-500 block",children:M==="ar"?"نوع الوجبة المدرسية المقررة:":"Assigned School Meal Box:"}),s.jsx("span",{className:"font-bold text-slate-900",children:M==="ar"?"الوجبة الغذائية المتكاملة + عبوة لبن معقم":"Full Nutrition Meal Box + Fortified Milk"})]}),
      s.jsxs("div",{className:"sm:col-span-2 p-3 bg-lime-50 rounded-xl border border-lime-200",children:[
        s.jsx("span",{className:"font-bold text-lime-900 block mb-1",children:M==="ar"?"توصية خبير التغذية الإكلينيكية:":"Clinical Nutritionist Note:"}),
        s.jsx("p",{className:"text-slate-700 text-[11px]",children:M==="ar"?"الطالب يتمتع بكتلة جسمانية متناسقة (BMI سليم) ومصرح له باستلام الوجبة المدرسية اليومية فور بدء العام الدراسي.":"Student has optimal BMI index and is authorized for daily hot school lunch."})
      ]})
    ]})
  ]}),
  s.jsxs("div",{className:"mt-5 pt-4 border-t-2 border-slate-300 flex items-center justify-between",children:[
    s.jsxs("div",{className:"flex items-center gap-3",children:[
      s.jsxs("div",{className:"w-16 h-16 rounded-full border-4 border-lime-700 flex flex-col items-center justify-center p-1 text-lime-800 text-center font-serif text-[8px] -rotate-2 shadow-sm",children:[s.jsx("span",{className:"font-bold",children:M==="ar"?"التغذية المدرسية":"NUTRITION"}),s.jsx("span",{className:"font-black text-[9px]",children:"PASSED"})]}),
      s.jsx("div",{className:"text-xs text-slate-500",children:M==="ar"?"معتمد من اللجنة الطبية المشتركة للتغذية المدرسية.":"Endorsed by School Nutrition & Health Inspector."})
    ]}),
    s.jsx("button",{type:"button",onClick:()=>Wt("main"),className:"px-4 py-2 rounded-xl bg-slate-800 text-slate-200 text-xs font-bold hover:bg-slate-700",children:M==="ar"?"الرجوع للاستمارة الرئيسية ◄":"Back to Dossier ◄"})
  ]})
]})}),
Zt==="language_proficiency"&&s.jsx("div",{className:"space-y-4 animate-in fade-in duration-150",children:s.jsxs("div",{className:"bg-white/95 p-6 rounded-2xl border-2 border-sky-400 shadow-md text-slate-900",children:[
  s.jsxs("div",{className:"border-b-2 border-slate-800 pb-3 mb-4 flex items-center justify-between",children:[
    s.jsxs("div",{children:[
      s.jsx("div",{className:"text-xs font-black text-sky-800 uppercase tracking-wide",children:M==="ar"?"الإدارة العامة للمدارس الرسمية للغات والتعليم الدولي":"Directorate of Official Language Schools & Bilingual Education"}),
      s.jsxs("h3",{className:"text-2xl font-black text-slate-900 mt-1 flex items-center gap-2",children:[s.jsx("span",{className:"text-2xl",children:"🌐"}),s.jsx("span",{children:M==="ar"?"إفادة المستوى الرفيع للغات الأجنبية والترجمة المعتمدة":"Advanced Foreign Languages & Dual Language Certificate"})]})
    ]}),
    s.jsxs("div",{className:"text-left font-mono",children:[s.jsx("div",{className:"text-xs text-slate-500",children:M==="ar"?"مستوى الكفاءة (CEFR)":"Proficiency"}),s.jsx("div",{className:"text-base font-black text-sky-700",children:"C1 Advanced (98%)"})]})
  ]}),
  s.jsxs("div",{className:"space-y-3 text-xs bg-slate-50 p-4 rounded-xl border border-slate-300",children:[
    s.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-3",children:[
      s.jsxs("div",{children:[s.jsx("span",{className:"font-bold text-slate-500 block",children:M==="ar"?"اللغة الأجنبية الأولى:":"First Foreign Language:"}),s.jsx("span",{className:"font-bold text-sky-900",children:M==="ar"?"الإنجليزية المتقدمة (Advanced English) - 98/100":"Advanced English (98/100)"})]}),
      s.jsxs("div",{children:[s.jsx("span",{className:"font-bold text-slate-500 block",children:M==="ar"?"اللغة الأجنبية الثانية:":"Second Foreign Language:"}),s.jsx("span",{className:"font-bold text-sky-900",children:M==="ar"?"الفرنسية / الألمانية (Français / Deutsch) - 95/100":"French / German (95/100)"})]}),
      s.jsxs("div",{className:"sm:col-span-2 p-3 bg-sky-50 rounded-xl border border-sky-200",children:[
        s.jsx("span",{className:"font-bold text-sky-900 block mb-1",children:M==="ar"?"نتيجة اختبار المحادثة والطلاقة الشفهية:":"Oral Fluency & Listening Assessment:"}),
        s.jsx("p",{className:"text-slate-800 text-[11px]",children:M==="ar"?"اجتاز الطالب المقابلة اللغوية بدرجة امتياز ومؤهل للدراسة بأقسام اللغات والعلوم التجريبية بدون اختبار تأهيلي.":"Student passed bilingual fluency interview with distinction, exempt from preparatory language tests."})
      ]})
    ]})
  ]}),
  s.jsxs("div",{className:"mt-5 pt-4 border-t-2 border-slate-300 flex items-center justify-between",children:[
    s.jsxs("div",{className:"flex items-center gap-3",children:[
      s.jsxs("div",{className:"w-16 h-16 rounded-full border-4 border-sky-700 flex flex-col items-center justify-center p-1 text-sky-800 text-center font-serif text-[8px] rotate-2 shadow-sm",children:[s.jsx("span",{className:"font-bold",children:M==="ar"?"توجيه اللغات":"LANGUAGES"}),s.jsx("span",{className:"font-black text-[9px]",children:"CERTIFIED"})]}),
      s.jsx("div",{className:"text-xs text-slate-500",children:M==="ar"?"معتمد وموثق من الموجه العام للغات الأجنبية.":"Certified by Senior Foreign Language Inspector."})
    ]}),
    s.jsx("button",{type:"button",onClick:()=>Wt("main"),className:"px-4 py-2 rounded-xl bg-slate-800 text-slate-200 text-xs font-bold hover:bg-slate-700",children:M==="ar"?"الرجوع للاستمارة الرئيسية ◄":"Back to Dossier ◄"})
  ]})
]})}),
Zt==="iq_olympiad_cert"&&s.jsx("div",{className:"space-y-4 animate-in fade-in duration-150",children:s.jsxs("div",{className:"bg-white/95 p-6 rounded-2xl border-2 border-violet-400 shadow-md text-slate-900",children:[
  s.jsxs("div",{className:"border-b-2 border-slate-800 pb-3 mb-4 flex items-center justify-between",children:[
    s.jsxs("div",{children:[
      s.jsx("div",{className:"text-xs font-black text-violet-800 uppercase tracking-wide",children:M==="ar"?"المركز القومي لرعاية الموهوبين والمتفوقين وأولمبياد العلوم":"National Center for Gifted Talents & Science Olympiad"}),
      s.jsxs("h3",{className:"text-2xl font-black text-slate-900 mt-1 flex items-center gap-2",children:[s.jsx("span",{className:"text-2xl",children:"🧠"}),s.jsx("span",{children:M==="ar"?"شهادة اجتياز اختبار الذكاء (IQ) وأولمبياد النوابغ":"Mensa IQ Assessment & Science Olympiad Diploma"})]})
    ]}),
    s.jsxs("div",{className:"text-left font-mono",children:[s.jsx("div",{className:"text-xs text-slate-500",children:M==="ar"?"درجة مقياس الذكاء":"Mensa IQ Score"}),s.jsx("div",{className:"text-base font-black text-violet-700",children:"IQ 142 (نابغة)"})]})
  ]}),
  s.jsxs("div",{className:"space-y-3 text-xs bg-slate-50 p-4 rounded-xl border border-slate-300",children:[
    s.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-3",children:[
      s.jsxs("div",{children:[s.jsx("span",{className:"font-bold text-slate-500 block",children:M==="ar"?"تصنيف الذكاء والقدرات العقلية:":"Cognitive Capability Tier:"}),s.jsx("span",{className:"font-bold text-violet-900",children:M==="ar"?"فائق الذكاء والتفكير المنطقي والرياضي (Top 1%)":"Superior Analytical & Mathematical Logic (Top 1%)"})]}),
      s.jsxs("div",{children:[s.jsx("span",{className:"font-bold text-slate-500 block",children:M==="ar"?"الميدالية الأولمبية المحققة:":"Olympiad Achievement:"}),s.jsx("span",{className:"font-bold text-amber-600",children:M==="ar"?"🥇 الميدالية الذهبية في أولمبياد الرياضيات":"🥇 Gold Medal in National Math Olympiad"})]}),
      s.jsxs("div",{className:"sm:col-span-2 p-3 bg-violet-50 rounded-xl border border-violet-200",children:[
        s.jsx("span",{className:"font-bold text-violet-900 block mb-1",children:M==="ar"?"قرار لجنة رعاية المتفوقين:":"Gifted Admission Decree:"}),
        s.jsx("p",{className:"text-slate-800 text-[11px]",children:M==="ar"?"يمنح الطالب مقعداً شرفياً بمسار النوابغ مع منحة كاملة لحضور ورش الفيزياء والفلك المتقدمة.":"Student is granted honorary placement in the Advanced Genius Track."})
      ]})
    ]})
  ]}),
  s.jsxs("div",{className:"mt-5 pt-4 border-t-2 border-slate-300 flex items-center justify-between",children:[
    s.jsxs("div",{className:"flex items-center gap-3",children:[
      s.jsxs("div",{className:"w-16 h-16 rounded-full border-4 border-violet-700 flex flex-col items-center justify-center p-1 text-violet-800 text-center font-serif text-[8px] -rotate-3 shadow-sm",children:[s.jsx("span",{className:"font-bold",children:M==="ar"?"رعاية النوابغ":"GIFTED"}),s.jsx("span",{className:"font-black text-[9px]",children:"HONORS"})]}),
      s.jsx("div",{className:"text-xs text-slate-500",children:M==="ar"?"موثق من المركز القومي للامتحانات والتقويم التربوي.":"Certified by National Center for Educational Evaluation."})
    ]}),
    s.jsx("button",{type:"button",onClick:()=>Wt("main"),className:"px-4 py-2 rounded-xl bg-slate-800 text-slate-200 text-xs font-bold hover:bg-slate-700",children:M==="ar"?"الرجوع للاستمارة الرئيسية ◄":"Back to Dossier ◄"})
  ]})
]})}),
Zt==="scout_camp_permit"&&s.jsx("div",{className:"space-y-4 animate-in fade-in duration-150",children:s.jsxs("div",{className:"bg-white/95 p-6 rounded-2xl border-2 border-emerald-400 shadow-md text-slate-900",children:[
  s.jsxs("div",{className:"border-b-2 border-slate-800 pb-3 mb-4 flex items-center justify-between",children:[
    s.jsxs("div",{children:[
      s.jsx("div",{className:"text-xs font-black text-emerald-800 uppercase tracking-wide",children:M==="ar"?"الاتحاد العام للكشافة والمرشدات • المعسكرات والرحلات المدرسية":"General Scout & Girl Guide Federation • Camp Directorate"}),
      s.jsxs("h3",{className:"text-2xl font-black text-slate-900 mt-1 flex items-center gap-2",children:[s.jsx("span",{className:"text-2xl",children:"⛺"}),s.jsx("span",{children:M==="ar"?"تصريح ولي الأمر للمخيمات الكشفية والرحلات العلمية":"Parental Scout Camp & Educational Excursion Bond"})]})
    ]}),
    s.jsxs("div",{className:"text-left font-mono",children:[s.jsx("div",{className:"text-xs text-slate-500",children:M==="ar"?"رقم القيد الكشفي":"Scout Badge ID"}),s.jsx("div",{className:"text-base font-black text-emerald-700",children:"SCOUT-2026-EGY"})]})
  ]}),
  s.jsxs("div",{className:"space-y-3 text-xs bg-slate-50 p-4 rounded-xl border border-slate-300",children:[
    s.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-3",children:[
      s.jsxs("div",{children:[s.jsx("span",{className:"font-bold text-slate-500 block",children:M==="ar"?"الوجهة والمعسكر المقرر:":"Destination & Camp:"}),s.jsx("span",{className:"font-bold text-slate-900",children:M==="ar"?"معسكر الكشافة الشتوي ببورسعيد وقناة السويس":"Port Said Winter Scout Camp"})]}),
      s.jsxs("div",{children:[s.jsx("span",{className:"font-bold text-slate-500 block",children:M==="ar"?"رتبة الطالب الكشفية:":"Scout Rank:"}),s.jsx("span",{className:"font-bold text-emerald-800",children:M==="ar"?"كشاف أول (First Class Scout) - شارة القيادة":"First Class Scout - Patrol Leader"})]}),
      s.jsxs("div",{className:"sm:col-span-2 p-3 bg-emerald-50 rounded-xl border border-emerald-200",children:[
        s.jsx("span",{className:"font-bold text-emerald-900 block mb-1",children:M==="ar"?"موافقة وتعهد ولي الأمر الصريح:":"Parental Clear Authorization:"}),
        s.jsx("p",{className:"text-slate-800 text-[11px]",children:M==="ar"?"أوافق أنا ولي الأمر على سفر الطالب مع البعثة الكشفية المدرسية تحت إشراف القادة الكشفيين وسددت رسوم التأمين ضد الحوادث.":"I authorize student participation in school scouting camp under leadership supervision."})
      ]})
    ]})
  ]}),
  s.jsxs("div",{className:"mt-5 pt-4 border-t-2 border-slate-300 flex items-center justify-between",children:[
    s.jsxs("div",{className:"flex items-center gap-3",children:[
      s.jsxs("div",{className:"w-16 h-16 rounded-full border-4 border-emerald-700 flex flex-col items-center justify-center p-1 text-emerald-800 text-center font-serif text-[8px] rotate-2 shadow-sm",children:[s.jsx("span",{className:"font-bold",children:M==="ar"?"مفوضية الكشافة":"SCOUT FED"}),s.jsx("span",{className:"font-black text-[9px]",children:"APPROVED"})]}),
      s.jsx("div",{className:"text-xs text-slate-500",children:M==="ar"?"معتمد من القائد الكشفي الأول ومسؤول الأنشطة المدرسية.":"Certified by Chief Scoutmaster & Activities Supervisor."})
    ]}),
    s.jsx("button",{type:"button",onClick:()=>Wt("main"),className:"px-4 py-2 rounded-xl bg-slate-800 text-slate-200 text-xs font-bold hover:bg-slate-700",children:M==="ar"?"الرجوع للاستمارة الرئيسية ◄":"Back to Dossier ◄"})
  ]})
]})}),
Zt==="arabic_calligraphy_diploma"&&s.jsx("div",{className:"space-y-4 animate-in fade-in duration-150",children:s.jsxs("div",{className:"bg-white/95 p-6 rounded-2xl border-2 border-amber-400 shadow-md text-slate-900",children:[
  s.jsxs("div",{className:"border-b-2 border-slate-800 pb-3 mb-4 flex items-center justify-between",children:[
    s.jsxs("div",{children:[
      s.jsx("div",{className:"text-xs font-black text-amber-800 uppercase tracking-wide",children:M==="ar"?"أكاديمية الخط العربي والفنون والزخرفة الإسلامية المدرسية":"School Academy of Arabic Calligraphy & Islamic Art"}),
      s.jsxs("h3",{className:"text-2xl font-black text-slate-900 mt-1 flex items-center gap-2",children:[s.jsx("span",{className:"text-2xl",children:"✍️"}),s.jsx("span",{children:M==="ar"?"إجازة الخط العربي والتميز في الفنون التراثية":"Arabic Classical Calligraphy & Heritage Art Diploma"})]})
    ]}),
    s.jsxs("div",{className:"text-left font-mono",children:[s.jsx("div",{className:"text-xs text-slate-500",children:M==="ar"?"الدرجة والتقدير":"Grade & Standing"}),s.jsx("div",{className:"text-base font-black text-amber-700",children:M==="ar"?"امتياز مع مرتبة الشرف":"Distinction Honors"})]})
  ]}),
  s.jsxs("div",{className:"space-y-3 text-xs bg-slate-50 p-4 rounded-xl border border-slate-300",children:[
    s.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-3",children:[
      s.jsxs("div",{children:[s.jsx("span",{className:"font-bold text-slate-500 block",children:M==="ar"?"الخطوط المتقنة والمجاز بها:":"Mastered Arabic Scripts:"}),s.jsx("span",{className:"font-bold text-amber-900",children:M==="ar"?"خط الرقعة، النسخ، الديواني، والثلث العربي":"Riq'ah, Naskh, Diwani & Thuluth Scripts"})]}),
      s.jsxs("div",{children:[s.jsx("span",{className:"font-bold text-slate-500 block",children:M==="ar"?"مشاركة المعارض الفنية:":"Art Exhibitions:"}),s.jsx("span",{className:"font-bold text-slate-900",children:M==="ar"?"لوحة شرف المعرض السنوي لقصور الثقافة":"Annual Cultural Palaces Grand Exhibition"})]}),
      s.jsxs("div",{className:"sm:col-span-2 p-3 bg-amber-50 rounded-xl border border-amber-200",children:[
        s.jsx("span",{className:"font-bold text-amber-900 block mb-1",children:M==="ar"?"توصية شيخ الخطاطين بالوزارة:":"Master Calligrapher Endorsement:"}),
        s.jsx("p",{className:"text-slate-800 text-[11px]",children:M==="ar"?"أظهر الطالب براعة منقطعة النظير في كتابة آيات الذكر الحكيم واللوحات الإرشادية للمدرسة.":"Demonstrated exceptional handcraft in classical calligraphy and school ornamental banners."})
      ]})
    ]})
  ]}),
  s.jsxs("div",{className:"mt-5 pt-4 border-t-2 border-slate-300 flex items-center justify-between",children:[
    s.jsxs("div",{className:"flex items-center gap-3",children:[
      s.jsxs("div",{className:"w-16 h-16 rounded-full border-4 border-amber-700 flex flex-col items-center justify-center p-1 text-amber-800 text-center font-serif text-[8px] -rotate-2 shadow-sm",children:[s.jsx("span",{className:"font-bold",children:M==="ar"?"نقابة الخطاطين":"CALLIGRAPHY"}),s.jsx("span",{className:"font-black text-[9px]",children:"DIPLOMA"})]}),
      s.jsx("div",{className:"text-xs text-slate-500",children:M==="ar"?"معتمد ومسجل بسجل المبدعين والخطاطين الواعدين.":"Endorsed by Master Calligraphers Guild Inspector."})
    ]}),
    s.jsx("button",{type:"button",onClick:()=>Wt("main"),className:"px-4 py-2 rounded-xl bg-slate-800 text-slate-200 text-xs font-bold hover:bg-slate-700",children:M==="ar"?"الرجوع للاستمارة الرئيسية ◄":"Back to Dossier ◄"})
  ]})
]})}),
Zt==="anti_bullying_pledge"&&s.jsx("div",{className:"space-y-4 animate-in fade-in duration-150",children:s.jsxs("div",{className:"bg-white/95 p-6 rounded-2xl border-2 border-rose-400 shadow-md text-slate-900",children:[
  s.jsxs("div",{className:"border-b-2 border-slate-800 pb-3 mb-4 flex items-center justify-between",children:[
    s.jsxs("div",{children:[
      s.jsx("div",{className:"text-xs font-black text-rose-800 uppercase tracking-wide",children:M==="ar"?"لجنة الحماية المدرسية ومكافحة التنمر والبيئة الآمنة":"School Child Protection Committee & Safe Campus Charter"}),
      s.jsxs("h3",{className:"text-2xl font-black text-slate-900 mt-1 flex items-center gap-2",children:[s.jsx("span",{className:"text-2xl",children:"🛡️"}),s.jsx("span",{children:M==="ar"?"وثيقة ميثاق مكافحة التنمر والسلامة الطلابية الشاملة":"Anti-Bullying Charter & Zero Tolerance Safety Covenant"})]})
    ]}),
    s.jsxs("div",{className:"text-left font-mono",children:[s.jsx("div",{className:"text-xs text-slate-500",children:M==="ar"?"كود الميثاق":"Charter ID"}),s.jsx("div",{className:"text-base font-black text-rose-700",children:"SAFE-CAMPUS-2026"})]})
  ]}),
  s.jsxs("div",{className:"space-y-3 text-xs bg-slate-50 p-4 rounded-xl border border-slate-300",children:[
    s.jsxs("div",{className:"p-3 bg-rose-50 rounded-xl border border-rose-200",children:[
      s.jsx("span",{className:"font-bold text-rose-900 block mb-1",children:M==="ar"?"بنود ميثاق الشرف الأخلاقي:":"Safety & Ethics Commitments:"}),
      s.jsxs("ul",{className:"list-disc list-inside space-y-1 text-slate-800 text-[11px]",children:[
        s.jsx("li",{children:M==="ar"?"الالتزام التام بالاحترام المتبادل ونبذ التنمر اللفظي أو البدني أو الإلكتروني.":"Strict mutual respect and zero verbal, physical, or cyber-bullying."}),
        s.jsx("li",{children:M==="ar"?"المحافظة على سلامة الزملاء وممتلكات المدرسة ومرافقها.":"Maintaining student safety, school property, and facilities."}),
        s.jsx("li",{children:M==="ar"?"الإبلاغ الفوري لإدارة المدرسة والأخصائي عند رصد أي سلوك سلبي.":"Immediate reporting of any unsafe behaviors to administration."})
      ]})
    ]}),
    s.jsxs("div",{className:"grid grid-cols-2 gap-3",children:[
      s.jsxs("div",{className:"p-2.5 bg-white rounded-lg border",children:[s.jsx("span",{className:"font-bold text-slate-500 block text-[10px]",children:M==="ar"?"توقيع الطالب:":"Student Signature:"}),s.jsx("span",{className:"font-mono font-bold text-slate-900 text-xs",children:a.name})]}),
      s.jsxs("div",{className:"p-2.5 bg-white rounded-lg border",children:[s.jsx("span",{className:"font-bold text-slate-500 block text-[10px]",children:M==="ar"?"توقيع ولي الأمر:":"Guardian Signature:"}),s.jsx("span",{className:"font-mono font-bold text-slate-900 text-xs",children:a.fatherName||"ولي أمر الطالب"})]})
    ]})
  ]}),
  s.jsxs("div",{className:"mt-5 pt-4 border-t-2 border-slate-300 flex items-center justify-between",children:[
    s.jsxs("div",{className:"flex items-center gap-3",children:[
      s.jsxs("div",{className:"w-16 h-16 rounded-full border-4 border-rose-700 flex flex-col items-center justify-center p-1 text-rose-800 text-center font-serif text-[8px] rotate-3 shadow-sm",children:[s.jsx("span",{className:"font-bold",children:M==="ar"?"الحماية المدرسية":"PROTECTION"}),s.jsx("span",{className:"font-black text-[9px]",children:"SIGNED"})]}),
      s.jsx("div",{className:"text-xs text-slate-500",children:M==="ar"?"معتمد ومودع بسجل الحماية المدرسية التابع للوزارة.":"Deposited in the Ministry Child Protection Registry."})
    ]}),
    s.jsx("button",{type:"button",onClick:()=>Wt("main"),className:"px-4 py-2 rounded-xl bg-slate-800 text-slate-200 text-xs font-bold hover:bg-slate-700",children:M==="ar"?"الرجوع للاستمارة الرئيسية ◄":"Back to Dossier ◄"})
  ]})
]})}),
Zt==="library_membership"&&s.jsx("div",{className:"space-y-4 animate-in fade-in duration-150",children:s.jsxs("div",{className:"bg-white/95 p-6 rounded-2xl border-2 border-stone-400 shadow-md text-slate-900",children:[
  s.jsxs("div",{className:"border-b-2 border-slate-800 pb-3 mb-4 flex items-center justify-between",children:[
    s.jsxs("div",{children:[
      s.jsx("div",{className:"text-xs font-black text-stone-800 uppercase tracking-wide",children:M==="ar"?"الإدارة العامة للمكتبات المدرسية ومصادر المعرفة":"General Directorate of School Libraries & Information Centers"}),
      s.jsxs("h3",{className:"text-2xl font-black text-slate-900 mt-1 flex items-center gap-2",children:[s.jsx("span",{className:"text-2xl",children:"📚"}),s.jsx("span",{children:M==="ar"?"استمارة قيد وبطاقة عضوية المكتبة والبحث العلمي":"School Library Membership & Junior Research Patron Card"})]})
    ]}),
    s.jsxs("div",{className:"text-left font-mono",children:[s.jsx("div",{className:"text-xs text-slate-500",children:M==="ar"?"تصنيف ديوي العشري":"Dewey Code"}),s.jsx("div",{className:"text-base font-black text-stone-700",children:"962.05 (مصر والعلوم)"})]})
  ]}),
  s.jsxs("div",{className:"space-y-3 text-xs bg-slate-50 p-4 rounded-xl border border-slate-300",children:[
    s.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-3",children:[
      s.jsxs("div",{children:[s.jsx("span",{className:"font-bold text-slate-500 block",children:M==="ar"?"رقم عضوية القارئ:":"Library Card ID:"}),s.jsx("span",{className:"font-mono font-bold text-stone-900",children:["LIB-2026-",a.id.slice(-5).toUpperCase()]})]}),
      s.jsxs("div",{children:[s.jsx("span",{className:"font-bold text-slate-500 block",children:M==="ar"?"فئة العضوية والصلاحيات:":"Membership Tier:"}),s.jsx("span",{className:"font-bold text-emerald-800",children:M==="ar"?"قارئ وباحث متميز (إعارة 4 كتب متزامنة)":"Distinguished Researcher (4 Book Loan)"})]}),
      s.jsxs("div",{className:"sm:col-span-2 p-3 bg-stone-100 rounded-xl border border-stone-200",children:[
        s.jsx("span",{className:"font-bold text-stone-900 block mb-1",children:M==="ar"?"سجل القراءة ومسابقات تحدي القراءة العربي:":"Reading Log & Arabic Reading Challenge:"}),
        s.jsx("p",{className:"text-slate-800 text-[11px]",children:M==="ar"?"أتم قراءة وتلخيص 25 كتاباً في مجالات العلوم والتاريخ وتأهل للمرحلة النهائية من تحدي القراءة.":"Completed 25 book summaries qualifying for the National Reading Challenge finals."})
      ]})
    ]})
  ]}),
  s.jsxs("div",{className:"mt-5 pt-4 border-t-2 border-slate-300 flex items-center justify-between",children:[
    s.jsxs("div",{className:"flex items-center gap-3",children:[
      s.jsxs("div",{className:"w-16 h-16 rounded-full border-4 border-stone-700 flex flex-col items-center justify-center p-1 text-stone-800 text-center font-serif text-[8px] rotate-2 shadow-sm",children:[s.jsx("span",{className:"font-bold",children:M==="ar"?"المكتبة المدرسية":"LIBRARY"}),s.jsx("span",{className:"font-black text-[9px]",children:"ISSUED"})]}),
      s.jsx("div",{className:"text-xs text-slate-500",children:M==="ar"?"مختوم من أمين المكتبة وموجه أول المكتبات بالإدارة.":"Certified by Senior School Library Supervisor."})
    ]}),
    s.jsx("button",{type:"button",onClick:()=>Wt("main"),className:"px-4 py-2 rounded-xl bg-slate-800 text-slate-200 text-xs font-bold hover:bg-slate-700",children:M==="ar"?"الرجوع للاستمارة الرئيسية ◄":"Back to Dossier ◄"})
  ]})
]})}),
Zt==="robotics_badge"&&s.jsx("div",{className:"space-y-4 animate-in fade-in duration-150",children:s.jsxs("div",{className:"bg-white/95 p-6 rounded-2xl border-2 border-cyan-400 shadow-md text-slate-900",children:[
  s.jsxs("div",{className:"border-b-2 border-slate-800 pb-3 mb-4 flex items-center justify-between",children:[
    s.jsxs("div",{children:[
      s.jsx("div",{className:"text-xs font-black text-cyan-800 uppercase tracking-wide",children:M==="ar"?"نوادي العلوم والتكنولوجيا • الدوري المدرسي للروبوتات والذكاء الاصطناعي":"STEM Science Clubs • School Robotics & AI League"}),
      s.jsxs("h3",{className:"text-2xl font-black text-slate-900 mt-1 flex items-center gap-2",children:[s.jsx("span",{className:"text-2xl",children:"🤖"}),s.jsx("span",{children:M==="ar"?"شهادة اعتماد دوري الروبوتات والبرمجة والذكاء الاصطناعي":"Robotics & Artificial Intelligence Junior Innovator Diploma"})]})
    ]}),
    s.jsxs("div",{className:"text-left font-mono",children:[s.jsx("div",{className:"text-xs text-slate-500",children:M==="ar"?"المرتبة والوسام":"Award Rank"}),s.jsx("div",{className:"text-base font-black text-cyan-700",children:"🥇 المركز الأول (Gold)"})]})
  ]}),
  s.jsxs("div",{className:"space-y-3 text-xs bg-slate-50 p-4 rounded-xl border border-slate-300",children:[
    s.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-3",children:[
      s.jsxs("div",{children:[s.jsx("span",{className:"font-bold text-slate-500 block",children:M==="ar"?"مشروع الابتكار المسجل:":"Registered Innovation Project:"}),s.jsx("span",{className:"font-bold text-cyan-950",children:M==="ar"?"روبوت ذكي لإطفاء الحرائق المعملية بالأشعة دون تدخل بشري":"Autonomous Lab Firefighting & Hazard Detection Robot"})]}),
      s.jsxs("div",{children:[s.jsx("span",{className:"font-bold text-slate-500 block",children:M==="ar"?"لغات البرمجة والأنظمة المستخدمة:":"Tech Stack & Programming:"}),s.jsx("span",{className:"font-bold font-mono text-slate-900",children:"Python • Arduino • Computer Vision"})]}),
      s.jsxs("div",{className:"sm:col-span-2 p-3 bg-cyan-50 rounded-xl border border-cyan-200",children:[
        s.jsx("span",{className:"font-bold text-cyan-900 block mb-1",children:M==="ar"?"تقييم لجنة تحكيم نوادي العلوم:":"STEM Jury Evaluation Verdict:"}),
        s.jsx("p",{className:"text-slate-800 text-[11px]",children:M==="ar"?"تم اعتماد المشروع كأحد أفضل 5 ابتكارات مدرسية على مستوى الجمهورية وتمثيل المدرسة بالمعرض العربي.":"Approved among Top 5 Nationwide STEM Innovations representing the school regionally."})
      ]})
    ]})
  ]}),
  s.jsxs("div",{className:"mt-5 pt-4 border-t-2 border-slate-300 flex items-center justify-between",children:[
    s.jsxs("div",{className:"flex items-center gap-3",children:[
      s.jsxs("div",{className:"w-16 h-16 rounded-full border-4 border-cyan-700 flex flex-col items-center justify-center p-1 text-cyan-800 text-center font-serif text-[8px] -rotate-3 shadow-sm",children:[s.jsx("span",{className:"font-bold",children:M==="ar"?"نوادي العلوم":"STEM CLUB"}),s.jsx("span",{className:"font-black text-[9px]",children:"ACCREDITED"})]}),
      s.jsx("div",{className:"text-xs text-slate-500",children:M==="ar"?"موثق من الموجه العام لمادة الحاسب الآلي وتكنولوجيا المعلومات.":"Certified by Computer Science & IT Senior Supervisor."})
    ]}),
    s.jsx("button",{type:"button",onClick:()=>Wt("main"),className:"px-4 py-2 rounded-xl bg-slate-800 text-slate-200 text-xs font-bold hover:bg-slate-700",children:M==="ar"?"الرجوع للاستمارة الرئيسية ◄":"Back to Dossier ◄"})
  ]})
]})}),
Zt==="chess_accreditation"&&s.jsx("div",{className:"space-y-4 animate-in fade-in duration-150",children:s.jsxs("div",{className:"bg-white/95 p-6 rounded-2xl border-2 border-purple-400 shadow-md text-slate-900",children:[
  s.jsxs("div",{className:"border-b-2 border-slate-800 pb-3 mb-4 flex items-center justify-between",children:[
    s.jsxs("div",{children:[
      s.jsx("div",{className:"text-xs font-black text-purple-800 uppercase tracking-wide",children:M==="ar"?"الاتحاد المصري للشطرنج المدرسي والرياضات الذهنية":"Egyptian School Chess & Mind Sports Federation"}),
      s.jsxs("h3",{className:"text-2xl font-black text-slate-900 mt-1 flex items-center gap-2",children:[s.jsx("span",{className:"text-2xl",children:"♟️"}),s.jsx("span",{children:M==="ar"?"بطاقة اعتماد وتصنيف اتحاد الشطرنج المدرسي الرسمي":"Official School Chess Federation & Master Rating Pass"})]})
    ]}),
    s.jsxs("div",{className:"text-left font-mono",children:[s.jsx("div",{className:"text-xs text-slate-500",children:M==="ar"?"التصنيف الرسمي (ELO)":"FIDE/ELO Rating"}),s.jsx("div",{className:"text-base font-black text-purple-700",children:"1650 ELO (أستاذ مرشح)"})]})
  ]}),
  s.jsxs("div",{className:"space-y-3 text-xs bg-slate-50 p-4 rounded-xl border border-slate-300",children:[
    s.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-3",children:[
      s.jsxs("div",{children:[s.jsx("span",{className:"font-bold text-slate-500 block",children:M==="ar"?"المركز في بطولة الجمهورية للمدارس:":"National Scholastic Championship:"}),s.jsx("span",{className:"font-bold text-purple-950",children:M==="ar"?"🏆 بطل الجمهورية لقطاع المدارس التجريبية":"🏆 National Champion - Language Sector"})]}),
      s.jsxs("div",{children:[s.jsx("span",{className:"font-bold text-slate-500 block",children:M==="ar"?"الأسلوب التكتيكي المعتمد:":"Tactical Style & Strategy:"}),s.jsx("span",{className:"font-bold text-slate-900",children:M==="ar"?"افتتاحية صقلية هجومية وسرعة حساب النقلات":"Aggressive Sicilian Defense & Rapid Blitz Calculation"})]}),
      s.jsxs("div",{className:"sm:col-span-2 p-3 bg-purple-50 rounded-xl border border-purple-200",children:[
        s.jsx("span",{className:"font-bold text-purple-900 block mb-1",children:M==="ar"?"تزكية الاتحاد لتمثيل المدرسة:":"Federation Nomination:"}),
        s.jsx("p",{className:"text-slate-800 text-[11px]",children:M==="ar"?"تم اعتماد الطالب ككابتن فريق الشطرنج المدرسي وتأهيله لتمثيل المدرسة في البطولة العربية للشطرنج المدرسي.":"Nominated as School Chess Team Captain for Regional Championships."})
      ]})
    ]})
  ]}),
  s.jsxs("div",{className:"mt-5 pt-4 border-t-2 border-slate-300 flex items-center justify-between",children:[
    s.jsxs("div",{className:"flex items-center gap-3",children:[
      s.jsxs("div",{className:"w-16 h-16 rounded-full border-4 border-purple-700 flex flex-col items-center justify-center p-1 text-purple-800 text-center font-serif text-[8px] rotate-1 shadow-sm",children:[s.jsx("span",{className:"font-bold",children:M==="ar"?"اتحاد الشطرنج":"CHESS FED"}),s.jsx("span",{className:"font-black text-[9px]",children:"RATED"})]}),
      s.jsx("div",{className:"text-xs text-slate-500",children:M==="ar"?"معتمد ومسجل بسجلات الاتحاد الدولي للشطرنج المدرسي (FIDE).":"Certified in FIDE International Scholastic Chess Database."})
    ]}),
    s.jsx("button",{type:"button",onClick:()=>Wt("main"),className:"px-4 py-2 rounded-xl bg-slate-800 text-slate-200 text-xs font-bold hover:bg-slate-700",children:M==="ar"?"الرجوع للاستمارة الرئيسية ◄":"Back to Dossier ◄"})
  ]})
]})}),
'''

code = code[:ins_point] + new_renderers + code[ins_point:]
print("3. Successfully injected all 12 brand new official paper renderers!")

with open("assets/index-BeRTxH1o.js", "w") as f:
    f.write(code)
with open("assets/app-bundle.js", "w") as f:
    f.write(code)

import glob
for dist_js in glob.glob("dist/assets/*.js"):
    if "index" in dist_js or "app" in dist_js or "BeRTxH1o" in dist_js or "CwhFnn8I" in dist_js:
        with open(dist_js, "w") as f:
            f.write(code)
        print("Updated dist file:", dist_js)

ts = int(time.time())
with open("index.html", "r") as f:
    html = f.read()

html = re.sub(r'app-bundle\.js\?v=\d+', f'app-bundle.js?v={ts}', html)
html = re.sub(r'app-bundle\.css\?v=\d+', f'app-bundle.css?v={ts}', html)

with open("index.html", "w") as f:
    f.write(html)
with open("dist/index.html", "w") as f:
    f.write(html)

print("SUCCESS: Everything updated, compiled, and synced cleanly!")
