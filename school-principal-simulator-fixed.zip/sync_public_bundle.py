import re
import shutil

print("Applying fixes to both assets/app-bundle.js and public/assets/app-bundle.js...")

for target_file in ["assets/app-bundle.js", "public/assets/app-bundle.js"]:
    print(f"Updating {target_file}...")
    with open(target_file, "r") as f:
        code = f.read()

    # 1. Update wXe (Tutorial) onClose:
    code = re.sub(
        r's\.jsx\(wXe,\{isOpen:fr,onClose:\(\)=>\{[^\}]+\},language:i\.settings\.language\}\)',
        's.jsx(wXe,{isOpen:fr,onClose:()=>{Js(!1);try{localStorage.setItem("school_tutorial_completed","true")}catch{}if(window.__morningRoutineStep==="tutorial"){window.__morningRoutineStep="regulations";we(!0)}else{window.__morningRoutineStep=null}},language:i.settings.language})',
        code
    )

    # 2. Update CJe (Regulations) onClose:
    code = re.sub(
        r's\.jsx\(CJe,\{isOpen:de,onClose:\(\)=>\{[^\}]+\},language:i\.settings\.language,isDark:vi\}\)',
        's.jsx(CJe,{isOpen:de,onClose:()=>{we(!1);if(window.__morningRoutineStep==="regulations"){window.__morningRoutineStep="story";is(!0)}else{window.__morningRoutineStep=null}},language:i.settings.language,isDark:vi})',
        code
    )

    # 3. Update aZe (Story) onClose:
    code = re.sub(
        r's\.jsx\(aZe,\{isOpen:ms,onClose:\(\)=>\{[^\}]+\},currentDay:i\.currentDay',
        's.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1),l(pe=>({...pe,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));if(window.__morningRoutineStep==="story"){window.__morningRoutineStep=null;p(!0)}else{window.__morningRoutineStep=null}},currentDay:i.currentDay',
        code
    )

    # 4. Top X button on CJe header:
    code = code.replace(
        's.jsx("button",{onClick:()=>{I.playStampAccept(),e()}',
        's.jsx("button",{onClick:()=>{I.playStampAccept();window.__morningRoutineStep=null;e()}'
    )

    # 5. Quick bar and manual triggers for Regulations: MUST set window.__morningRoutineStep = null
    manual_reg_handler = "()=>{p(!1);is(!1);Js(!1);window.__morningRoutineStep=null;we(!0)}"

    code = code.replace('onOpenDailyRegulations:()=>{p(!1);is(!1);Js(!1);window.__morningRoutineStep=null;we(!0)}', f'onOpenDailyRegulations:{manual_reg_handler}')
    code = code.replace('onOpenDailyRegulations:()=>we(!0)', f'onOpenDailyRegulations:{manual_reg_handler}')
    code = code.replace('onOpenRulebook:()=>{p(!1);is(!1);Js(!1);window.__morningRoutineStep=null;we(!0)}', f'onOpenRulebook:{manual_reg_handler}')
    code = code.replace('onOpenRulebook:()=>we(!0)', f'onOpenRulebook:{manual_reg_handler}')
    code = code.replace('window.addEventListener("open-rulebook",()=>we(!0))', f'window.addEventListener("open-rulebook",{manual_reg_handler})')

    # 6. Morning routine start button handler:
    code = re.sub(
        r'onStartGame:\(\)=>\{[^\}]+\}',
        'onStartGame:()=>{I.playPaperRustle();const ae=$E(i.currentDay,4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!1);is(!1);we(!1);window.__morningRoutineStep="tutorial";Js(!0);c("desk")}',
        code
    )

    code = re.sub(
        r'onStartMorningRoutine:\(\)=>\{[^\}]+\}',
        'onStartMorningRoutine:()=>{I.playPaperRustle();const ae=$E(i.currentDay,4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!1);is(!1);we(!1);window.__morningRoutineStep="tutorial";Js(!0);c("desk")}',
        code
    )

    # 7. Remove maxAllowedAbsencePct and requiredSubjectCutoffs from early days in Sxe dictionary
    code = code.replace('maxAllowedAbsencePct:20,', '')
    code = code.replace('maxAllowedAbsencePct:18,', '')
    code = code.replace(
        'requiredSubjectCutoffs:[{subjectKey:"math",nameAr:"الرياضيات",nameEn:"Mathematics",minScore:80},{subjectKey:"science",nameAr:"العلوم والفيزياء",nameEn:"Science & Physics",minScore:80}],',
        ''
    )

    with open(target_file, "w") as f:
        f.write(code)

print("Synchronized all bundles in /assets and /public/assets successfully!")
