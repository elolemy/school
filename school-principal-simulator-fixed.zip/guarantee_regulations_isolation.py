import re

print("Applying robust guarantee that Regulations modal never opens story or decisions when opened on its own...")

with open("assets/app-bundle.js", "r") as f:
    code = f.read()

# 1. Update window.addEventListener for open-rulebook to set rnStep to null
code = code.replace(
    'window.addEventListener("open-rulebook",()=>we(!0))',
    'window.addEventListener("open-rulebook",()=>{setRnStep(null);we(!0)})'
)

# 2. In JDe modal render in Kat, ensure onOpenRulebook sets rnStep to null
code = code.replace(
    'onOpenRulebook:()=>{we(!0)}',
    'onOpenRulebook:()=>{setRnStep(null);we(!0)}'
)

# 3. Ensure CJe onClose cleanly resets rnStep and only opens p(!0) when rnStep was explicitly 'regulations'
old_cje = 's.jsx(CJe,{isOpen:de,onClose:()=>{we(!1);if(rnStep==="regulations"){setRnStep(null),p(!0)}},language:i.settings.language,isDark:vi})'
new_cje = 's.jsx(CJe,{isOpen:de,onClose:()=>{we(!1);const wasReg=rnStep==="regulations";setRnStep(null);if(wasReg){p(!0)}},language:i.settings.language,isDark:vi})'

if old_cje in code:
    code = code.replace(old_cje, new_cje, 1)
    print("✓ Updated CJe onClose to safely reset rnStep")
else:
    print("! Using regex to update CJe onClose...")
    code = re.sub(
        r's\.jsx\(CJe,\{isOpen:de,onClose:\(\)=>\{.+?\},language:i\.settings\.language,isDark:vi\}\)',
        new_cje,
        code
    )

# 4. In aZe onClose, ensure rnStep resets if not in 'story'
old_aze = 's.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1),l(pe=>({...pe,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));if(rnStep==="story"){setRnStep("regulations"),we(!0)}},currentDay:i.currentDay'
new_aze = 's.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1),l(pe=>({...pe,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));const wasStory=rnStep==="story";setRnStep(null);if(wasStory){setRnStep("regulations");we(!0)}},currentDay:i.currentDay'

if old_aze in code:
    code = code.replace(old_aze, new_aze, 1)
    print("✓ Updated aZe onClose")
else:
    print("! Using regex to update aZe onClose...")
    code = re.sub(
        r's\.jsx\(aZe,\{isOpen:ms,onClose:\(\)=>\{.+?\},currentDay:i\.currentDay',
        new_aze,
        code
    )

with open("assets/app-bundle.js", "w") as f:
    f.write(code)

print("Applied changes successfully.")
