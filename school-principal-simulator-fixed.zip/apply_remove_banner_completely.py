import subprocess

print("Removing targeted banner elements completely...")

dispute_snippet = """i.currentDispute?s.jsx("div",{className:"max-w-6xl mx-auto px-4 pt-3 flex items-center justify-between",children:s.jsxs("button",{onClick:()=>I.playPaperRustle(),className:"w-full p-3 rounded-2xl bg-gradient-to-r from-red-600 via-rose-600 to-amber-600 text-white font-black text-sm flex items-center justify-between shadow-lg shadow-red-900/30 animate-pulse border border-red-400/50",children:[s.jsxs("span",{className:"flex items-center gap-2",children:[s.jsx("span",{className:"w-3 h-3 rounded-full bg-white animate-ping"}),s.jsx("span",{children:i.settings.language==="ar"?`⚠️ حالة طارئة: ${i.currentDispute.title}`:`⚠️ Urgent Hearing: ${i.currentDispute.titleEn}`})]}),s.jsx("span",{className:"px-3 py-1 rounded-xl bg-slate-950/40 text-xs font-bold border border-white/20",children:i.settings.language==="ar"?"فتح جلسة التحقيق والبت الفوري":"Open Hearing Room"})]})}):null"""

zse_snippet = 's.jsx(ZSe,{state:i,isAr:i.settings.language==="ar"}),'

for path in ["public/assets/app-bundle.js", "assets/app-bundle.js"]:
    print(f"Updating JS bundle at {path}...")
    with open(path, "r") as f:
        c = f.read()

    if dispute_snippet in c:
        c = c.replace(dispute_snippet, "null")
        print("  Replaced dispute banner with null")
    else:
        print("  WARNING: dispute_snippet not found!")

    if zse_snippet in c:
        c = c.replace(zse_snippet, "")
        print("  Removed ZSe emergency tasks banner")
    else:
        print("  WARNING: zse_snippet not found!")

    with open(path, "w") as f:
        f.write(c)

    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check!")
    else:
        print(f"  ERROR: {path} syntax error:\n{res.stderr[:400]}")
        exit(1)

css_addition = """
.bg-rose-600\\/90,
.max-w-6xl.mx-auto.px-4.pt-3 {
  display: none !important;
}
"""

for css_path in ["public/assets/app-bundle.css", "assets/app-bundle.css"]:
    with open(css_path, "r") as f:
        css = f.read()
    if ".bg-rose-600\\/90" not in css:
        css += "\n" + css_addition
        with open(css_path, "w") as f:
            f.write(css)
        print(f"  Updated CSS at {css_path}")

print("Banner removal completely finished!")
