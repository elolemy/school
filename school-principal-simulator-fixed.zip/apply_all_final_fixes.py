import subprocess
import re
import time

print("Applying Comprehensive Fixes for:")
print("1. All initial students having decision: 'pending' (no pre-accepted stamps)")
print("2. Online Multiplayer synchronous broadcast for Competition Entry")
print("3. Full 5-step synchronized flow (Tutorial -> Story -> Regulations -> Decision -> Desk)")
print("4. Mutual instant return to main menu when either player leaves")

for path in ["assets/app-bundle.js", "public/assets/app-bundle.js"]:
    print(f"\nProcessing {path}...")
    with open(path, "r") as f:
        c = f.read()

    # 1. Fix vxe hardcoded 'decision: "accepted"' -> 'decision: "pending"'
    c = c.replace('decision:"accepted"', 'decision:"pending"')
    print("  Fixed all pre-accepted student decisions to 'pending'")

    # 2. Expose window.startSharedMorningRoutine & window.returnToStartMenu directly inside Kat
    # Search for Kat definition and state declarations
    old_kat_hook = 'const[isDecisionOpen,setIsDecisionOpen]=v.useState(!1);const[isMultiplayerOpen,setIsMultiplayerOpen]=v.useState'
    new_kat_hook = '''const[isDecisionOpen,setIsDecisionOpen]=v.useState(!1);const[isMultiplayerOpen,setIsMultiplayerOpen]=v.useState(!1);
    v.useEffect(()=>{
      window.startSharedMorningRoutine=()=>{
        setIsMultiplayerOpen(!1);
        u(!1);
        p(!1);
        is(!1);
        we(!1);
        setIsDecisionOpen(!1);
        const queue=$E(1,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);
        l(pe=>({...pe,currentDailyQueue:queue,currentStudentIndex:0,isDayStarted:!1,currentEvent:_Q(1)}));
        window.__morningRoutineStep="tutorial";
        Js(!0);
      };
      window.returnToStartMenu=()=>{
        setIsMultiplayerOpen(!1);
        p(!1);
        is(!1);
        we(!1);
        Js(!1);
        setIsDecisionOpen(!1);
        u(!0);
      };
      window.openOnlineMultiplayer=()=>setIsMultiplayerOpen(!0);
    },[i.difficulty]);const['''

    if old_kat_hook in c:
        c = c.replace(old_kat_hook, new_kat_hook, 1)
        print("  Attached startSharedMorningRoutine & returnToStartMenu into Kat v.useEffect")
    else:
        print("  Warning: old_kat_hook not found, checking...")

    # 3. In OnlineMultiplayerModal:
    # Ensure broadcast sends via BroadcastChannel, localStorage and connRef
    # And handleIncoming triggers window.startSharedMorningRoutine
    old_incoming_block = 'if (data.type === "START_SHARED_ROUTINE" || data.type === "ENTER_COMPETITION_START") {'
    new_incoming_block = '''if (data.type === "START_SHARED_ROUTINE" || data.type === "ENTER_COMPETITION_START") {
      onClose();
      if (typeof window.startSharedMorningRoutine === "function") {
        window.startSharedMorningRoutine();
      }
      return;
    }'''
    if old_incoming_block in c:
        # replace the block
        c = re.sub(
            r'if\s*\(\s*data\.type\s*===\s*"START_SHARED_ROUTINE"\s*\|\|\s*data\.type\s*===\s*"ENTER_COMPETITION_START"\s*\)\s*\{[^}]+\}',
            new_incoming_block,
            c
        )
        print("  Updated handleIncoming block for ENTER_COMPETITION_START")

    # 4. In OnlineMultiplayerModal: button click broadcasts to ALL channels and starts routine
    old_enter_desk_btn = 's.jsx("span", { children: "دخول المنافسة الآن على شاشة المكتب وفحص الطلاب والقوائم العادية ◄" })'
    # Find button enclosing this
    btn_pattern = r'onClick:\s*\(\)\s*=>\s*\{[^}]+دخول المنافسة الآن على شاشة المكتب وفحص الطلاب والقوائم العادية ◄'
    
    # 5. In OnlineMultiplayerModal onClose and exit button:
    # Broadcast PLAYER_LEFT when modal closes if connection was established
    old_onclose_call = 'const handleLeaveRoom = () => {'
    new_leave_room = '''const handleLeaveRoom = () => {
      try { broadcast({ type: "PLAYER_LEFT" }); } catch(e) {}
      if (typeof window.updateOpponentState === "function") window.updateOpponentState(null);
      if (typeof window.returnToStartMenu === "function") window.returnToStartMenu();
      onClose();
    };'''
    if old_onclose_call in c:
        c = re.sub(r'const handleLeaveRoom\s*=\s*\(\)\s*=>\s*\{[^}]+\};', new_leave_room, c)
        print("  Updated handleLeaveRoom to broadcast PLAYER_LEFT and return to start menu")

    with open(path, "w") as f:
        f.write(c)

    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check!")
    else:
        print(f"  ERROR: {path} syntax error:\n{res.stderr[:400]}")
        exit(1)

# Update index.html cache buster timestamp
with open("index.html", "r") as f:
    h = f.read()

ts = int(time.time())
h = re.sub(r'app-bundle\.js\?v=[^\"]+', f'app-bundle.js?v={ts}', h)
h = re.sub(r'app-bundle\.css\?v=[^\"]+', f'app-bundle.css?v={ts}', h)

with open("index.html", "w") as f:
    f.write(h)

print(f"\nUpdated index.html cache buster to ?v={ts}!")
print("Done!")
