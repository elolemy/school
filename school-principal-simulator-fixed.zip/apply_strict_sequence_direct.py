import subprocess

guard_code = """window.__morningRoutineGuard=window.__morningRoutineGuard||{currentStep:null,start:function(){this.currentStep="instructions"},advanceFrom:function(s){if(this.currentStep!==s)return null;if(s==="instructions"){this.currentStep="story";return"story"}if(s==="story"){this.currentStep="regulations";return"regulations"}if(s==="regulations"){this.currentStep="decisions";return"decisions"}if(s==="decisions"){this.currentStep=null;return"done"}return null},reset:function(){this.currentStep=null}};"""

old_sje = """s.jsx(SJe,{gameState:i,onStartGame:()=>{u(!1);let ae=!1;try{ae=localStorage.getItem("school_tutorial_completed")==="true"}catch{}i.currentDay===1&&!ae?(Js(!0),p(!1),is(!1)):(l(re=>({...re,isDayStarted:!0})),p(!1),is(!1),Js(!1)),c("desk")},onStartMorningRoutine:()=>{I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)})),u(!1),p(!1),Js(!1),is(!0),c("desk")},onRestartStory:e,onUpdateGameState:ae=>{l(ae),ri(ae)},onOpenSettings:()=>Ae(!0),onOpenRulebook:()=>we(!0),onOpenTutorial:()=>Js(!0),onOpenAchievements:()=>ye(!0),onOpenSupportChat:()=>Tt(!0),onLogout:r})"""

new_sje = """s.jsx(SJe,{gameState:i,onStartGame:()=>{window.__morningRoutineGuard.start();I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!1);is(!1);we(!1);Js(!0);c("desk")},onStartMorningRoutine:()=>{window.__morningRoutineGuard.start();I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!1);is(!1);we(!1);Js(!0);c("desk")},onRestartStory:e,onUpdateGameState:ae=>{l(ae),ri(ae)},onOpenSettings:()=>Ae(!0),onOpenRulebook:()=>{window.__morningRoutineGuard.reset();we(!0)},onOpenTutorial:()=>Js(!0),onOpenAchievements:()=>ye(!0),onOpenSupportChat:()=>Tt(!0),onLogout:r})"""

old_wxe = """s.jsx(wXe,{isOpen:fr,onClose:()=>{Js(!1);try{localStorage.setItem("school_tutorial_completed","true")}catch{}i.currentDay===1&&!i.isDayStarted&&!ms&&p(!0)},language:i.settings.language})"""

new_wxe = """s.jsx(wXe,{isOpen:fr,onClose:()=>{Js(!1);try{localStorage.setItem("school_tutorial_completed","true")}catch{}const next=window.__morningRoutineGuard.advanceFrom("instructions");if(next==="story"){p(!1);we(!1);is(!0)}},language:i.settings.language})"""

old_aze = """s.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1),l(pe=>({...pe,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}))},currentDay:i.currentDay"""

new_aze = """s.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1);l(pe=>({...pe,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));const next=window.__morningRoutineGuard.advanceFrom("story");if(next==="regulations"){Js(!1);p(!1);we(!0)}},currentDay:i.currentDay"""

old_cje = """s.jsx(CJe,{isOpen:de,onClose:()=>we(!1),language:i.settings.language,isDark:vi})"""

new_cje = """s.jsx(CJe,{isOpen:de,onClose:()=>{we(!1);const next=window.__morningRoutineGuard.advanceFrom("regulations");if(next==="decisions"){Js(!1);is(!1);p(!0)}},language:i.settings.language,isDark:vi})"""

old_jde_start = """onStartDay:()=>{p(!1),I.playSchoolBell(),l(ae=>({...ae,isDayStarted:!0})),is(!0)}"""

new_jde_start = """onStartDay:()=>{p(!1);window.__morningRoutineGuard.advanceFrom("decisions");I.playSchoolBell();l(ae=>({...ae,isDayStarted:!0}))}"""

for path in ["public/assets/app-bundle.js", "assets/app-bundle.js"]:
    print(f"Applying strict sequence updates to {path}...")
    with open(path, "r") as f:
        c = f.read()

    # Prepend guard code if not present
    if "window.__morningRoutineGuard" not in c:
        c = guard_code + "\n" + c

    # Replace each target
    if old_sje in c:
        c = c.replace(old_sje, new_sje)
        print("  Replaced SJe")
    else:
        print("  WARNING: old_sje not found!")

    if old_wxe in c:
        c = c.replace(old_wxe, new_wxe)
        print("  Replaced wXe")
    else:
        print("  WARNING: old_wxe not found!")

    if old_aze in c:
        c = c.replace(old_aze, new_aze)
        print("  Replaced aZe")
    else:
        print("  WARNING: old_aze not found!")

    if old_cje in c:
        c = c.replace(old_cje, new_cje)
        print("  Replaced CJe")
    else:
        print("  WARNING: old_cje not found!")

    if old_jde_start in c:
        c = c.replace(old_jde_start, new_jde_start)
        print("  Replaced JDe onStartDay")
    else:
        print("  WARNING: old_jde_start not found!")

    with open(path, "w") as f:
        f.write(c)

    # Validate syntax with Node
    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check (returncode 0)")
    else:
        print(f"  ERROR: {path} syntax error:\n{res.stderr[:500]}")
        exit(1)

print("Done applying strict morning routine sequence!")
