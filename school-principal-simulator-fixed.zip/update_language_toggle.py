import glob
import re

print("Starting language toggle update...")

with open("assets/app-bundle.js", "r") as f:
    code = f.read()

# 1. Update badge-language to be an interactive toggle button
old_badge = 's.jsxs("div",{id:"badge-language",className:"px-2.5 py-1.5 rounded-lg border font-bold text-xs bg-emerald-500/15 text-emerald-400 border-emerald-500/30 flex items-center gap-1.5 select-none",title:"اللغة معتمدة بالكامل باللغة العربية",children:[s.jsx("span",{children:"🇸🇦"}),s.jsx("span",{children:"العربية"})]})'

new_badge = 's.jsxs("button",{id:"badge-language",onClick:ee,title:de==="ar"?"تغيير اللغة إلى الإنجليزية (Switch to English)":"Switch to Arabic (التحويل للعربية)",className:`px-2.5 py-1.5 rounded-lg border font-bold text-xs flex items-center gap-1.5 select-none cursor-pointer transition-all duration-200 active:scale-95 shadow-sm ${de==="ar"?"bg-emerald-500/15 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/25 hover:border-emerald-500/50":"bg-sky-500/15 text-sky-400 border-sky-500/30 hover:bg-sky-500/25 hover:border-sky-500/50"}`,children:[s.jsx("span",{children:de==="ar"?"🇸🇦":"🇬🇧"}),s.jsx("span",{children:de==="ar"?"العربية":"English"}),s.jsx("span",{className:"text-[10px] opacity-75 px-1 py-0.5 rounded bg-black/20 font-mono",children:de==="ar"?"⇄ EN":"⇄ AR"})]})'

assert old_badge in code, "old_badge not found in code"
code = code.replace(old_badge, new_badge, 1)

# 2. Update Cp to toggle between Arabic and English
old_cp = 'Cp=()=>{l(ae=>({...ae,settings:{...ae.settings,language:"ar"}}))}'
new_cp = 'Cp=()=>{l(ae=>{const pe=ae.settings.language==="ar"?"en":"ar";try{document.documentElement.lang=pe,document.documentElement.dir=pe==="ar"?"rtl":"ltr",document.body.dir=pe==="ar"?"rtl":"ltr"}catch(st){}return{...ae,settings:{...ae.settings,language:pe}}})}'

assert old_cp in code, "old_cp not found in code"
code = code.replace(old_cp, new_cp, 1)

with open("assets/app-bundle.js", "w") as f:
    f.write(code)

with open("assets/index-BeRTxH1o.js", "w") as f:
    f.write(code)

# Update public/ and dist/
for target in [
    "public/assets/app-bundle.js",
    "public/assets/index-BeRTxH1o.js",
    "dist/assets/app-bundle.js",
    "dist/assets/index-BeRTxH1o.js"
]:
    try:
        with open(target, "w") as f:
            f.write(code)
        print(f"Updated {target}")
    except Exception as e:
        print(f"Could not write {target}: {e}")

for f_path in glob.glob("dist/assets/*.js"):
    if "index" in f_path or "bundle" in f_path:
        with open(f_path, "w") as f:
            f.write(code)
        print(f"Updated {f_path}")

print("Language toggle update complete!")
