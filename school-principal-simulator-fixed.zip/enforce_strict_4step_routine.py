import re
import subprocess

print("Enforcing strict 4-step morning routine sequence...")

strict_start_handler = '()=>{I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!1);is(!1);we(!1);window.__routinePhase="tutorial";Js(!0);c("desk")}'

for target_file in ["assets/app-bundle.js", "public/assets/app-bundle.js"]:
    print(f"Enforcing sequence in {target_file}...")
    with open(target_file, "r") as f:
        code = f.read()

    # 1. Update SJe rendering props in Kat
    # Replace onStartGame and onStartMorningRoutine with strict_start_handler
    code = re.sub(
        r'onStartGame:\(\)=>\{[^\}]+\}',
        f'onStartGame:{strict_start_handler}',
        code
    )

    code = re.sub(
        r'onStartMorningRoutine:\(\)=>\{[^\}]+\}',
        f'onStartMorningRoutine:{strict_start_handler}',
        code
    )

    # 2. Update wXe (Instructions / Tutorial) onClose:
    # Always transitions to "story" if in routine phase
    code = re.sub(
        r's\.jsx\(wXe,\{isOpen:fr,onClose:\(\)=>\{[^\}]+\},language:i\.settings\.language\}\)',
        's.jsx(wXe,{isOpen:fr,onClose:()=>{Js(!1);try{localStorage.setItem("school_tutorial_completed","true")}catch{}window.__routinePhase="story";is(!0)},language:i.settings.language})',
        code
    )

    # 3. Update aZe (Today Story) onClose:
    # Transitions to "regulations" if in "story" phase
    code = re.sub(
        r's\.jsx\(aZe,\{isOpen:ms,onClose:\(\)=>\{[^\}]+\},currentDay:i\.currentDay',
        's.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1);l(pe=>({...pe,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));if(window.__routinePhase==="story"){window.__routinePhase="regulations";we(!0)}else{window.__routinePhase=null}},currentDay:i.currentDay',
        code
    )

    # 4. Update CJe (Regulations) onClose:
    # Transitions to "briefing" (p(!0)) if in "regulations" phase
    code = re.sub(
        r's\.jsx\(CJe,\{isOpen:de,onClose:\(\)=>\{[^\}]+\},language:i\.settings\.language,isDark:vi\}\)',
        's.jsx(CJe,{isOpen:de,onClose:()=>{we(!1);if(window.__routinePhase==="regulations"){window.__routinePhase=null;p(!0)}else{window.__routinePhase=null}},language:i.settings.language,isDark:vi})',
        code
    )

    with open(target_file, "w") as f:
        f.write(code)

    # Validate with node
    res = subprocess.run(["node", "--input-type=module", "-c"], input=code, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"SUCCESS: {target_file} passed syntax validation!")
    else:
        print(f"ERROR in {target_file}:\n{res.stderr}")
        exit(1)

print("Strict 4-step morning routine enforced and validated!")
