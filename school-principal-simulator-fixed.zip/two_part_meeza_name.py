import re
import time
import glob

with open("assets/app-bundle.js", "r") as f:
    code = f.read()

# 1. Update Dne component so cardholderName on Meeza card is strictly two-part (first + father name)
old_dne_start = 'Dne=({student:t,isCompact:e=!1})=>{const r=t.personalVisaCard||{cardNumber:"5078 9204 8812 4091",cardholderName:t.nameEn.toUpperCase()'
new_dne_start = 'Dne=({student:t,isCompact:e=!1})=>{const r=t.personalVisaCard||{cardNumber:"5078 9204 8812 4091",cardholderName:(t.nameEn||t.name||"").split(" ").slice(0,2).join(" ").toUpperCase()'

if old_dne_start in code:
    code = code.replace(old_dne_start, new_dne_start)
    print("1. Updated Dne cardholderName default to 2-part name!")

# Also replace r.cardholderName render in Dne
old_dne_render = 'children:r.cardholderName'
new_dne_render = 'children:(r.cardholderName||t.nameEn||t.name||"").split(" ").slice(0,2).join(" ").toUpperCase()'

if old_dne_render in code:
    code = code.replace(old_dne_render, new_dne_render)
    print("2. Replaced r.cardholderName in Dne render with 2-part slice!")

# 2. In generator: update be = { ..., cardholderName: p.toUpperCase(), ... }
old_gen_card = 'cardholderName:p.toUpperCase()'
new_gen_card = 'cardholderName:p.split(" ").slice(0,2).join(" ").toUpperCase()'

if old_gen_card in code:
    code = code.replace(old_gen_card, new_gen_card)
    print("3. Updated generator Meeza cardholderName to 2-part name!")

with open("assets/app-bundle.js", "w") as f:
    f.write(code)
with open("assets/index-BeRTxH1o.js", "w") as f:
    f.write(code)

for dist_js in glob.glob("dist/assets/*.js"):
    if "index" in dist_js or "app" in dist_js or "BeRTxH1o" in dist_js or "BoWY_e0a" in dist_js or "CwhFnn8I" in dist_js or "C9sCu8NM" in dist_js or "QB4pRpBj" in dist_js or "CM2YjkZp" in dist_js:
        with open(dist_js, "w") as f:
            f.write(code)
        print("Updated dist file:", dist_js)

ts = int(time.time())
with open("index.html", "r") as f:
    html = f.read()

html = re.sub(r'app-bundle\.js\?v=\d+', f'app-bundle.js?v={ts}', html)
html = re.sub(r'app-bundle\.css\?v=\d+', f'app-bundle.css?v={ts}', html)

with open("index.html", "w") as f:
    f.write(html)
with open("dist/index.html", "w") as f:
    f.write(html)

print("SUCCESS: Student name is now strictly two-part on Meeza Visa Card!")
