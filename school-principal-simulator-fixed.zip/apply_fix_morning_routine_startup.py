import subprocess

print("Fixing morning routine startup: replacing Js(!0) with Js(!1) in onStartGame and onStartMorningRoutine...")

target1 = 'u(!1);p(!1);is(!1);we(!1);Js(!0);c("desk")},onStartMorningRoutine:()=>{window.__morningRoutineGuard.start();I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!1);is(!1);we(!1);Js(!0);c("desk")}'

replacement1 = 'u(!1);p(!1);is(!1);we(!1);Js(!1);c("desk")},onStartMorningRoutine:()=>{window.__morningRoutineGuard.start();I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!1);is(!1);we(!1);Js(!1);c("desk")}'

target2 = ',ri(ae),Js(!0),p(!1),is(!1),c("desk")}'
replacement2 = ',ri(ae),Js(!1),p(!1),is(!1),c("desk")}'

target3 = ',ri(ae),Js(!0),p(!1),is(!1),c("desk")},onRestoreState'
replacement3 = ',ri(ae),Js(!1),p(!1),is(!1),c("desk")},onRestoreState'

for path in ["public/assets/app-bundle.js", "assets/app-bundle.js"]:
    print(f"Updating {path}...")
    with open(path, "r") as f:
        c = f.read()

    if target1 in c:
        c = c.replace(target1, replacement1)
        print("  Replaced target1 (onStartGame & onStartMorningRoutine)")
    else:
        print("  WARNING: target1 not found!")

    c = c.replace(target2, replacement2)
    c = c.replace(target3, replacement3)

    # Also ensure _Je and TJe remain closed
    c = c.replace("s.jsx(_Je,{isOpen:xr,", "s.jsx(_Je,{isOpen:!1,")
    c = c.replace("s.jsx(TJe,{isOpen:bs,", "s.jsx(TJe,{isOpen:!1,")
    if "!1&&s.jsx(JDe,{" not in c and "s.jsx(JDe,{" in c:
        c = c.replace("s.jsx(JDe,{", "!1&&s.jsx(JDe,{")

    with open(path, "w") as f:
        f.write(c)

    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check!")
    else:
        print(f"  ERROR: {path} syntax error:\n{res.stderr[:400]}")
        exit(1)

print("Startup morning routine fix completed!")
