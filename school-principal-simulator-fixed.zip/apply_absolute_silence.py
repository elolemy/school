import subprocess

print("Enforcing absolute silence and disabling all music/melodies/fanfares/bells...")

for path in ["public/assets/app-bundle.js", "assets/app-bundle.js"]:
    print(f"Updating {path}...")
    with open(path, "r") as f:
        c = f.read()

    # 1. Purge localStorage on startup to soundEnabled: false
    old_purge = 'try{const _st=localStorage.getItem("school_sim_game_state");if(_st){const _p=JSON.parse(_st);if(_p&&_p.settings){_p.settings.musicEnabled=!1;_p.settings.ambientSoundEnabled=!1;_p.settings.musicVolume=0;_p.settings.ambientVolume=0;localStorage.setItem("school_sim_game_state",JSON.stringify(_p))}}}catch(e){};'
    new_purge = 'try{const _st=localStorage.getItem("school_sim_game_state");if(_st){const _p=JSON.parse(_st);if(_p&&_p.settings){_p.settings.soundEnabled=!1;_p.settings.musicEnabled=!1;_p.settings.ambientSoundEnabled=!1;_p.settings.musicVolume=0;_p.settings.ambientVolume=0;localStorage.setItem("school_sim_game_state",JSON.stringify(_p))}}}catch(e){};'
    if old_purge in c:
        c = c.replace(old_purge, new_purge)
    else:
        c = new_purge + c

    # 2. Zd default settings: soundEnabled: !1
    c = c.replace(
        'settings:{language:"ar",theme:"dark",soundEnabled:!0',
        'settings:{language:"ar",theme:"dark",soundEnabled:!1'
    )

    # 3. Exe constructor: isMuted: !0 by default
    c = c.replace('ft(this,"isMuted",!1)', 'ft(this,"isMuted",!0)')

    # 4. initContext: check isMuted immediately
    old_init = "initContext(){try{if(!this.ctx&&typeof window<\"u\"){"
    new_init = "initContext(){if(this.isMuted)return;try{if(!this.ctx&&typeof window<\"u\"){"
    if old_init in c:
        c = c.replace(old_init, new_init)

    # 5. Neutralize musical melodies and fanfares
    musical_methods = [
        "playAchievementFanfare(){",
        "playUpgradeSuccess(){",
        "playInspectorAlert(){",
        "playSchoolBell(){",
        "playSchoolBellStandard(){",
        "playSchoolBellFireAlarm(){",
        "playSchoolBellRecess(){",
        "playBellTone(",
        "playOrganTone(",
        "playAlarmTone(",
        "playChimeSuccess(){",
        "playApplePayChime(){"
    ]
    for m in musical_methods:
        c = c.replace(m, m + "return;")

    # 6. Ensure the focused mute button handles mute properly and suspends audio context
    old_btn = 'className:"p-2.5 rounded-xl bg-slate-850 hover:bg-slate-800 border border-slate-750 text-amber-300 transition-all shadow-sm",title:T?"كتم الصوت والموسيقى بالكامل":"تشغيل المؤثرات الصوتية"'
    new_btn = 'className:"p-2.5 rounded-xl bg-slate-850 hover:bg-slate-800 border border-slate-750 text-amber-300 transition-all shadow-sm",title:T?"كتم الصوت والموسيقى بالكامل":"تشغيل المؤثرات"'
    if old_btn in c:
        c = c.replace(old_btn, new_btn)

    with open(path, "w") as f:
        f.write(c)

    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check!")
    else:
        print(f"  ERROR: {path} syntax error:\n{res.stderr[:400]}")
        exit(1)

print("Absolute silence configuration completed!")
