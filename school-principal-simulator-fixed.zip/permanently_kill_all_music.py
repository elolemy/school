import subprocess

print("Permanently disabling all music and ambient synth playback across the entire app...")

for path in ["public/assets/app-bundle.js", "assets/app-bundle.js"]:
    print(f"Updating {path}...")
    with open(path, "r") as f:
        c = f.read()

    # 1. Purge localStorage music flags on bundle load
    storage_purge = 'try{const _st=localStorage.getItem("school_sim_game_state");if(_st){const _p=JSON.parse(_st);if(_p&&_p.settings){_p.settings.musicEnabled=!1;_p.settings.ambientSoundEnabled=!1;_p.settings.musicVolume=0;_p.settings.ambientVolume=0;localStorage.setItem("school_sim_game_state",JSON.stringify(_p))}}}catch(e){};'
    if "localStorage.getItem(\"school_sim_game_state\")" not in c[:1000]:
        c = storage_purge + c
        print("  Added instant localStorage purge at top of bundle")

    # 2. Update setSoundEnabled to completely mute and suspend context if !e
    old_set_sound = "setSoundEnabled(e){this.isMuted=!e,this.toggleMusic(e),this.setAmbientEnabled(e)}"
    new_set_sound = 'setSoundEnabled(e){this.isMuted=!e;this.musicVolume=0;this.ambientVolume=0;this.isMusicPlaying=!1;this.isAmbientRunning=!1;this.ambientEnabled=!1;if(this.timerId){window.clearTimeout(this.timerId);this.timerId=null;}if(this.ambientTimerId){window.clearTimeout(this.ambientTimerId);this.ambientTimerId=null;}if(!e&&this.ctx&&this.ctx.state!=="closed"){try{this.ctx.suspend().catch(()=>{})}catch(err){}}}'
    if old_set_sound in c:
        c = c.replace(old_set_sound, new_set_sound)
        print("  Updated setSoundEnabled to strictly mute music and ambient")
    else:
        print("  WARNING: old_set_sound not found!")

    # 3. Update setAmbientEnabled to strictly stay disabled
    old_set_ambient = "setAmbientEnabled(e){this.ambientEnabled=e,e&&!this.isAmbientRunning?(this.initContext(),this.isAmbientRunning=!0,this.startAmbientLoop()):!e&&this.isAmbientRunning&&(this.isAmbientRunning=!1,this.ambientTimerId&&(window.clearTimeout(this.ambientTimerId),this.ambientTimerId=null))}"
    new_set_ambient = "setAmbientEnabled(e){this.ambientEnabled=!1;this.isAmbientRunning=!1;this.ambientVolume=0;if(this.ambientTimerId){window.clearTimeout(this.ambientTimerId);this.ambientTimerId=null;}}"
    if old_set_ambient in c:
        c = c.replace(old_set_ambient, new_set_ambient)
        print("  Updated setAmbientEnabled to never run")
    else:
        print("  WARNING: old_set_ambient not found!")

    # 4. Silence all ambient renderers
    c = c.replace("playStageAmbientBeat(e,r){", "playStageAmbientBeat(e,r){return;")
    c = c.replace("playStageAmbiencePreview(e){", "playStageAmbiencePreview(e){return;")
    c = c.replace("renderKgPlaygroundAmbience(e,r){", "renderKgPlaygroundAmbience(e,r){return;")
    c = c.replace("renderPrimarySchoolAmbience(e,r){", "renderPrimarySchoolAmbience(e,r){return;")
    c = c.replace("renderPreparatoryHallwayAmbience(e,r){", "renderPreparatoryHallwayAmbience(e,r){return;")
    c = c.replace("renderSecondaryAssemblyAmbience(e,r){", "renderSecondaryAssemblyAmbience(e,r){return;")
    c = c.replace("renderClassroomOccupancyNoise(e,r){", "renderClassroomOccupancyNoise(e,r){return;")

    # 5. Update the focused button in SJe header
    old_btn = 'onClick:()=>{const U=!T;n({...t,settings:{...t.settings,soundEnabled:U,musicEnabled:U}}),I.setSoundEnabled(U)},className:"p-2.5 rounded-xl bg-slate-850 hover:bg-slate-800 border border-slate-750 text-amber-300 transition-all shadow-sm",title:T?"كتم الصوت":"تشغيل الصوت"'
    new_btn = 'onClick:()=>{const U=!T;n({...t,settings:{...t.settings,soundEnabled:U,musicEnabled:!1,ambientSoundEnabled:!1}}),I.setSoundEnabled(U),!U&&(I.toggleMusic(!1),I.setAmbientEnabled(!1),I.ctx&&I.ctx.state!=="closed"&&I.ctx.suspend().catch(()=>{}));},className:"p-2.5 rounded-xl bg-slate-850 hover:bg-slate-800 border border-slate-750 text-amber-300 transition-all shadow-sm",title:T?"كتم الصوت والموسيقى بالكامل":"تشغيل المؤثرات الصوتية"'
    if old_btn in c:
        c = c.replace(old_btn, new_btn)
        print("  Updated focused button in SJe header")
    else:
        print("  WARNING: old_btn not found!")

    with open(path, "w") as f:
        f.write(c)

    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check!")
    else:
        print(f"  ERROR: {path} syntax error:\n{res.stderr[:400]}")
        exit(1)

print("All audio updates successfully completed!")
