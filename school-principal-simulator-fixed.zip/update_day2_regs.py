import re
import subprocess

print("Updating Day 2 regulations threshold in app-bundle.js...")

for path in ["assets/app-bundle.js", "public/assets/app-bundle.js"]:
    print(f"\nProcessing {path}...")
    with open(path, "r", encoding="utf-8") as f:
        c = f.read()

    # 1. Update Sxe[2] minAcademicPercentage to 78 and update themeDirective text
    old_day2 = '2:{day:2,title:"اليوم 2: قرار وزاري برفع الحد الأدنى للمعدل الأكاديمي والتدقيق الصحي",titleEn:"Day 2: Ministerial Decree Raising Academic Threshold & Medical Scrutiny",themeDirective:"نظراً للإقبال الكبير على التسجيل، تقرر رفع الحد الأدنى للنسبة المئوية المقبولة إلى 75% مع التدقيق الصارم في خلو بطاقة التطعيمات من التزوير، واشتراط مطابقة الرقم القومي للسن الفعلي.",themeDirectiveEn:"Minimum acceptance threshold raised to 75% with strict audit of vaccination seals and National ID age consistency.",minAcademicPercentage:75,'
    
    new_day2 = '2:{day:2,title:"اليوم 2: قرار وزاري برفع الحد الأدنى للمعدل الأكاديمي والتدقيق الصحي",titleEn:"Day 2: Ministerial Decree Raising Academic Threshold & Medical Scrutiny",themeDirective:"نظراً للإقبال الكبير على التسجيل، تقرر رفع الحد الأدنى للنسبة المئوية المقبولة إلى 78% مع التدقيق الصارم في خلو بطاقة التطعيمات من التزوير، واشتراط مطابقة الرقم القومي للسن الفعلي.",themeDirectiveEn:"Minimum acceptance threshold raised to 78% with strict audit of vaccination seals and National ID age consistency.",minAcademicPercentage:78,'

    if old_day2 in c:
        c = c.replace(old_day2, new_day2, 1)
        print("  Updated Sxe[2] successfully via exact match")
    else:
        # Regex replacement for Day 2
        c = re.sub(
            r'2:\s*\{day:2,[^}]*minAcademicPercentage:\s*\d+',
            '2:{day:2,title:"اليوم 2: قرار وزاري برفع الحد الأدنى للمعدل الأكاديمي والتدقيق الصحي",titleEn:"Day 2: Ministerial Decree Raising Academic Threshold & Medical Scrutiny",themeDirective:"نظراً للإقبال الكبير على التسجيل، تقرر رفع الحد الأدنى للنسبة المئوية المقبولة إلى 78% مع التدقيق الصارم في خلو بطاقة التطعيمات من التزوير، واشتراط مطابقة الرقم القومي للسن الفعلي.",themeDirectiveEn:"Minimum acceptance threshold raised to 78% with strict audit of vaccination seals and National ID age consistency.",minAcademicPercentage:78',
            c
        )
        print("  Updated Sxe[2] via regex")

    # 2. Update Jh function so that if i has minAcademicPercentage (like Day 2), it prioritizes i.minAcademicPercentage instead of Dxe override
    old_jh_f = 'if(i){const f=n,'
    new_jh_f = 'if(i){const f=i.minAcademicPercentage??n,'
    if old_jh_f in c:
        c = c.replace(old_jh_f, new_jh_f, 1)
        print("  Updated Jh function to respect i.minAcademicPercentage")

    with open(path, "w", encoding="utf-8") as f:
        f.write(c)

    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check!")
    else:
        print(f"  ERROR: {path} syntax error:\n{res.stderr[:400]}")
        exit(1)

print("\nSuccessfully updated Day 2 regulations threshold to 78%!")
