import re

print("Applying no-story morning routine fix: Regulations -> Decisions directly...")

with open("assets/app-bundle.js", "r") as f:
    code = f.read()

# 1. Update onStartGame and onStartMorningRoutine:
# Starts Morning Routine directly by opening Regulations (we(!0)) with window.__morningRoutineStep = "regulations"
start_routine_code = '()=>{I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!1);is(!1);Js(!1);window.__morningRoutineStep="regulations";we(!0);c("desk")}'

code = re.sub(
    r'onStartGame:\(\)=>\{[^\}]+\}',
    f'onStartGame:{start_routine_code}',
    code
)

code = re.sub(
    r'onStartMorningRoutine:\(\)=>\{[^\}]+\}',
    f'onStartMorningRoutine:{start_routine_code}',
    code
)

# 2. Update CJe (Regulations) onClose:
# If window.__morningRoutineStep === "regulations", proceed directly to Decisions (p(!0)) and set window.__morningRoutineStep = null
# Otherwise, set window.__morningRoutineStep = null and stay on Desk (NO STORY, NO DECISIONS)
code = re.sub(
    r's\.jsx\(CJe,\{isOpen:de,onClose:\(\)=>\{[^\}]+\},language:i\.settings\.language,isDark:vi\}\)',
    's.jsx(CJe,{isOpen:de,onClose:()=>{we(!1);if(window.__morningRoutineStep==="regulations"){window.__morningRoutineStep=null;p(!0)}else{window.__morningRoutineStep=null}},language:i.settings.language,isDark:vi})',
    code
)

# 3. Top X button on CJe header: ALWAYS cancels routine step (window.__morningRoutineStep = null) and closes CJe directly
code = code.replace(
    's.jsx("button",{onClick:()=>{I.playStampAccept(),e()}',
    's.jsx("button",{onClick:()=>{I.playStampAccept();window.__morningRoutineStep=null;e()}'
)

# 4. Quick bar and manual triggers for Regulations: MUST set window.__morningRoutineStep = null so closing CJe does NOT open decisions or story
manual_reg_handler = "()=>{p(!1);is(!1);Js(!1);window.__morningRoutineStep=null;we(!0)}"

code = code.replace('onOpenDailyRegulations:()=>{p(!1);is(!1);Js(!1);window.__morningRoutineStep=null;we(!0)}', f'onOpenDailyRegulations:{manual_reg_handler}')
code = code.replace('onOpenDailyRegulations:()=>we(!0)', f'onOpenDailyRegulations:{manual_reg_handler}')
code = code.replace('onOpenRulebook:()=>{p(!1);is(!1);Js(!1);window.__morningRoutineStep=null;we(!0)}', f'onOpenRulebook:{manual_reg_handler}')
code = code.replace('onOpenRulebook:()=>we(!0)', f'onOpenRulebook:{manual_reg_handler}')
code = code.replace('window.addEventListener("open-rulebook",()=>we(!0))', f'window.addEventListener("open-rulebook",{manual_reg_handler})')

with open("assets/app-bundle.js", "w") as f:
    f.write(code)

print("Applied no-story morning routine fix successfully!")
