import subprocess

print("Applying fixed header and removing simulation bar...")

old_header = "return s.jsxs(\"header\",{className:`sticky top-0 z-40 border-b backdrop-blur-md"
new_header = "return s.jsxs(\"header\",{className:`fixed top-0 left-0 right-0 z-40 border-b backdrop-blur-md"

old_main = 's.jsxs("main",{className:"pb-28",'
new_main = 's.jsxs("main",{className:"pt-28 pb-28",'

old_sim_bar = """s.jsx("div",{className:"max-w-6xl mx-auto px-4 pt-3 flex items-center justify-between",children:i.currentDispute?s.jsxs("button",{onClick:()=>I.playPaperRustle(),className:"w-full p-3 rounded-2xl bg-gradient-to-r from-red-600 via-rose-600 to-amber-600 text-white font-black text-sm flex items-center justify-between shadow-lg shadow-red-900/30 animate-pulse border border-red-400/50",children:[s.jsxs("span",{className:"flex items-center gap-2",children:[s.jsx("span",{className:"w-3 h-3 rounded-full bg-white animate-ping"}),s.jsx("span",{children:i.settings.language==="ar"?`⚠️ حالة طارئة: ${i.currentDispute.title}`:`⚠️ Urgent Hearing: ${i.currentDispute.titleEn}`})]}),s.jsx("span",{className:"px-3 py-1 rounded-xl bg-slate-950/40 text-xs font-bold border border-white/20",children:i.settings.language==="ar"?"فتح جلسة التحقيق والبت الفوري":"Open Hearing Room"})]}):s.jsxs("div",{className:"w-full flex items-center justify-between",children:[s.jsx("button",{onClick:()=>Ks(!0),className:"text-xs font-bold opacity-75 hover:opacity-100 text-rose-400 hover:text-rose-300 flex items-center gap-1.5 transition-all",children:s.jsx("span",{children:i.settings.language==="ar"?"🤡 محاكاة مقلب متمرد (حبر مكتب / ممحاة)":"🤡 Simulate Prank Cleanup"})}),s.jsx("button",{onClick:oo,className:"text-xs font-bold opacity-75 hover:opacity-100 text-amber-500 hover:text-amber-400 flex items-center gap-1.5 transition-all",children:s.jsx("span",{children:i.settings.language==="ar"?"⚔️ محاكاة استدعاء نزاع/مشاجرة طارئة في الفناء":"⚔️ Simulate Emergency Courtyard Dispute"})})]})})"""

new_sim_bar = """i.currentDispute?s.jsx("div",{className:"max-w-6xl mx-auto px-4 pt-3 flex items-center justify-between",children:s.jsxs("button",{onClick:()=>I.playPaperRustle(),className:"w-full p-3 rounded-2xl bg-gradient-to-r from-red-600 via-rose-600 to-amber-600 text-white font-black text-sm flex items-center justify-between shadow-lg shadow-red-900/30 animate-pulse border border-red-400/50",children:[s.jsxs("span",{className:"flex items-center gap-2",children:[s.jsx("span",{className:"w-3 h-3 rounded-full bg-white animate-ping"}),s.jsx("span",{children:i.settings.language==="ar"?`⚠️ حالة طارئة: ${i.currentDispute.title}`:`⚠️ Urgent Hearing: ${i.currentDispute.titleEn}`})]}),s.jsx("span",{className:"px-3 py-1 rounded-xl bg-slate-950/40 text-xs font-bold border border-white/20",children:i.settings.language==="ar"?"فتح جلسة التحقيق والبت الفوري":"Open Hearing Room"})]})}):null"""

old_uat = 's.jsx(Uat,{isAr:i.settings.language==="ar"}),'
new_uat = ''

for path in ["public/assets/app-bundle.js", "assets/app-bundle.js"]:
    print(f"Updating {path}...")
    with open(path, "r") as f:
        c = f.read()

    if old_header in c:
        c = c.replace(old_header, new_header)
        print("  Replaced header with fixed header")
    else:
        print("  WARNING: old_header not found!")

    if old_main in c:
        c = c.replace(old_main, new_main)
        print("  Updated main padding to pt-28 pb-28")
    else:
        print("  WARNING: old_main not found!")

    if old_sim_bar in c:
        c = c.replace(old_sim_bar, new_sim_bar)
        print("  Removed simulation/prank buttons bar")
    else:
        print("  WARNING: old_sim_bar not found!")

    if old_uat in c:
        c = c.replace(old_uat, new_uat)
        print("  Removed top Uat ticker to pin header directly to top")
    else:
        print("  WARNING: old_uat not found!")

    with open(path, "w") as f:
        f.write(c)

    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check!")
    else:
        print(f"  ERROR: {path} syntax error:\n{res.stderr[:400]}")
        exit(1)

print("Done updating header and removing simulation bar!")
