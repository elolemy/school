import glob
import re

print("Ensuring Daily Story & Morning Decision Flow across all 1000 days...")

with open("assets/app-bundle.js", "r") as f:
    code = f.read()

# 1. In aZe onClose, ensure currentEvent is set so Morning Briefing & Decision (XDe) opens right after story closes:
old_aze_render = 's.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1)}'
new_aze_render = 's.jsx(aZe,{isOpen:ms,onClose:()=>{is(!1),l(pe=>({...pe,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}))}'

assert old_aze_render in code, "old_aze_render not found"
code = code.replace(old_aze_render, new_aze_render, 1)

# 2. In SJe onStartMorningRoutine, ensure story opens and currentEvent is ready:
old_routine = 'onStartMorningRoutine:()=>{I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!1,currentDailyQueue:ae,currentStudentIndex:0})),u(!1);let re=!1;try{re=localStorage.getItem("school_tutorial_completed")==="true"}catch{}i.currentDay===1&&!re?(Js(!0),p(!1),is(!1)):(l(pe=>({...pe,isDayStarted:!0})),p(!1),is(!1),Js(!1)),c("desk")}'
new_routine = 'onStartMorningRoutine:()=>{I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)})),u(!1),p(!1),Js(!1),is(!0),c("desk")}'

if old_routine in code:
    code = code.replace(old_routine, new_routine, 1)
    print("Updated onStartMorningRoutine")
else:
    print("old_routine not found directly, checking regex or substring")

# 3. In initial state, ensure currentEvent is initialized with _Q(1)
old_init_state = 'activeViewMode:"desk",alumniFundBalance:0'
new_init_state = 'activeViewMode:"desk",currentEvent:_Q(1),alumniFundBalance:0'

if old_init_state in code:
    code = code.replace(old_init_state, new_init_state, 1)
    print("Updated initial state with _Q(1)")

with open("assets/app-bundle.js", "w") as f:
    f.write(code)

with open("assets/index-BeRTxH1o.js", "w") as f:
    f.write(code)

for target in [
    "public/assets/app-bundle.js",
    "public/assets/index-BeRTxH1o.js",
    "dist/assets/app-bundle.js",
    "dist/assets/index-BeRTxH1o.js"
]:
    try:
        with open(target, "w") as f:
            f.write(code)
    except Exception as e:
        print(f"Could not write {target}: {e}")

for f_path in glob.glob("dist/assets/*.js"):
    if "index" in f_path or "bundle" in f_path:
        with open(f_path, "w") as f:
            f.write(code)

print("Daily story & morning event flow updated successfully!")
