import subprocess

print("Applying fix: Remove initial decisions completely & Make tutorial header strictly fixed...")

for path in ["public/assets/app-bundle.js", "assets/app-bundle.js"]:
    print(f"Updating JS bundle at {path}...")
    with open(path, "r") as f:
        c = f.read()

    # 1. Eliminate JDe (Manager Decisions) from rendering
    if "m&&!d&&s.jsx(JDe,{" in c:
        c = c.replace("m&&!d&&s.jsx(JDe,{", "!1&&s.jsx(JDe,{")
        print("  Disabled JDe rendering (!1&&s.jsx(JDe))")
    else:
        print("  WARNING: JDe rendering pattern not found!")

    # 2. Neutralize p(!0) calls that were triggering decisions at start
    c = c.replace('l(Zd()),p(!0),c("desk")', 'l(Zd()),p(!1),c("desk")')
    c = c.replace('Vs?(I.playInspectorAlert(),Tr(!0)):p(!0);c("desk")', 'Vs?(I.playInspectorAlert(),Tr(!0)):p(!1);c("desk")')
    c = c.replace('onOpenDailyRegulations:()=>p(!0)', 'onOpenDailyRegulations:()=>we(!0)')

    # 3. Make wXe tutorial header & sub-header sticky/fixed inside the card
    c = c.replace(
        'shrink-0 relative z-20 tutorial-modal-header',
        'shrink-0 sticky top-0 z-50 tutorial-modal-header'
    )
    c = c.replace(
        'shrink-0 relative z-20 tutorial-modal-footer',
        'shrink-0 sticky bottom-0 z-50 tutorial-modal-footer'
    )

    with open(path, "w") as f:
        f.write(c)

    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check!")
    else:
        print(f"  ERROR: {path} syntax check failed:\n{res.stderr[:400]}")
        exit(1)

# 4. Update CSS files
css_replacement = """.tutorial-modal-card {
  max-height: 85vh !important;
  height: 620px !important;
  display: flex !important;
  flex-direction: column !important;
  overflow: hidden !important;
  position: relative !important;
}
.tutorial-modal-header {
  position: sticky !important;
  top: 0 !important;
  left: 0 !important;
  right: 0 !important;
  width: 100% !important;
  z-index: 50 !important;
  background-color: #020617 !important;
  border-bottom: 1px solid rgba(245, 158, 11, 0.4) !important;
  flex-shrink: 0 !important;
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.5) !important;
}
.tutorial-modal-sub-header {
  position: sticky !important;
  top: 0 !important;
  left: 0 !important;
  right: 0 !important;
  width: 100% !important;
  z-index: 40 !important;
  background-color: #0f172a !important;
  border-bottom: 1px solid #1e293b !important;
  flex-shrink: 0 !important;
}
.tutorial-modal-body {
  flex: 1 1 0% !important;
  overflow-y: auto !important;
  overscroll-behavior: contain !important;
  min-height: 0 !important;
  -webkit-overflow-scrolling: touch !important;
}
.tutorial-modal-footer {
  position: sticky !important;
  bottom: 0 !important;
  left: 0 !important;
  right: 0 !important;
  width: 100% !important;
  z-index: 50 !important;
  background-color: #020617 !important;
  border-top: 1px solid #1e293b !important;
  flex-shrink: 0 !important;
}"""

for css_path in ["public/assets/app-bundle.css", "assets/app-bundle.css"]:
    print(f"Updating CSS at {css_path}...")
    with open(css_path, "r") as f:
        css = f.read()

    idx = css.find(".tutorial-modal-card")
    if idx != -1:
        end_idx = css.find("}", css.find(".tutorial-modal-footer")) + 1
        css = css[:idx] + css_replacement + css[end_idx:]
    else:
        css += "\n" + css_replacement

    with open(css_path, "w") as f:
        f.write(css)
    print(f"  SUCCESS: {css_path} updated")

print("All changes successfully applied and verified!")
