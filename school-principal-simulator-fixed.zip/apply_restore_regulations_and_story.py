import subprocess

print("Restoring 1000 days regulations, daily story, and instructions...")

for path in ["public/assets/app-bundle.js", "assets/app-bundle.js"]:
    print(f"Updating {path}...")
    with open(path, "r") as f:
        c = f.read()

    # 1. Restore JDe modal rendering: m&&s.jsx(JDe,
    c = c.replace("!1&&s.jsx(JDe,{", "m&&s.jsx(JDe,{")

    # 2. Open JDe on start game / start morning routine by setting p(!0)
    old_start = 'u(!1);p(!1);is(!1);we(!1);Js(!1);c("desk")},onStartMorningRoutine:()=>{window.__morningRoutineGuard.start();I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!1);is(!1);we(!1);Js(!1);c("desk")}'
    new_start = 'u(!1);p(!0);is(!1);we(!1);Js(!1);c("desk")},onStartMorningRoutine:()=>{window.__morningRoutineGuard.start();I.playPaperRustle();const ae=$E(i.currentDay,i.difficulty==="hard"?5:i.difficulty==="easy"?3:4,i.difficulty);l(pe=>({...pe,isDayStarted:!0,currentDailyQueue:ae,currentStudentIndex:0,currentEvent:pe.currentEvent||_Q(pe.currentDay||1)}));u(!1);p(!0);is(!1);we(!1);Js(!1);c("desk")}'

    if old_start in c:
        c = c.replace(old_start, new_start)
        print("  Updated onStartGame and onStartMorningRoutine to set p(!0)")
    else:
        print("  WARNING: old_start not found!")

    # 3. Restore _Je (daily directives & inspection)
    c = c.replace("s.jsx(_Je,{isOpen:!1,", "s.jsx(_Je,{isOpen:xr,")

    # 4. Restore TJe (morning inspection)
    c = c.replace("s.jsx(TJe,{isOpen:!1,", "s.jsx(TJe,{isOpen:bs,")

    # 5. Restore Tr(!0) so inspector alert trigger works
    c = c.replace("Tr(!1)", "Tr(!0)")

    with open(path, "w") as f:
        f.write(c)

    res = subprocess.run(["node", "--input-type=module", "-c"], input=c, text=True, capture_output=True)
    if res.returncode == 0:
        print(f"  SUCCESS: {path} passed Node syntax check!")
    else:
        print(f"  ERROR: {path} syntax error:\n{res.stderr[:400]}")
        exit(1)

print("Restoration of regulations, story, and instructions successfully applied!")
